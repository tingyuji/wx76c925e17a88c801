(global.webpackJsonp = global.webpackJsonp || []).push([ [ "uni_modules/c-lottie/components/c-lottie/c-lottie" ], {
    "0b12": function(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return a;
        }), n.d(e, "c", function() {
            return o;
        }), n.d(e, "a", function() {});
        var a = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    "2cb2": function(t, e, n) {},
    "9b1b": function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("0b12"), o = n("a016");
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(i);
        n("e1cf");
        var r = n("828b"), c = Object(r.a)(o.default, a.b, a.c, !1, null, "1608924e", null, !1, a.a, void 0);
        e.default = c.exports;
    },
    a016: function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("e5a5"), o = n.n(a);
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(i);
        e.default = o.a;
    },
    e1cf: function(t, e, n) {
        "use strict";
        var a = n("2cb2");
        n.n(a).a;
    },
    e5a5: function(t, e, n) {
        "use strict";
        (function(t) {
            var a = n("47a9");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var o = a(n("7eb4")), i = a(n("af34")), r = a(n("ee10")), c = a(n("c817")), l = a(n("6eb4")), u = {
                props: {
                    canvasId: {
                        type: String
                    },
                    width: {
                        type: String,
                        default: "750rpx"
                    },
                    height: {
                        type: String,
                        default: "750rpx"
                    },
                    src: {
                        type: String
                    },
                    data: {
                        type: String
                    },
                    autoPlay: {
                        type: Boolean,
                        default: !0
                    },
                    loop: {
                        type: Boolean,
                        default: !0
                    },
                    renderer: {
                        type: String,
                        default: "canvas"
                    },
                    isOnChange: {
                        type: Boolean,
                        default: !1
                    }
                },
                emits: [ "Complete", "LoopComplete", "EnterFrame", "SegmentStart", "dataReady", "dataFailed" ],
                data: function() {
                    return {
                        fun: {}
                    };
                },
                computed: {
                    myCanvasId: function() {
                        return this.canvasId ? this.canvasId : "c" + (0, c.default)(18);
                    },
                    lottieData: function() {
                        return {
                            myCanvasId: this.myCanvasId,
                            width: this.width,
                            height: this.height,
                            src: this.src,
                            data: this.data,
                            autoPlay: this.autoPlay,
                            loop: this.loop,
                            renderer: this.renderer,
                            isOnChange: this.isOnChange
                        };
                    }
                },
                watch: {
                    lottieData: function() {
                        this.render();
                    }
                },
                methods: {
                    call: function(t, e) {
                        this.fun = {
                            name: t,
                            args: e
                        }, this.callPlayer(this.fun);
                    },
                    getContext: function() {
                        var e = this;
                        return new Promise(function(n) {
                            var a = t.getSystemInfoSync().pixelRatio;
                            t.createSelectorQuery().in(e).select("#".concat(e.myCanvasId)).fields({
                                node: !0,
                                size: !0
                            }).exec(function(t) {
                                var e = t[0], o = e.width, i = e.height, r = t[0].node;
                                n({
                                    canvas: r,
                                    width: o,
                                    height: i,
                                    pixelRatio: a
                                });
                            });
                        });
                    },
                    render: function() {
                        var t = this;
                        return (0, r.default)(o.default.mark(function e() {
                            var n, a, i, r, c;
                            return o.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return t.player && t.call("destroy", t.player), e.next = 3, t.getContext();

                                  case 3:
                                    n = e.sent, a = n.canvas, i = n.width, r = n.height, c = n.pixelRatio, t.myCanvas = a, 
                                    t.context = a.getContext("2d"), t.context.scale(c, c), a.width = i * c, a.height = r * c, 
                                    l.default.setup(t.myCanvas), t.player = l.default.loadAnimation({
                                        loop: t.loop,
                                        autoplay: t.autoPlay,
                                        animationData: t.data,
                                        path: t.src,
                                        rendererSettings: {
                                            context: t.context
                                        }
                                    }), t.player.addEventListener("data_ready", function(e) {
                                        t.$emit("dataReady", e);
                                    }), t.player.addEventListener("data_failed", function(e) {
                                        t.$emit("dataFailed", e);
                                    }), t.player.onComplete = function(e) {
                                        t.$emit("Complete", e);
                                    }, t.player.onLoopComplete = function(e) {
                                        t.$emit("LoopComplete", e);
                                    }, t.isOnChange && (t.player.onEnterFrame = function(e) {
                                        t.$emit("EnterFrame", e);
                                    }), t.player.onSegmentStart = function(e) {
                                        t.$emit("SegmentStart", e);
                                    };

                                  case 21:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    callPlayer: function(t) {
                        if (t.name) {
                            var e, n = t.name, a = t.args;
                            Array.isArray(a) ? (e = this.player)[n].apply(e, (0, i.default)(a)) : this.player[n](a);
                        }
                    }
                },
                mounted: function() {
                    this.render();
                },
                beforeDestroy: function() {
                    this.call("destroy");
                }
            };
            e.default = u;
        }).call(this, n("df3c").default);
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "uni_modules/c-lottie/components/c-lottie/c-lottie-create-component", {
    "uni_modules/c-lottie/components/c-lottie/c-lottie-create-component": function(t, e, n) {
        n("df3c").createComponent(n("9b1b"));
    }
}, [ [ "uni_modules/c-lottie/components/c-lottie/c-lottie-create-component" ] ] ]);