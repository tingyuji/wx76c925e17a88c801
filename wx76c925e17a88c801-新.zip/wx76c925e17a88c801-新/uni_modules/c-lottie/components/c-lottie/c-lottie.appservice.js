$gwx_XC_55=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_55 || [];
function gz$gwx_XC_55_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_55_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_55_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_55_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_55_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_55_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_55=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_55=true;
var x=['./uni_modules/c-lottie/components/c-lottie/c-lottie.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_55_1()
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_55";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_55();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uni_modules/c-lottie/components/c-lottie/c-lottie.wxml'] = [$gwx_XC_55, './uni_modules/c-lottie/components/c-lottie/c-lottie.wxml'];else __wxAppCode__['uni_modules/c-lottie/components/c-lottie/c-lottie.wxml'] = $gwx_XC_55( './uni_modules/c-lottie/components/c-lottie/c-lottie.wxml' );
	;__wxRoute = "uni_modules/c-lottie/components/c-lottie/c-lottie";__wxRouteBegin = true;__wxAppCurrentFile__="uni_modules/c-lottie/components/c-lottie/c-lottie.js";define("uni_modules/c-lottie/components/c-lottie/c-lottie.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["uni_modules/c-lottie/components/c-lottie/c-lottie"],{"0b12":function(t,e,n){"use strict";n.d(e,"b",(function(){return a})),n.d(e,"c",(function(){return o})),n.d(e,"a",(function(){}));var a=function(){this.$createElement;this._self._c},o=[]},"2cb2":function(t,e,n){},"9b1b":function(t,e,n){"use strict";n.r(e);var a=n("0b12"),o=n("a016");for(var i in o)["default"].indexOf(i)<0&&function(t){n.d(e,t,(function(){return o[t]}))}(i);n("e1cf");var r=n("828b"),c=Object(r.a)(o.default,a.b,a.c,!1,null,"1608924e",null,!1,a.a,void 0);e.default=c.exports},a016:function(t,e,n){"use strict";n.r(e);var a=n("e5a5"),o=n.n(a);for(var i in a)["default"].indexOf(i)<0&&function(t){n.d(e,t,(function(){return a[t]}))}(i);e.default=o.a},e1cf:function(t,e,n){"use strict";var a=n("2cb2");n.n(a).a},e5a5:function(t,e,n){"use strict";(function(t){var a=n("47a9");Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var o=a(n("7eb4")),i=a(n("af34")),r=a(n("ee10")),c=a(n("c817")),l=a(n("6eb4")),u={props:{canvasId:{type:String},width:{type:String,default:"750rpx"},height:{type:String,default:"750rpx"},src:{type:String},data:{type:String},autoPlay:{type:Boolean,default:!0},loop:{type:Boolean,default:!0},renderer:{type:String,default:"canvas"},isOnChange:{type:Boolean,default:!1}},emits:["Complete","LoopComplete","EnterFrame","SegmentStart","dataReady","dataFailed"],data:function(){return{fun:{}}},computed:{myCanvasId:function(){return this.canvasId?this.canvasId:"c"+(0,c.default)(18)},lottieData:function(){return{myCanvasId:this.myCanvasId,width:this.width,height:this.height,src:this.src,data:this.data,autoPlay:this.autoPlay,loop:this.loop,renderer:this.renderer,isOnChange:this.isOnChange}}},watch:{lottieData:function(){this.render()}},methods:{call:function(t,e){this.fun={name:t,args:e},this.callPlayer(this.fun)},getContext:function(){var e=this;return new Promise((function(n){var a=t.getSystemInfoSync().pixelRatio;t.createSelectorQuery().in(e).select("#".concat(e.myCanvasId)).fields({node:!0,size:!0}).exec((function(t){var e=t[0],o=e.width,i=e.height,r=t[0].node;n({canvas:r,width:o,height:i,pixelRatio:a})}))}))},render:function(){var t=this;return(0,r.default)(o.default.mark((function e(){var n,a,i,r,c;return o.default.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:return t.player&&t.call("destroy",t.player),e.next=3,t.getContext();case 3:n=e.sent,a=n.canvas,i=n.width,r=n.height,c=n.pixelRatio,t.myCanvas=a,t.context=a.getContext("2d"),t.context.scale(c,c),a.width=i*c,a.height=r*c,l.default.setup(t.myCanvas),t.player=l.default.loadAnimation({loop:t.loop,autoplay:t.autoPlay,animationData:t.data,path:t.src,rendererSettings:{context:t.context}}),t.player.addEventListener("data_ready",(function(e){t.$emit("dataReady",e)})),t.player.addEventListener("data_failed",(function(e){t.$emit("dataFailed",e)})),t.player.onComplete=function(e){t.$emit("Complete",e)},t.player.onLoopComplete=function(e){t.$emit("LoopComplete",e)},t.isOnChange&&(t.player.onEnterFrame=function(e){t.$emit("EnterFrame",e)}),t.player.onSegmentStart=function(e){t.$emit("SegmentStart",e)};case 21:case"end":return e.stop()}}),e)})))()},callPlayer:function(t){if(t.name){var e,n=t.name,a=t.args;Array.isArray(a)?(e=this.player)[n].apply(e,(0,i.default)(a)):this.player[n](a)}}},mounted:function(){this.render()},beforeDestroy:function(){this.call("destroy")}};e.default=u}).call(this,n("df3c").default)}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["uni_modules/c-lottie/components/c-lottie/c-lottie-create-component",{"uni_modules/c-lottie/components/c-lottie/c-lottie-create-component":function(t,e,n){n("df3c").createComponent(n("9b1b"))}},[["uni_modules/c-lottie/components/c-lottie/c-lottie-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'uni_modules/c-lottie/components/c-lottie/c-lottie.js'});require("uni_modules/c-lottie/components/c-lottie/c-lottie.js");