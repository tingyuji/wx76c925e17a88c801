$gwx_XC_21=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_21 || [];
function gz$gwx_XC_21_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_21_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_21_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_21_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'__e'])
Z([3,'__l'])
Z([3,'vue-ref'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^LoopComplete']],[[4],[[5],[[4],[[5],[1,'onLoopComplete']]]]]]]]])
Z([3,'cLottieRef'])
Z([3,'750rpx'])
Z([1,true])
Z([[7],[3,'src2']])
Z([3,'2d5f9d41-1'])
Z(z[5])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_21_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_21_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_21=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_21=true;
var x=['./pages/clock.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_21_1()
var t5D=_mz(z,'c-lottie',['bind:LoopComplete',0,'bind:__l',1,'class',1,'data-event-opts',2,'data-ref',3,'height',4,'loop',5,'src',6,'vueId',7,'width',8],[],e,s,gg)
_(r,t5D)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_21";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_21();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/clock.wxml'] = [$gwx_XC_21, './pages/clock.wxml'];else __wxAppCode__['pages/clock.wxml'] = $gwx_XC_21( './pages/clock.wxml' );
	;__wxRoute = "pages/clock";__wxRouteBegin = true;__wxAppCurrentFile__="pages/clock.js";define("pages/clock.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/clock"],{"47f2":function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0,t.default={data:function(){return{src:"https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/cry.json",src1:"https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/good.json",src2:"https://mp-eeab6da6-80cd-4e80-844a-66b2a7203834.cdn.bspapp.com/cloudstorage/7b538fb7-d2d5-4524-bf21-6c20e3b5ce6f.json",src3:"https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/excellent.json"}},methods:{onLoopComplete:function(e){}}}},"6b56":function(e,t,n){"use strict";n.r(t);var c=n("47f2"),o=n.n(c);for(var i in c)["default"].indexOf(i)<0&&function(e){n.d(t,e,(function(){return c[e]}))}(i);t.default=o.a},"7e5f":function(e,t,n){"use strict";n.r(t);var c=n("fd2c"),o=n("6b56");for(var i in o)["default"].indexOf(i)<0&&function(e){n.d(t,e,(function(){return o[e]}))}(i);n("d683");var s=n("828b"),r=Object(s.a)(o.default,c.b,c.c,!1,null,null,null,!1,c.a,void 0);t.default=r.exports},a2b6:function(e,t,n){},c5cb:function(e,t,n){"use strict";(function(e,t){var c=n("47a9");n("e465"),c(n("3240"));var o=c(n("7e5f"));e.__webpack_require_UNI_MP_PLUGIN__=n,t(o.default)}).call(this,n("3223").default,n("df3c").createPage)},d683:function(e,t,n){"use strict";var c=n("a2b6");n.n(c).a},fd2c:function(e,t,n){"use strict";n.d(t,"b",(function(){return o})),n.d(t,"c",(function(){return i})),n.d(t,"a",(function(){return c}));var c={cLottie:function(){return Promise.all([n.e("common/vendor"),n.e("uni_modules/c-lottie/components/c-lottie/c-lottie")]).then(n.bind(null,"9b1b"))}},o=function(){var e=this;e.$createElement;e._self._c,e._isMounted||(e.e0=function(t){e.src="https://mp-eeab6da6-80cd-4e80-844a-66b2a7203834.cdn.bspapp.com/cloudstorage/7b538fb7-d2d5-4524-bf21-6c20e3b5ce6f.json"},e.e1=function(t){e.src="https://mp-eeab6da6-80cd-4e80-844a-66b2a7203834.cdn.bspapp.com/cloudstorage/c42b5f05-06b9-43e7-8436-c1029eee610a.json"},e.e2=function(e){return this.$refs.cLottieRef.call("play")},e.e3=function(e){return this.$refs.cLottieRef.call("setDirection",-1)},e.e4=function(e){return this.$refs.cLottieRef.call("pause")},e.e5=function(e){return this.$refs.cLottieRef.call("stop")},e.e6=function(e){return this.$refs.cLottieRef.call("setSpeed",1)},e.e7=function(e){return this.$refs.cLottieRef.call("setSpeed",2)},e.e8=function(e){return this.$refs.cLottieRef.call("goToAndStop",[2e3,!1])},e.e9=function(e){return this.$refs.cLottieRef.call("goToAndPlay",[2e3,!1])},e.e10=function(e){return this.$refs.cLottieRef.call("goToAndStop",[2,!0])},e.e11=function(e){return this.$refs.cLottieRef.call("goToAndPlay",[2,!0])},e.e12=function(e){return this.$refs.cLottieRef.call("playSegments",[[10,20],!1])},e.e13=function(e){return this.$refs.cLottieRef.call("playSegments",[[[0,5],[10,18]],!0])})},i=[]}},[["c5cb","common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/clock.js'});require("pages/clock.js");