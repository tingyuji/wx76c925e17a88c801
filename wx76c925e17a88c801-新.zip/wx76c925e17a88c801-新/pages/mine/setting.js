(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/setting" ], {
    "0318": function(e, n, t) {},
    "077e": function(e, n, t) {
        "use strict";
        var i = t("0318");
        t.n(i).a;
    },
    3210: function(e, n, t) {
        "use strict";
        t.r(n);
        var i = t("987e"), o = t.n(i);
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(n, e, function() {
                return i[e];
            });
        }(a);
        n.default = o.a;
    },
    "3b80": function(e, n, t) {
        "use strict";
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return a;
        }), t.d(n, "a", function() {
            return i;
        });
        var i = {
            pageLoading: function() {
                return t.e("components/pageLoading/pageLoading").then(t.bind(null, "7f33"));
            },
            mPopup: function() {
                return t.e("components/mPopup/mPopup").then(t.bind(null, "ae6f"));
            },
            mPicker: function() {
                return t.e("components/mPicker/mPicker").then(t.bind(null, "e94f"));
            },
            mModal: function() {
                return t.e("components/mModal/mModal").then(t.bind(null, "68ea"));
            },
            slotModal: function() {
                return t.e("components/slotModal/slotModal").then(t.bind(null, "8d9e"));
            }
        }, o = function() {
            var e = this, n = (e.$createElement, e._self._c, encodeURIComponent(e.agreement.user.value)), t = encodeURIComponent(e.agreement.privacy.value);
            e._isMounted || (e.e0 = function(n) {
                return e.$refs.mPicker.show();
            }, e.e1 = function(n, t) {
                var i = arguments[arguments.length - 1].currentTarget.dataset, o = i.eventParams || i["event-params"];
                t = o.child, e.goPage("/pages/mine/editChild?child=" + encodeURIComponent(JSON.stringify(t)));
            }, e.e2 = function(n) {
                return e.$refs.mModal.show();
            }, e.e3 = function(n) {
                e.nameFocus = !1;
            }, e.e4 = function(n) {
                return e.$refs.appUpload.hide();
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    m0: n,
                    m1: t
                }
            });
        }, a = [];
    },
    "987e": function(e, n, t) {
        "use strict";
        (function(e, i) {
            var o = t("47a9");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var a = o(t("7ca3")), r = {
                data: function() {
                    return {
                        userInfo: {},
                        editCell: "",
                        relationArr: [ {
                            name: "妈妈"
                        }, {
                            name: "爸爸"
                        }, {
                            name: "爷爷"
                        }, {
                            name: "奶奶"
                        }, {
                            name: "外公"
                        }, {
                            name: "外婆"
                        }, {
                            name: "亲人"
                        } ],
                        selIndex: 0,
                        childArr: [],
                        nameFocus: !1,
                        agreement: {
                            privacy: {},
                            user: {}
                        },
                        version: "",
                        updateData: {
                            latest_version: "",
                            description: "",
                            force_update: 0,
                            download_url: ""
                        }
                    };
                },
                onLoad: function(n) {
                    var t = this;
                    n.userInfo && (this.userInfo = JSON.parse(decodeURIComponent(n.userInfo))), this.relationArr.filter(function(e, n) {
                        e.name == t.userInfo.standing && (t.selIndex = n);
                    }), this.getChildList(), this.init(), e.$on("change_child_info", function(e) {
                        t.getChildList();
                    });
                },
                methods: {
                    init: function() {
                        var e = this;
                        this.$api.commonApi.configurations({
                            key: "app_auth"
                        }, !1, this).then(function(n) {
                            e.agreement = n.data.app_auth;
                        });
                    },
                    getChildList: function() {
                        var e = this;
                        this.$api.commonApi.childrenList({
                            is_my: 1
                        }, !0, this).then(function(n) {
                            e.childArr = n.data;
                        });
                    },
                    change: function(e) {
                        this.editCell = e, this.$refs.mPopup.show(), this.nameFocus = !0;
                    },
                    mPopupSubmit: function() {
                        var e = this;
                        if ("mobile" == this.editCell && !this.$util.checkPhoneNumber(this.userInfo.mobile)) return this.$util.msg("请输入正确的手机号");
                        this.userInfo[this.editCell] = this.userInfo[this.editCell].trim(), this.$api.commonApi.setting(this.userInfo.id, (0, 
                        a.default)({}, this.editCell, this.userInfo[this.editCell]), !0, this).then(function(n) {
                            e.$util.msg("修改成功"), e.$refs.mPopup.hide();
                        });
                    },
                    mPickerSubmit: function(e) {
                        var n = this;
                        -1 != this.userInfo.nickname.indexOf(this.userInfo.standing) && (this.userInfo.nickname = this.userInfo.nickname.replace(this.userInfo.standing, this.relationArr[e].name), 
                        this.editCell = "nickname", this.mPopupSubmit()), this.$api.commonApi.setting(this.userInfo.id, {
                            standing: this.relationArr[e].name
                        }, !0, this).then(function(t) {
                            n.$util.msg("修改成功"), n.userInfo.standing = n.relationArr[e].name;
                        });
                    },
                    decryptPhoneNumber: function(e) {
                        var n = this;
                        e.detail.code ? this.$api.commonApi.bindPhone({
                            phone_code: e.detail.code
                        }, !0, this).then(function(e) {
                            n.getUserInfo();
                        }) : this.$util.msg("授权失败");
                    },
                    getUserInfo: function() {
                        var n = this;
                        this.$api.commonApi.userInfo({}, !0, this).then(function(t) {
                            n.$util.msg("修改成功"), n.userInfo = t.data, e.setStorageSync("userInfo", t.data);
                        });
                    },
                    signOut: function() {
                        var n = this;
                        this.$api.commonApi.signOut(this.userInfo.id, {}, !0, this).then(function(t) {
                            var i = e.getStorageSync("oldUser");
                            e.clearStorageSync(), e.setStorageSync("oldUser", i), n.$refs.mModal2.show();
                        });
                    },
                    reLogin: function() {
                        var n = this;
                        e.login({
                            provider: "weixin",
                            success: function(t) {
                                n.$api.commonApi.silentLogin({
                                    driver: "weChat",
                                    code: t.code
                                }, !0, n).then(function(n) {
                                    e.setStorageSync("token", n.data.token), e.setStorageSync("userInfo", n.data.user), 
                                    n.data.user.last_child_id && e.setStorageSync("child_id", n.data.user.last_child_id), 
                                    e.reLaunch({
                                        url: "/pages/index"
                                    });
                                });
                            }
                        });
                    },
                    closeMini: function() {
                        i.exitMiniProgram();
                    },
                    loginOut: function() {
                        var n = e.getStorageSync("oldUser");
                        e.clearStorageSync(), e.setStorageSync("oldUser", n), e.reLaunch({
                            url: "/pages/login/login"
                        });
                    },
                    checkUpdate: function() {
                        var n = this;
                        this.$api.commonApi.app_version({}, !1, this).then(function(t) {
                            n.updateData.latest_version = t.data.version, n.updateData.description = t.data.description, 
                            n.updateData.download_url = t.data.download_url, Number(e.getAppBaseInfo().appWgtVersion.replace(/\./g, "")) < Number(t.data.version.replace(/\./g, "")) ? n.$refs.appUpload.show() : n.$util.msg("已是最新版本");
                        });
                    },
                    updateApp: function() {
                        this.$util.updateApp(this);
                    }
                }
            };
            n.default = r;
        }).call(this, t("df3c").default, t("3223").default);
    },
    a934: function(e, n, t) {
        "use strict";
        (function(e, n) {
            var i = t("47a9");
            t("e465"), i(t("3240"));
            var o = i(t("d5b7"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(o.default);
        }).call(this, t("3223").default, t("df3c").createPage);
    },
    d5b7: function(e, n, t) {
        "use strict";
        t.r(n);
        var i = t("3b80"), o = t("3210");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(a);
        t("077e");
        var r = t("828b"), s = Object(r.a)(o.default, i.b, i.c, !1, null, "f6657d32", null, !1, i.a, void 0);
        n.default = s.exports;
    }
}, [ [ "a934", "common/runtime", "common/vendor" ] ] ]);