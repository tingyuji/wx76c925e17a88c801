(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/print" ], {
    "31b7": function(n, t, e) {
        "use strict";
        var i = e("4da0");
        e.n(i).a;
    },
    3627: function(n, t, e) {
        "use strict";
        e.r(t);
        var i = e("6fe3"), a = e("635a");
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(o);
        e("31b7");
        var u = e("828b"), c = Object(u.a)(a.default, i.b, i.c, !1, null, "02ff98a1", null, !1, i.a, void 0);
        t.default = c.exports;
    },
    "4da0": function(n, t, e) {},
    "635a": function(n, t, e) {
        "use strict";
        e.r(t);
        var i = e("65f9"), a = e.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(n) {
            e.d(t, n, function() {
                return i[n];
            });
        }(o);
        t.default = a.a;
    },
    "65f9": function(n, t, e) {
        "use strict";
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var e = {
                data: function() {
                    return {
                        loadingText: "图片生成中,请耐心等待~",
                        currentTab: 0,
                        tabArr: [ {
                            name: "目标清单",
                            value: 0,
                            img: ""
                        }, {
                            name: "星愿清单",
                            value: 1,
                            img: ""
                        } ]
                    };
                },
                onLoad: function() {
                    this.getData();
                },
                methods: {
                    getData: function() {
                        var t = this;
                        this.loadingShow = !0, Promise.all([ new Promise(function(e, i) {
                            t.$api.wishApi.prizePrint({
                                child_id: n.getStorageSync("child_id")
                            }, !1, t).then(function(n) {
                                t.tabArr[1].img = n.data.image, e();
                            });
                        }), new Promise(function(e, i) {
                            t.$api.behaviorsApi.behaviorPrint({
                                child_id: n.getStorageSync("child_id")
                            }, !1, t).then(function(n) {
                                t.tabArr[0].img = n.data.image, e();
                            });
                        }) ]).then(function(n) {
                            t.loadingShow = !1;
                        });
                    },
                    checkMenu: function(n) {
                        this.currentTab = n.value;
                    },
                    saveImg: function() {
                        var t = this, e = this;
                        this.loadingText = "", this.loadingShow = !0, n.downloadFile({
                            url: this.tabArr[this.currentTab].img,
                            success: function(i) {
                                200 === i.statusCode && (t.loadingShow = !1, n.saveImageToPhotosAlbum({
                                    filePath: i.tempFilePath,
                                    success: function() {
                                        e.$util.msg("保存成功");
                                    }
                                }));
                            }
                        });
                    }
                }
            };
            t.default = e;
        }).call(this, e("df3c").default);
    },
    "6fe3": function(n, t, e) {
        "use strict";
        e.d(t, "b", function() {
            return a;
        }), e.d(t, "c", function() {
            return o;
        }), e.d(t, "a", function() {
            return i;
        });
        var i = {
            pageLoading: function() {
                return e.e("components/pageLoading/pageLoading").then(e.bind(null, "7f33"));
            },
            mButton: function() {
                return e.e("components/mButton/mButton").then(e.bind(null, "fac5"));
            }
        }, a = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    bc1e: function(n, t, e) {
        "use strict";
        (function(n, t) {
            var i = e("47a9");
            e("e465"), i(e("3240"));
            var a = i(e("3627"));
            n.__webpack_require_UNI_MP_PLUGIN__ = e, t(a.default);
        }).call(this, e("3223").default, e("df3c").createPage);
    }
}, [ [ "bc1e", "common/runtime", "common/vendor" ] ] ]);