(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/familyInvite" ], {
    5388: function(n, e, t) {
        "use strict";
        (function(n) {
            var a = t("47a9");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = a(t("7eb4")), o = a(t("7ca3")), r = a(t("ee10")), c = {
                data: function() {
                    return {
                        salt: "",
                        standinged: [],
                        nickname: "",
                        relationArr: [ "妈妈", "爸爸", "爷爷", "奶奶", "外公", "外婆", "亲人" ],
                        param: {
                            standing: ""
                        },
                        goHomeStatus: !1,
                        btnData: {
                            type: 1,
                            fromApp: !1
                        }
                    };
                },
                onLoad: function(e) {
                    var t = this;
                    return (0, r.default)(i.default.mark(function a() {
                        return i.default.wrap(function(a) {
                            for (;;) switch (a.prev = a.next) {
                              case 0:
                                return n.removeStorageSync("userInfo"), a.next = 3, t.$onLaunched;

                              case 3:
                                if (n.getStorageSync("goHome") && (t.goHomeStatus = !0), n.removeStorageSync("goHome"), 
                                !t.goHomeStatus) {
                                    a.next = 7;
                                    break;
                                }
                                return a.abrupt("return", t.goHome());

                              case 7:
                                if (!n.getStorageSync("userInfo")) {
                                    a.next = 9;
                                    break;
                                }
                                return a.abrupt("return", n.reLaunch({
                                    url: "/pages/index"
                                }));

                              case 9:
                                t.$nextTick(function() {
                                    getApp().globalData.fromApp && (t.btnData.fromApp = !0), n.getStorageSync("userInfo").mobile && (t.btnData.mobile = !0);
                                }), e.salt && (t.salt = e.salt), e.standinged && (t.standinged = JSON.parse(decodeURIComponent(e.standinged))), 
                                e.nickname && (t.nickname = e.nickname), t.param.standing = t.relationArr.filter(function(n) {
                                    return !t.standinged.includes(n);
                                })[0];

                              case 14:
                              case "end":
                                return a.stop();
                            }
                        }, a);
                    }))();
                },
                methods: (0, o.default)({
                    selectStanding: function(n) {
                        this.standinged.includes(n) || (this.param.standing = n);
                    },
                    decryptPhoneNumber: function(n) {
                        var e = this;
                        n.detail.code ? this.$api.commonApi.bindPhone({
                            phone_code: n.detail.code
                        }, !0, this).then(function(n) {
                            e.acceptInvite();
                        }) : this.$util.msg("授权失败");
                    },
                    acceptInvite: function() {
                        if (this.btnData.type = 1, !getApp().globalData.fromApp) {
                            var e = this;
                            e.loadingShow = !0, n.login({
                                provider: "weixin",
                                success: function(t) {
                                    e.$api.commonApi.silentLogin({
                                        driver: "weChat",
                                        code: t.code,
                                        salt: e.salt,
                                        nickname: e.param.standing,
                                        standing: e.param.standing
                                    }, !1, e).then(function(t) {
                                        e.loadingShow = !1, n.setStorageSync("token", t.data.token), n.setStorageSync("userInfo", t.data.user), 
                                        t.data.user.last_child_id && n.setStorageSync("child_id", t.data.user.last_child_id), 
                                        n.reLaunch({
                                            url: "/pages/index"
                                        });
                                    });
                                }
                            });
                        }
                    },
                    goHome: function() {
                        if (this.btnData.type = 2, !getApp().globalData.fromApp) {
                            var e = this;
                            e.loadingShow = !0, n.login({
                                provider: "weixin",
                                success: function(t) {
                                    e.$api.commonApi.silentLogin({
                                        driver: "weChat",
                                        code: t.code
                                    }, !1, e).then(function(t) {
                                        e.loadingShow = !1, n.setStorageSync("token", t.data.token), n.setStorageSync("userInfo", t.data.user), 
                                        t.data.user.last_child_id && n.setStorageSync("child_id", t.data.user.last_child_id), 
                                        n.reLaunch({
                                            url: "/pages/index"
                                        });
                                    });
                                }
                            });
                        }
                    }
                }, "decryptPhoneNumber", function(e) {
                    if (e.detail.code) {
                        var t = this;
                        t.loadingShow = !0, n.login({
                            provider: "weixin",
                            success: function(a) {
                                var i;
                                1 == t.btnData.type ? i = {
                                    driver: "phone",
                                    code: a.code,
                                    phone_code: e.detail.code,
                                    salt: t.salt,
                                    nickname: t.param.standing,
                                    standing: t.param.standing
                                } : 2 == t.btnData.type && (i = {
                                    driver: "phone",
                                    code: a.code,
                                    phone_code: e.detail.code
                                }), t.$api.commonApi.silentLogin(i, !1, t).then(function(e) {
                                    t.loadingShow = !1, n.setStorageSync("token", e.data.token), n.setStorageSync("userInfo", e.data.user), 
                                    e.data.user.last_child_id && n.setStorageSync("child_id", e.data.user.last_child_id), 
                                    n.reLaunch({
                                        url: "/pages/index"
                                    });
                                }).catch(function(n) {
                                    t.loadingShow = !1;
                                });
                            }
                        });
                    } else this.$util.msg("授权失败");
                })
            };
            e.default = c;
        }).call(this, t("df3c").default);
    },
    "7b38": function(n, e, t) {
        "use strict";
        t.r(e);
        var a = t("86fc"), i = t("9778");
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(n) {
            t.d(e, n, function() {
                return i[n];
            });
        }(o);
        t("7df3");
        var r = t("828b"), c = Object(r.a)(i.default, a.b, a.c, !1, null, "01cdcc1e", null, !1, a.a, void 0);
        e.default = c.exports;
    },
    "7df3": function(n, e, t) {
        "use strict";
        var a = t("e400");
        t.n(a).a;
    },
    "86fc": function(n, e, t) {
        "use strict";
        t.d(e, "b", function() {
            return i;
        }), t.d(e, "c", function() {
            return o;
        }), t.d(e, "a", function() {
            return a;
        });
        var a = {
            pageLoading: function() {
                return t.e("components/pageLoading/pageLoading").then(t.bind(null, "7f33"));
            },
            mButton: function() {
                return t.e("components/mButton/mButton").then(t.bind(null, "fac5"));
            }
        }, i = function() {
            var n = this, e = (n.$createElement, n._self._c, n.__map(n.relationArr, function(e, t) {
                return {
                    $orig: n.__get_orig(e),
                    g0: n.standinged.includes(e)
                };
            }));
            n.$mp.data = Object.assign({}, {
                $root: {
                    l0: e
                }
            });
        }, o = [];
    },
    9778: function(n, e, t) {
        "use strict";
        t.r(e);
        var a = t("5388"), i = t.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(o);
        e.default = i.a;
    },
    b49e: function(n, e, t) {
        "use strict";
        (function(n, e) {
            var a = t("47a9");
            t("e465"), a(t("3240"));
            var i = a(t("7b38"));
            n.__webpack_require_UNI_MP_PLUGIN__ = t, e(i.default);
        }).call(this, t("3223").default, t("df3c").createPage);
    },
    e400: function(n, e, t) {}
}, [ [ "b49e", "common/runtime", "common/vendor" ] ] ]);