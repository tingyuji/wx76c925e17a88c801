$gwx_XC_38=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_38 || [];
function gz$gwx_XC_38_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_38_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_38_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_38_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'content data-v-f6657d32'])
Z([3,'__l'])
Z([3,'data-v-f6657d32'])
Z([[7],[3,'loadingShow']])
Z([3,'64dd5b19-1'])
Z(z[1])
Z([3,'__e'])
Z(z[6])
Z([3,'data-v-f6657d32 vue-ref'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^submit']],[[4],[[5],[[4],[[5],[1,'mPopupSubmit']]]]]]]],[[4],[[5],[[5],[1,'^hide']],[[4],[[5],[[4],[[5],[1,'e3']]]]]]]]])
Z([3,'mPopup'])
Z([3,'64dd5b19-2'])
Z([[4],[[5],[1,'default']]])
Z([3,'input-wrap data-v-f6657d32'])
Z([[2,'=='],[[7],[3,'editCell']],[1,'mobile']])
Z([[2,'=='],[[7],[3,'editCell']],[1,'nickname']])
Z(z[1])
Z(z[6])
Z(z[8])
Z([[4],[[5],[[4],[[5],[[5],[1,'^submit']],[[4],[[5],[[4],[[5],[1,'mPickerSubmit']]]]]]]]])
Z([3,'mPicker'])
Z([[7],[3,'relationArr']])
Z([[7],[3,'selIndex']])
Z([3,'64dd5b19-3'])
Z(z[1])
Z(z[6])
Z(z[8])
Z([3,'注销'])
Z([3,'确定注销该账户并清空宝贝的所有数据，注销后不可恢复？'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^submit']],[[4],[[5],[[4],[[5],[1,'signOut']]]]]]]]])
Z([3,'mModal'])
Z([3,'提示'])
Z([3,'64dd5b19-4'])
Z(z[1])
Z(z[6])
Z(z[6])
Z([3,'退出'])
Z(z[8])
Z([3,'重新创建'])
Z([3,'注销成功'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^submit']],[[4],[[5],[[4],[[5],[1,'reLogin']]]]]]]],[[4],[[5],[[5],[1,'^cancal']],[[4],[[5],[[4],[[5],[1,'closeMini']]]]]]]]])
Z([3,'mModal2'])
Z(z[31])
Z([3,'64dd5b19-5'])
Z(z[1])
Z(z[8])
Z([3,'appUpload'])
Z([1,false])
Z([3,'64dd5b19-6'])
Z(z[12])
Z([[2,'!'],[[6],[[7],[3,'updateData']],[3,'force_update']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_38_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_38_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_38=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_38=true;
var x=['./pages/mine/setting.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_38_1()
var cMK=_n('view')
_rz(z,cMK,'class',0,e,s,gg)
var oNK=_mz(z,'page-loading',['bind:__l',1,'class',1,'loadingShow_',2,'vueId',3],[],e,s,gg)
_(cMK,oNK)
var lOK=_mz(z,'m-popup',['bind:__l',5,'bind:hide',1,'bind:submit',2,'class',3,'data-event-opts',4,'data-ref',5,'vueId',6,'vueSlots',7],[],e,s,gg)
var aPK=_n('view')
_rz(z,aPK,'class',13,e,s,gg)
var tQK=_v()
_(aPK,tQK)
if(_oz(z,14,e,s,gg)){tQK.wxVkey=1
}
var eRK=_v()
_(aPK,eRK)
if(_oz(z,15,e,s,gg)){eRK.wxVkey=1
}
tQK.wxXCkey=1
eRK.wxXCkey=1
_(lOK,aPK)
_(cMK,lOK)
var bSK=_mz(z,'m-picker',['bind:__l',16,'bind:submit',1,'class',2,'data-event-opts',3,'data-ref',4,'list',5,'selIndex',6,'vueId',7],[],e,s,gg)
_(cMK,bSK)
var oTK=_mz(z,'m-modal',['bind:__l',24,'bind:submit',1,'class',2,'confirmText',3,'content',4,'data-event-opts',5,'data-ref',6,'title',7,'vueId',8],[],e,s,gg)
_(cMK,oTK)
var xUK=_mz(z,'m-modal',['bind:__l',33,'bind:cancal',1,'bind:submit',2,'cancalText',3,'class',4,'confirmText',5,'content',6,'data-event-opts',7,'data-ref',8,'title',9,'vueId',10],[],e,s,gg)
_(cMK,xUK)
var oVK=_mz(z,'slot-modal',['bind:__l',44,'class',1,'data-ref',2,'maskClose',3,'vueId',4,'vueSlots',5],[],e,s,gg)
var fWK=_v()
_(oVK,fWK)
if(_oz(z,50,e,s,gg)){fWK.wxVkey=1
}
fWK.wxXCkey=1
_(cMK,oVK)
_(r,cMK)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_38";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_38();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/mine/setting.wxml'] = [$gwx_XC_38, './pages/mine/setting.wxml'];else __wxAppCode__['pages/mine/setting.wxml'] = $gwx_XC_38( './pages/mine/setting.wxml' );
	;__wxRoute = "pages/mine/setting";__wxRouteBegin = true;__wxAppCurrentFile__="pages/mine/setting.js";define("pages/mine/setting.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/mine/setting"],{"0318":function(e,n,t){},"077e":function(e,n,t){"use strict";var i=t("0318");t.n(i).a},3210:function(e,n,t){"use strict";t.r(n);var i=t("987e"),o=t.n(i);for(var a in i)["default"].indexOf(a)<0&&function(e){t.d(n,e,(function(){return i[e]}))}(a);n.default=o.a},"3b80":function(e,n,t){"use strict";t.d(n,"b",(function(){return o})),t.d(n,"c",(function(){return a})),t.d(n,"a",(function(){return i}));var i={pageLoading:function(){return t.e("components/pageLoading/pageLoading").then(t.bind(null,"7f33"))},mPopup:function(){return t.e("components/mPopup/mPopup").then(t.bind(null,"ae6f"))},mPicker:function(){return t.e("components/mPicker/mPicker").then(t.bind(null,"e94f"))},mModal:function(){return t.e("components/mModal/mModal").then(t.bind(null,"68ea"))},slotModal:function(){return t.e("components/slotModal/slotModal").then(t.bind(null,"8d9e"))}},o=function(){var e=this,n=(e.$createElement,e._self._c,encodeURIComponent(e.agreement.user.value)),t=encodeURIComponent(e.agreement.privacy.value);e._isMounted||(e.e0=function(n){return e.$refs.mPicker.show()},e.e1=function(n,t){var i=arguments[arguments.length-1].currentTarget.dataset,o=i.eventParams||i["event-params"];t=o.child,e.goPage("/pages/mine/editChild?child="+encodeURIComponent(JSON.stringify(t)))},e.e2=function(n){return e.$refs.mModal.show()},e.e3=function(n){e.nameFocus=!1},e.e4=function(n){return e.$refs.appUpload.hide()}),e.$mp.data=Object.assign({},{$root:{m0:n,m1:t}})},a=[]},"987e":function(e,n,t){"use strict";(function(e,i){var o=t("47a9");Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a=o(t("7ca3")),r={data:function(){return{userInfo:{},editCell:"",relationArr:[{name:"妈妈"},{name:"爸爸"},{name:"爷爷"},{name:"奶奶"},{name:"外公"},{name:"外婆"},{name:"亲人"}],selIndex:0,childArr:[],nameFocus:!1,agreement:{privacy:{},user:{}},version:"",updateData:{latest_version:"",description:"",force_update:0,download_url:""}}},onLoad:function(n){var t=this;n.userInfo&&(this.userInfo=JSON.parse(decodeURIComponent(n.userInfo))),this.relationArr.filter((function(e,n){e.name==t.userInfo.standing&&(t.selIndex=n)})),this.getChildList(),this.init(),e.$on("change_child_info",(function(e){t.getChildList()}))},methods:{init:function(){var e=this;this.$api.commonApi.configurations({key:"app_auth"},!1,this).then((function(n){e.agreement=n.data.app_auth}))},getChildList:function(){var e=this;this.$api.commonApi.childrenList({is_my:1},!0,this).then((function(n){e.childArr=n.data}))},change:function(e){this.editCell=e,this.$refs.mPopup.show(),this.nameFocus=!0},mPopupSubmit:function(){var e=this;if("mobile"==this.editCell&&!this.$util.checkPhoneNumber(this.userInfo.mobile))return this.$util.msg("请输入正确的手机号");this.userInfo[this.editCell]=this.userInfo[this.editCell].trim(),this.$api.commonApi.setting(this.userInfo.id,(0,a.default)({},this.editCell,this.userInfo[this.editCell]),!0,this).then((function(n){e.$util.msg("修改成功"),e.$refs.mPopup.hide()}))},mPickerSubmit:function(e){var n=this;-1!=this.userInfo.nickname.indexOf(this.userInfo.standing)&&(this.userInfo.nickname=this.userInfo.nickname.replace(this.userInfo.standing,this.relationArr[e].name),this.editCell="nickname",this.mPopupSubmit()),this.$api.commonApi.setting(this.userInfo.id,{standing:this.relationArr[e].name},!0,this).then((function(t){n.$util.msg("修改成功"),n.userInfo.standing=n.relationArr[e].name}))},decryptPhoneNumber:function(e){var n=this;e.detail.code?this.$api.commonApi.bindPhone({phone_code:e.detail.code},!0,this).then((function(e){n.getUserInfo()})):this.$util.msg("授权失败")},getUserInfo:function(){var n=this;this.$api.commonApi.userInfo({},!0,this).then((function(t){n.$util.msg("修改成功"),n.userInfo=t.data,e.setStorageSync("userInfo",t.data)}))},signOut:function(){var n=this;this.$api.commonApi.signOut(this.userInfo.id,{},!0,this).then((function(t){var i=e.getStorageSync("oldUser");e.clearStorageSync(),e.setStorageSync("oldUser",i),n.$refs.mModal2.show()}))},reLogin:function(){var n=this;e.login({provider:"weixin",success:function(t){n.$api.commonApi.silentLogin({driver:"weChat",code:t.code},!0,n).then((function(n){e.setStorageSync("token",n.data.token),e.setStorageSync("userInfo",n.data.user),n.data.user.last_child_id&&e.setStorageSync("child_id",n.data.user.last_child_id),e.reLaunch({url:"/pages/index"})}))}})},closeMini:function(){i.exitMiniProgram()},loginOut:function(){var n=e.getStorageSync("oldUser");e.clearStorageSync(),e.setStorageSync("oldUser",n),e.reLaunch({url:"/pages/login/login"})},checkUpdate:function(){var n=this;this.$api.commonApi.app_version({},!1,this).then((function(t){n.updateData.latest_version=t.data.version,n.updateData.description=t.data.description,n.updateData.download_url=t.data.download_url,Number(e.getAppBaseInfo().appWgtVersion.replace(/\./g,""))<Number(t.data.version.replace(/\./g,""))?n.$refs.appUpload.show():n.$util.msg("已是最新版本")}))},updateApp:function(){this.$util.updateApp(this)}}};n.default=r}).call(this,t("df3c").default,t("3223").default)},a934:function(e,n,t){"use strict";(function(e,n){var i=t("47a9");t("e465"),i(t("3240"));var o=i(t("d5b7"));e.__webpack_require_UNI_MP_PLUGIN__=t,n(o.default)}).call(this,t("3223").default,t("df3c").createPage)},d5b7:function(e,n,t){"use strict";t.r(n);var i=t("3b80"),o=t("3210");for(var a in o)["default"].indexOf(a)<0&&function(e){t.d(n,e,(function(){return o[e]}))}(a);t("077e");var r=t("828b"),s=Object(r.a)(o.default,i.b,i.c,!1,null,"f6657d32",null,!1,i.a,void 0);n.default=s.exports}},[["a934","common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/mine/setting.js'});require("pages/mine/setting.js");