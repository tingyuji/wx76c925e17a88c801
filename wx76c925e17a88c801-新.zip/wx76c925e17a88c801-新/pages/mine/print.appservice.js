$gwx_XC_37=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_37 || [];
function gz$gwx_XC_37_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_37_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_37_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_37_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'fix-content data-v-02ff98a1'])
Z([3,'__l'])
Z([3,'data-v-02ff98a1'])
Z([[7],[3,'loadingShow']])
Z([[7],[3,'loadingText']])
Z([3,'0ab92b9c-1'])
Z(z[1])
Z([3,'__e'])
Z(z[2])
Z([[4],[[5],[[4],[[5],[[5],[1,'^submit']],[[4],[[5],[[4],[[5],[1,'saveImg']]]]]]]]])
Z([3,'下载'])
Z([3,'0ab92b9c-2'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_37_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_37_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_37=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_37=true;
var x=['./pages/mine/print.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_37_1()
var fIK=_n('view')
_rz(z,fIK,'class',0,e,s,gg)
var cJK=_mz(z,'page-loading',['bind:__l',1,'class',1,'loadingShow_',2,'text',3,'vueId',4],[],e,s,gg)
_(fIK,cJK)
var hKK=_mz(z,'m-button',['bind:__l',6,'bind:submit',1,'class',2,'data-event-opts',3,'text',4,'vueId',5],[],e,s,gg)
_(fIK,hKK)
_(r,fIK)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_37";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_37();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/mine/print.wxml'] = [$gwx_XC_37, './pages/mine/print.wxml'];else __wxAppCode__['pages/mine/print.wxml'] = $gwx_XC_37( './pages/mine/print.wxml' );
	;__wxRoute = "pages/mine/print";__wxRouteBegin = true;__wxAppCurrentFile__="pages/mine/print.js";define("pages/mine/print.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/mine/print"],{"31b7":function(n,t,e){"use strict";var i=e("4da0");e.n(i).a},3627:function(n,t,e){"use strict";e.r(t);var i=e("6fe3"),a=e("635a");for(var o in a)["default"].indexOf(o)<0&&function(n){e.d(t,n,(function(){return a[n]}))}(o);e("31b7");var u=e("828b"),c=Object(u.a)(a.default,i.b,i.c,!1,null,"02ff98a1",null,!1,i.a,void 0);t.default=c.exports},"4da0":function(n,t,e){},"635a":function(n,t,e){"use strict";e.r(t);var i=e("65f9"),a=e.n(i);for(var o in i)["default"].indexOf(o)<0&&function(n){e.d(t,n,(function(){return i[n]}))}(o);t.default=a.a},"65f9":function(n,t,e){"use strict";(function(n){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var e={data:function(){return{loadingText:"图片生成中,请耐心等待~",currentTab:0,tabArr:[{name:"目标清单",value:0,img:""},{name:"星愿清单",value:1,img:""}]}},onLoad:function(){this.getData()},methods:{getData:function(){var t=this;this.loadingShow=!0,Promise.all([new Promise((function(e,i){t.$api.wishApi.prizePrint({child_id:n.getStorageSync("child_id")},!1,t).then((function(n){t.tabArr[1].img=n.data.image,e()}))})),new Promise((function(e,i){t.$api.behaviorsApi.behaviorPrint({child_id:n.getStorageSync("child_id")},!1,t).then((function(n){t.tabArr[0].img=n.data.image,e()}))}))]).then((function(n){t.loadingShow=!1}))},checkMenu:function(n){this.currentTab=n.value},saveImg:function(){var t=this,e=this;this.loadingText="",this.loadingShow=!0,n.downloadFile({url:this.tabArr[this.currentTab].img,success:function(i){200===i.statusCode&&(t.loadingShow=!1,n.saveImageToPhotosAlbum({filePath:i.tempFilePath,success:function(){e.$util.msg("保存成功")}}))}})}}};t.default=e}).call(this,e("df3c").default)},"6fe3":function(n,t,e){"use strict";e.d(t,"b",(function(){return a})),e.d(t,"c",(function(){return o})),e.d(t,"a",(function(){return i}));var i={pageLoading:function(){return e.e("components/pageLoading/pageLoading").then(e.bind(null,"7f33"))},mButton:function(){return e.e("components/mButton/mButton").then(e.bind(null,"fac5"))}},a=function(){this.$createElement;this._self._c},o=[]},bc1e:function(n,t,e){"use strict";(function(n,t){var i=e("47a9");e("e465"),i(e("3240"));var a=i(e("3627"));n.__webpack_require_UNI_MP_PLUGIN__=e,t(a.default)}).call(this,e("3223").default,e("df3c").createPage)}},[["bc1e","common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/mine/print.js'});require("pages/mine/print.js");