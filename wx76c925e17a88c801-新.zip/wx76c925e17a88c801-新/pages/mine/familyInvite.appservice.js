$gwx_XC_36=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_36 || [];
function gz$gwx_XC_36_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_36_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_36_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_36_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'fix-content data-v-01cdcc1e'])
Z([3,'__l'])
Z([3,'data-v-01cdcc1e'])
Z([[7],[3,'loadingShow']])
Z([3,'46dba4e6-1'])
Z([3,'card flex-column flex-align-center data-v-01cdcc1e'])
Z([3,'__e'])
Z([3,'btn-wrap data-v-01cdcc1e'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'acceptInvite']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[1])
Z(z[2])
Z([3,'接受邀请'])
Z([3,'46dba4e6-2'])
Z([[6],[[7],[3,'btnData']],[3,'fromApp']])
Z(z[6])
Z(z[7])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'goHome']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'margin-top:50rpx;'])
Z([3,'#fff'])
Z(z[1])
Z(z[2])
Z([3,'去首页'])
Z([3,'#765DF4'])
Z([3,'46dba4e6-3'])
Z(z[13])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_36_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_36_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_36=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_36=true;
var x=['./pages/mine/familyInvite.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_36_1()
var c9J=_n('view')
_rz(z,c9J,'class',0,e,s,gg)
var o0J=_mz(z,'page-loading',['bind:__l',1,'class',1,'loadingShow_',2,'vueId',3],[],e,s,gg)
_(c9J,o0J)
var lAK=_n('view')
_rz(z,lAK,'class',5,e,s,gg)
var aBK=_mz(z,'view',['bindtap',6,'class',1,'data-event-opts',2],[],e,s,gg)
var eDK=_mz(z,'m-button',['bind:__l',9,'class',1,'text',2,'vueId',3],[],e,s,gg)
_(aBK,eDK)
var tCK=_v()
_(aBK,tCK)
if(_oz(z,13,e,s,gg)){tCK.wxVkey=1
}
tCK.wxXCkey=1
_(lAK,aBK)
var bEK=_mz(z,'view',['bindtap',14,'class',1,'data-event-opts',2,'style',3],[],e,s,gg)
var xGK=_mz(z,'m-button',['bgColor',18,'bind:__l',1,'class',2,'text',3,'textColor',4,'vueId',5],[],e,s,gg)
_(bEK,xGK)
var oFK=_v()
_(bEK,oFK)
if(_oz(z,24,e,s,gg)){oFK.wxVkey=1
}
oFK.wxXCkey=1
_(lAK,bEK)
_(c9J,lAK)
_(r,c9J)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_36";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_36();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/mine/familyInvite.wxml'] = [$gwx_XC_36, './pages/mine/familyInvite.wxml'];else __wxAppCode__['pages/mine/familyInvite.wxml'] = $gwx_XC_36( './pages/mine/familyInvite.wxml' );
	;__wxRoute = "pages/mine/familyInvite";__wxRouteBegin = true;__wxAppCurrentFile__="pages/mine/familyInvite.js";define("pages/mine/familyInvite.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/mine/familyInvite"],{5388:function(n,e,t){"use strict";(function(n){var a=t("47a9");Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var i=a(t("7eb4")),o=a(t("7ca3")),r=a(t("ee10")),c={data:function(){return{salt:"",standinged:[],nickname:"",relationArr:["妈妈","爸爸","爷爷","奶奶","外公","外婆","亲人"],param:{standing:""},goHomeStatus:!1,btnData:{type:1,fromApp:!1}}},onLoad:function(e){var t=this;return(0,r.default)(i.default.mark((function a(){return i.default.wrap((function(a){for(;;)switch(a.prev=a.next){case 0:return n.removeStorageSync("userInfo"),a.next=3,t.$onLaunched;case 3:if(n.getStorageSync("goHome")&&(t.goHomeStatus=!0),n.removeStorageSync("goHome"),!t.goHomeStatus){a.next=7;break}return a.abrupt("return",t.goHome());case 7:if(!n.getStorageSync("userInfo")){a.next=9;break}return a.abrupt("return",n.reLaunch({url:"/pages/index"}));case 9:t.$nextTick((function(){getApp().globalData.fromApp&&(t.btnData.fromApp=!0),n.getStorageSync("userInfo").mobile&&(t.btnData.mobile=!0)})),e.salt&&(t.salt=e.salt),e.standinged&&(t.standinged=JSON.parse(decodeURIComponent(e.standinged))),e.nickname&&(t.nickname=e.nickname),t.param.standing=t.relationArr.filter((function(n){return!t.standinged.includes(n)}))[0];case 14:case"end":return a.stop()}}),a)})))()},methods:(0,o.default)({selectStanding:function(n){this.standinged.includes(n)||(this.param.standing=n)},decryptPhoneNumber:function(n){var e=this;n.detail.code?this.$api.commonApi.bindPhone({phone_code:n.detail.code},!0,this).then((function(n){e.acceptInvite()})):this.$util.msg("授权失败")},acceptInvite:function(){if(this.btnData.type=1,!getApp().globalData.fromApp){var e=this;e.loadingShow=!0,n.login({provider:"weixin",success:function(t){e.$api.commonApi.silentLogin({driver:"weChat",code:t.code,salt:e.salt,nickname:e.param.standing,standing:e.param.standing},!1,e).then((function(t){e.loadingShow=!1,n.setStorageSync("token",t.data.token),n.setStorageSync("userInfo",t.data.user),t.data.user.last_child_id&&n.setStorageSync("child_id",t.data.user.last_child_id),n.reLaunch({url:"/pages/index"})}))}})}},goHome:function(){if(this.btnData.type=2,!getApp().globalData.fromApp){var e=this;e.loadingShow=!0,n.login({provider:"weixin",success:function(t){e.$api.commonApi.silentLogin({driver:"weChat",code:t.code},!1,e).then((function(t){e.loadingShow=!1,n.setStorageSync("token",t.data.token),n.setStorageSync("userInfo",t.data.user),t.data.user.last_child_id&&n.setStorageSync("child_id",t.data.user.last_child_id),n.reLaunch({url:"/pages/index"})}))}})}}},"decryptPhoneNumber",(function(e){if(e.detail.code){var t=this;t.loadingShow=!0,n.login({provider:"weixin",success:function(a){var i;1==t.btnData.type?i={driver:"phone",code:a.code,phone_code:e.detail.code,salt:t.salt,nickname:t.param.standing,standing:t.param.standing}:2==t.btnData.type&&(i={driver:"phone",code:a.code,phone_code:e.detail.code}),t.$api.commonApi.silentLogin(i,!1,t).then((function(e){t.loadingShow=!1,n.setStorageSync("token",e.data.token),n.setStorageSync("userInfo",e.data.user),e.data.user.last_child_id&&n.setStorageSync("child_id",e.data.user.last_child_id),n.reLaunch({url:"/pages/index"})})).catch((function(n){t.loadingShow=!1}))}})}else this.$util.msg("授权失败")}))};e.default=c}).call(this,t("df3c").default)},"7b38":function(n,e,t){"use strict";t.r(e);var a=t("86fc"),i=t("9778");for(var o in i)["default"].indexOf(o)<0&&function(n){t.d(e,n,(function(){return i[n]}))}(o);t("7df3");var r=t("828b"),c=Object(r.a)(i.default,a.b,a.c,!1,null,"01cdcc1e",null,!1,a.a,void 0);e.default=c.exports},"7df3":function(n,e,t){"use strict";var a=t("e400");t.n(a).a},"86fc":function(n,e,t){"use strict";t.d(e,"b",(function(){return i})),t.d(e,"c",(function(){return o})),t.d(e,"a",(function(){return a}));var a={pageLoading:function(){return t.e("components/pageLoading/pageLoading").then(t.bind(null,"7f33"))},mButton:function(){return t.e("components/mButton/mButton").then(t.bind(null,"fac5"))}},i=function(){var n=this,e=(n.$createElement,n._self._c,n.__map(n.relationArr,(function(e,t){return{$orig:n.__get_orig(e),g0:n.standinged.includes(e)}})));n.$mp.data=Object.assign({},{$root:{l0:e}})},o=[]},9778:function(n,e,t){"use strict";t.r(e);var a=t("5388"),i=t.n(a);for(var o in a)["default"].indexOf(o)<0&&function(n){t.d(e,n,(function(){return a[n]}))}(o);e.default=i.a},b49e:function(n,e,t){"use strict";(function(n,e){var a=t("47a9");t("e465"),a(t("3240"));var i=a(t("7b38"));n.__webpack_require_UNI_MP_PLUGIN__=t,e(i.default)}).call(this,t("3223").default,t("df3c").createPage)},e400:function(n,e,t){}},[["b49e","common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/mine/familyInvite.js'});require("pages/mine/familyInvite.js");