$gwx_XC_21=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_21 || [];
function gz$gwx_XC_21_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_21_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_21_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_21_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'__e'])
Z([3,'__l'])
Z([3,'vue-ref'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^LoopComplete']],[[4],[[5],[[4],[[5],[1,'onLoopComplete']]]]]]]]])
Z([3,'cLottieRef'])
Z([3,'750rpx'])
Z([1,true])
Z([[7],[3,'src2']])
Z([3,'2d5f9d41-1'])
Z(z[5])
Z([3,'content'])
Z([3,'切换图像'])
Z([3,'btnBox'])
Z(z[0])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e0']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'mini'])
Z([3,'热销'])
Z(z[0])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e1']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[15])
Z([3,'字母'])
Z([3,'播放暂停'])
Z(z[12])
Z(z[0])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e2']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[15])
Z([3,'播放'])
Z(z[0])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e3']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[15])
Z([3,'反向播放'])
Z(z[0])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e4']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[15])
Z([3,'暂停播放'])
Z(z[0])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e5']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[15])
Z([3,'停止播放'])
Z([3,'播放速度'])
Z(z[12])
Z(z[0])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e6']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[15])
Z([3,'播放速度1x'])
Z(z[0])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e7']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[15])
Z([3,'播放速度2x'])
Z([3,'播放其它设置'])
Z(z[12])
Z(z[0])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e8']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[15])
Z([3,'跳转到2s并暂停'])
Z(z[0])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e9']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[15])
Z([3,'跳转到2s并播放'])
Z(z[12])
Z(z[0])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e10']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[15])
Z([3,'跳转到第2帧并暂停'])
Z(z[0])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e11']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[15])
Z([3,'跳转到第2帧并播放'])
Z(z[12])
Z(z[0])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e12']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[15])
Z([3,'播放完之前的片段，播放10-20帧'])
Z(z[12])
Z(z[0])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e13']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[15])
Z([3,'直接播放0-5帧和10-18帧'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_21_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_21_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_21=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_21=true;
var x=['./pages/clock.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_21_1()
var bSK=_n('view')
var oTK=_mz(z,'c-lottie',['bind:LoopComplete',0,'bind:__l',1,'class',1,'data-event-opts',2,'data-ref',3,'height',4,'loop',5,'src',6,'vueId',7,'width',8],[],e,s,gg)
_(bSK,oTK)
var xUK=_n('view')
_rz(z,xUK,'class',10,e,s,gg)
var oVK=_n('view')
var fWK=_oz(z,11,e,s,gg)
_(oVK,fWK)
_(xUK,oVK)
var cXK=_n('view')
_rz(z,cXK,'class',12,e,s,gg)
var hYK=_mz(z,'button',['bindtap',13,'data-event-opts',1,'size',2],[],e,s,gg)
var oZK=_oz(z,16,e,s,gg)
_(hYK,oZK)
_(cXK,hYK)
var c1K=_mz(z,'button',['bindtap',17,'data-event-opts',1,'size',2],[],e,s,gg)
var o2K=_oz(z,20,e,s,gg)
_(c1K,o2K)
_(cXK,c1K)
_(xUK,cXK)
var l3K=_n('view')
var a4K=_oz(z,21,e,s,gg)
_(l3K,a4K)
_(xUK,l3K)
var t5K=_n('view')
_rz(z,t5K,'class',22,e,s,gg)
var e6K=_mz(z,'button',['bindtap',23,'data-event-opts',1,'size',2],[],e,s,gg)
var b7K=_oz(z,26,e,s,gg)
_(e6K,b7K)
_(t5K,e6K)
var o8K=_mz(z,'button',['bindtap',27,'data-event-opts',1,'size',2],[],e,s,gg)
var x9K=_oz(z,30,e,s,gg)
_(o8K,x9K)
_(t5K,o8K)
var o0K=_mz(z,'button',['bindtap',31,'data-event-opts',1,'size',2],[],e,s,gg)
var fAL=_oz(z,34,e,s,gg)
_(o0K,fAL)
_(t5K,o0K)
var cBL=_mz(z,'button',['bindtap',35,'data-event-opts',1,'size',2],[],e,s,gg)
var hCL=_oz(z,38,e,s,gg)
_(cBL,hCL)
_(t5K,cBL)
_(xUK,t5K)
var oDL=_n('view')
var cEL=_oz(z,39,e,s,gg)
_(oDL,cEL)
_(xUK,oDL)
var oFL=_n('view')
_rz(z,oFL,'class',40,e,s,gg)
var lGL=_mz(z,'button',['bindtap',41,'data-event-opts',1,'size',2],[],e,s,gg)
var aHL=_oz(z,44,e,s,gg)
_(lGL,aHL)
_(oFL,lGL)
var tIL=_mz(z,'button',['bindtap',45,'data-event-opts',1,'size',2],[],e,s,gg)
var eJL=_oz(z,48,e,s,gg)
_(tIL,eJL)
_(oFL,tIL)
_(xUK,oFL)
var bKL=_n('view')
var oLL=_oz(z,49,e,s,gg)
_(bKL,oLL)
_(xUK,bKL)
var xML=_n('view')
_rz(z,xML,'class',50,e,s,gg)
var oNL=_mz(z,'button',['bindtap',51,'data-event-opts',1,'size',2],[],e,s,gg)
var fOL=_oz(z,54,e,s,gg)
_(oNL,fOL)
_(xML,oNL)
var cPL=_mz(z,'button',['bindtap',55,'data-event-opts',1,'size',2],[],e,s,gg)
var hQL=_oz(z,58,e,s,gg)
_(cPL,hQL)
_(xML,cPL)
_(xUK,xML)
var oRL=_n('view')
_rz(z,oRL,'class',59,e,s,gg)
var cSL=_mz(z,'button',['bindtap',60,'data-event-opts',1,'size',2],[],e,s,gg)
var oTL=_oz(z,63,e,s,gg)
_(cSL,oTL)
_(oRL,cSL)
var lUL=_mz(z,'button',['bindtap',64,'data-event-opts',1,'size',2],[],e,s,gg)
var aVL=_oz(z,67,e,s,gg)
_(lUL,aVL)
_(oRL,lUL)
_(xUK,oRL)
var tWL=_n('view')
_rz(z,tWL,'class',68,e,s,gg)
var eXL=_mz(z,'button',['bindtap',69,'data-event-opts',1,'size',2],[],e,s,gg)
var bYL=_oz(z,72,e,s,gg)
_(eXL,bYL)
_(tWL,eXL)
_(xUK,tWL)
var oZL=_n('view')
_rz(z,oZL,'class',73,e,s,gg)
var x1L=_mz(z,'button',['bindtap',74,'data-event-opts',1,'size',2],[],e,s,gg)
var o2L=_oz(z,77,e,s,gg)
_(x1L,o2L)
_(oZL,x1L)
_(xUK,oZL)
_(bSK,xUK)
_(r,bSK)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_21";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_21();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/clock.wxml'] = [$gwx_XC_21, './pages/clock.wxml'];else __wxAppCode__['pages/clock.wxml'] = $gwx_XC_21( './pages/clock.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/clock.wxss'] = setCssToHead([".",[1],"page{overflow-x:hidden;width:100vw}\n.",[1],"content{font-size:",[0,28],";padding:",[0,20],"}\n.",[1],"btnBox{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;margin-bottom:",[0,30],";margin-top:",[0,20],";width:100%}\n",],undefined,{path:"./pages/clock.wxss"});
}