(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/wish" ], {
    "0284": function(t, o, n) {
        "use strict";
        var e = n("5317");
        n.n(e).a;
    },
    4129: function(t, o, n) {
        "use strict";
        n.r(o);
        var e = n("be37"), i = n.n(e);
        for (var s in e) [ "default" ].indexOf(s) < 0 && function(t) {
            n.d(o, t, function() {
                return e[t];
            });
        }(s);
        o.default = i.a;
    },
    5317: function(t, o, n) {},
    "808e": function(t, o, n) {
        "use strict";
        (function(t, o) {
            var e = n("47a9");
            n("e465"), e(n("3240"));
            var i = e(n("d401"));
            t.__webpack_require_UNI_MP_PLUGIN__ = n, o(i.default);
        }).call(this, n("3223").default, n("df3c").createPage);
    },
    "8c79": function(t, o, n) {
        "use strict";
        n.d(o, "b", function() {
            return i;
        }), n.d(o, "c", function() {
            return s;
        }), n.d(o, "a", function() {
            return e;
        });
        var e = {
            pageLoading: function() {
                return n.e("components/pageLoading/pageLoading").then(n.bind(null, "7f33"));
            },
            mPopup: function() {
                return n.e("components/mPopup/mPopup").then(n.bind(null, "ae6f"));
            },
            uniNumberBox: function() {
                return n.e("uni_modules/uni-number-box/components/uni-number-box/uni-number-box").then(n.bind(null, "2406"));
            },
            mButton: function() {
                return n.e("components/mButton/mButton").then(n.bind(null, "fac5"));
            },
            mModal: function() {
                return n.e("components/mModal/mModal").then(n.bind(null, "68ea"));
            },
            slotModal: function() {
                return n.e("components/slotModal/slotModal").then(n.bind(null, "8d9e"));
            },
            tabbar: function() {
                return n.e("components/tabbar/tabbar").then(n.bind(null, "09e8"));
            }
        }, i = function() {
            var t = this, o = (t.$createElement, t._self._c, t.goodsData[0].goods.length), n = o ? t.__map(t.goodsData, function(o, n) {
                return {
                    $orig: t.__get_orig(o),
                    g1: o.goods.length
                };
            }) : null, e = t.is_created && t.goodsData[1].goods.length;
            t._isMounted || (t.e0 = function(o, n) {
                var e = arguments[arguments.length - 1].currentTarget.dataset, i = e.eventParams || e["event-params"];
                0 != (n = i.goods).status && t.clickGoods(n);
            }, t.e1 = function(o, n) {
                var e = arguments[arguments.length - 1].currentTarget.dataset, i = e.eventParams || e["event-params"];
                n = i.goods, o.stopPropagation(), t.goPage("/pages/wish/goodsAdd?goods=" + encodeURIComponent(JSON.stringify(n)));
            }, t.e2 = function(o) {
                return t.$refs.slotModal.hide();
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    g0: o,
                    l0: n,
                    g2: e
                }
            });
        }, s = [];
    },
    be37: function(t, o, n) {
        "use strict";
        (function(t) {
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var n = {
                data: function() {
                    return {
                        stickTopOpacity: 0,
                        customTop: 0,
                        child_id: t.getStorageSync("child_id"),
                        is_created: t.getStorageSync("userInfo").family.is_created,
                        child: {},
                        iosSafeArea: !0,
                        goodsData: [ {
                            type: 1,
                            title: "小星愿",
                            goods: []
                        }, {
                            type: 2,
                            title: "自定义星愿",
                            goods: []
                        } ],
                        sortStatus: 0,
                        exChangeGoods: {},
                        exchangeNum: 1,
                        exChangeGoodsId: null,
                        errMsg: ""
                    };
                },
                onPageScroll: function(t) {
                    this.stickTopOpacity = t.scrollTop / 150;
                },
                onLoad: function() {
                    var o = this;
                    this.getCustomTop(), t.$off("wish_refresh").$on("wish_refresh", function(t) {
                        o.getData(!1);
                    }), this.getData(!0);
                },
                onShow: function() {
                    this.getInfo();
                },
                computed: {
                    totalStar: function() {
                        return this.exchangeNum * this.exChangeGoods.star;
                    }
                },
                methods: {
                    getCustomTop: function() {
                        this.customTop = getApp().globalData.capsuleInfo.bottom + 15;
                    },
                    getInfo: function() {
                        var o = this;
                        this.$api.commonApi.childrenInfo(this.child_id, {}, !1, this).then(function(n) {
                            t.setStorageSync("child", n.data), o.child = n.data;
                        });
                    },
                    getData: function(t) {
                        var o = this;
                        t && (this.loadingShow = !0), Promise.all([ new Promise(function(t) {
                            o.$api.wishApi.prizesList({
                                child_id: o.child_id,
                                type: "system"
                            }, !1, o).then(function(n) {
                                o.goodsData[0].goods = n.data, t();
                            });
                        }), new Promise(function(t) {
                            o.$api.wishApi.prizesList({
                                child_id: o.child_id,
                                type: "custom"
                            }, !1, o).then(function(n) {
                                o.goodsData[1].goods = n.data, t();
                            });
                        }) ]).then(function(n) {
                            o.$forceUpdate(), t && (o.loadingShow = !1);
                        });
                    },
                    sort: function() {
                        var t = this;
                        this.sortStatus = 0 == this.sortStatus ? 1 : 1 == this.sortStatus ? 2 : 0, this.$api.wishApi.prizesList({
                            child_id: this.child_id,
                            type: "custom",
                            sort: 0 == this.sortStatus ? "" : 1 == this.sortStatus ? "sort_up" : "sort_down",
                            sort_type: this.sortStatus ? "star" : "created_at"
                        }, !0, this).then(function(o) {
                            t.goodsData[1].goods = o.data;
                        });
                    },
                    clickGoods: function(t) {
                        this.exchangeNum = 1, this.exChangeGoods = t, this.$refs.mPopup.show();
                    },
                    numberChange: function(t) {
                        this.exchangeNum = t;
                    },
                    checkExchange: function() {
                        if (this.totalStar > this.child.score) return this.$util.msg("孩子星星余额不足", 2e3);
                        this.$refs.mModal.show();
                    },
                    exChange: function() {
                        var t = this;
                        this.$api.wishApi.prizesExchange({
                            child_id: this.child_id,
                            prize_id: this.exChangeGoods.id,
                            buy_num: this.exchangeNum
                        }, !0, this).then(function(o) {
                            t.exChangeGoodsId = o.data.id, t.$refs.mModal2.show(), t.$refs.mPopup.hide(), t.getInfo();
                        });
                    },
                    useNow: function() {
                        var t = this;
                        this.$api.wishApi.prizesUse(this.exChangeGoodsId, {
                            child_id: this.child_id,
                            status_map: "success"
                        }, !0, this).then(function(o) {
                            t.$util.msg("使用成功！请即时给孩子兑现~");
                        });
                    },
                    goodsAdd: function() {
                        t.getStorageSync("userInfo").family.vip_end_day < 1 && this.goodsData[1].goods.length > 2 ? (this.errMsg = this.is_created ? "标准版最多可添加3个自定义星愿，请升级到专业版，感谢您的理解~" : "标准版最多可添加3个自定义星愿，请联系孩子创建者升级，感谢您的理解~", 
                        this.$refs.slotModal.show()) : this.goPage("/pages/wish/goodsAdd");
                    },
                    renew: function() {
                        this.$refs.slotModal.hide(), this.is_created && (t.setStorageSync("renew", !0), 
                        t.switchTab({
                            url: "/pages/mine"
                        }));
                    }
                }
            };
            o.default = n;
        }).call(this, n("df3c").default);
    },
    d401: function(t, o, n) {
        "use strict";
        n.r(o);
        var e = n("8c79"), i = n("4129");
        for (var s in i) [ "default" ].indexOf(s) < 0 && function(t) {
            n.d(o, t, function() {
                return i[t];
            });
        }(s);
        n("0284");
        var a = n("828b"), r = Object(a.a)(i.default, e.b, e.c, !1, null, "cfcebff2", null, !1, e.a, void 0);
        o.default = r.exports;
    }
}, [ [ "808e", "common/runtime", "common/vendor" ] ] ]);