$gwx_XC_26=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_26 || [];
function gz$gwx_XC_26_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_26_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'content data-v-91c389dc'])
Z([3,'title data-v-91c389dc'])
Z([3,'aspectFill'])
Z([[2,'+'],[[7],[3,'ossMoUrl']],[1,'startup_page_title1.png']])
Z([3,'star data-v-91c389dc'])
Z(z[2])
Z([[2,'+'],[[7],[3,'ossMoUrl']],[1,'startup_page_title_star.png']])
Z([3,'cloud1 data-v-91c389dc'])
Z(z[2])
Z([[2,'+'],[[7],[3,'ossMoUrl']],[1,'startup_page_cloud_11.png']])
Z([3,'cloud2 data-v-91c389dc'])
Z(z[2])
Z([[2,'+'],[[7],[3,'ossMoUrl']],[1,'startup_page_cloud_2.png']])
Z([3,'placeholder data-v-91c389dc'])
Z([3,'circle circle-1 data-v-91c389dc'])
Z([3,'circle-img data-v-91c389dc'])
Z(z[2])
Z([[7],[3,'img1']])
Z([3,'circle circle-2 data-v-91c389dc'])
Z(z[15])
Z(z[2])
Z([[7],[3,'img2']])
Z([3,'circle circle-3 data-v-91c389dc'])
Z(z[15])
Z(z[2])
Z([[7],[3,'img3']])
Z([3,'circle circle-4 data-v-91c389dc'])
Z(z[15])
Z(z[2])
Z([[7],[3,'img4']])
Z([3,'circle circle-5 data-v-91c389dc'])
Z(z[15])
Z(z[2])
Z([[7],[3,'img5']])
Z([3,'circle circle-6 data-v-91c389dc'])
Z(z[15])
Z(z[2])
Z([[7],[3,'img6']])
Z([3,'__e'])
Z([3,'btn-wrap data-v-91c389dc'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'submit']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'__l'])
Z([3,'data-v-91c389dc'])
Z([3,'开启积分制'])
Z([3,'75a511c0-1'])
Z([[2,'&&'],[[2,'!'],[[6],[[7],[3,'btnData']],[3,'mobile']]],[[6],[[7],[3,'btnData']],[3,'fromApp']]])
Z(z[38])
Z([3,'login-btn absolute-full data-v-91c389dc'])
Z([[4],[[5],[[4],[[5],[[5],[1,'getphonenumber']],[[4],[[5],[[4],[[5],[[5],[1,'decryptPhoneNumber']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'getPhoneNumber'])
Z([3,'default'])
Z([3,'slogn data-v-91c389dc'])
Z([3,'自律的最高境界，是自我驱动。'])
Z(z[42])
Z([3,'height:50rpx;'])
Z([3,'ios-bottom data-v-91c389dc'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_26_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_26=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_26=true;
var x=['./pages/enterStep/stepOne.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_26_1()
var hAN=_n('view')
_rz(z,hAN,'class',0,e,s,gg)
var oBN=_mz(z,'image',['class',1,'mode',1,'src',2],[],e,s,gg)
_(hAN,oBN)
var cCN=_mz(z,'image',['class',4,'mode',1,'src',2],[],e,s,gg)
_(hAN,cCN)
var oDN=_mz(z,'image',['class',7,'mode',1,'src',2],[],e,s,gg)
_(hAN,oDN)
var lEN=_mz(z,'image',['class',10,'mode',1,'src',2],[],e,s,gg)
_(hAN,lEN)
var aFN=_n('view')
_rz(z,aFN,'class',13,e,s,gg)
_(hAN,aFN)
var tGN=_n('view')
_rz(z,tGN,'class',14,e,s,gg)
var eHN=_mz(z,'image',['class',15,'mode',1,'src',2],[],e,s,gg)
_(tGN,eHN)
_(hAN,tGN)
var bIN=_n('view')
_rz(z,bIN,'class',18,e,s,gg)
var oJN=_mz(z,'image',['class',19,'mode',1,'src',2],[],e,s,gg)
_(bIN,oJN)
_(hAN,bIN)
var xKN=_n('view')
_rz(z,xKN,'class',22,e,s,gg)
var oLN=_mz(z,'image',['class',23,'mode',1,'src',2],[],e,s,gg)
_(xKN,oLN)
_(hAN,xKN)
var fMN=_n('view')
_rz(z,fMN,'class',26,e,s,gg)
var cNN=_mz(z,'image',['class',27,'mode',1,'src',2],[],e,s,gg)
_(fMN,cNN)
_(hAN,fMN)
var hON=_n('view')
_rz(z,hON,'class',30,e,s,gg)
var oPN=_mz(z,'image',['class',31,'mode',1,'src',2],[],e,s,gg)
_(hON,oPN)
_(hAN,hON)
var cQN=_n('view')
_rz(z,cQN,'class',34,e,s,gg)
var oRN=_mz(z,'image',['class',35,'mode',1,'src',2],[],e,s,gg)
_(cQN,oRN)
_(hAN,cQN)
var lSN=_mz(z,'view',['bindtap',38,'class',1,'data-event-opts',2],[],e,s,gg)
var tUN=_mz(z,'m-button',['bind:__l',41,'class',1,'text',2,'vueId',3],[],e,s,gg)
_(lSN,tUN)
var aTN=_v()
_(lSN,aTN)
if(_oz(z,45,e,s,gg)){aTN.wxVkey=1
var eVN=_mz(z,'button',['bindgetphonenumber',46,'class',1,'data-event-opts',2,'openType',3,'type',4],[],e,s,gg)
_(aTN,eVN)
}
aTN.wxXCkey=1
_(hAN,lSN)
var bWN=_n('view')
_rz(z,bWN,'class',51,e,s,gg)
var oXN=_oz(z,52,e,s,gg)
_(bWN,oXN)
_(hAN,bWN)
var xYN=_mz(z,'view',['class',53,'style',1],[],e,s,gg)
_(hAN,xYN)
var oZN=_n('view')
_rz(z,oZN,'class',55,e,s,gg)
_(hAN,oZN)
_(r,hAN)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_26";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_26();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/enterStep/stepOne.wxml'] = [$gwx_XC_26, './pages/enterStep/stepOne.wxml'];else __wxAppCode__['pages/enterStep/stepOne.wxml'] = $gwx_XC_26( './pages/enterStep/stepOne.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/enterStep/stepOne.wxss'] = setCssToHead([".",[1],"content.",[1],"data-v-91c389dc{background:linear-gradient(180deg,#7561f4,#58d2f4);max-width:100vw;min-height:100vh;overflow:hidden;padding-top:",[0,200],";position:relative}\n@-webkit-keyframes cloud1-data-v-91c389dc{0%{left:",[0,750],"}\n100%{left:",[0,-570],"}\n}@keyframes cloud1-data-v-91c389dc{0%{left:",[0,750],"}\n100%{left:",[0,-570],"}\n}.",[1],"content .",[1],"cloud1.",[1],"data-v-91c389dc{-webkit-animation:cloud1-data-v-91c389dc 25s linear infinite;animation:cloud1-data-v-91c389dc 25s linear infinite;height:",[0,299],";left:0;position:absolute;top:",[0,394],";width:",[0,570],"}\n.",[1],"content .",[1],"cloud2.",[1],"data-v-91c389dc{bottom:",[0,-500],";height:",[0,986],";left:0;position:absolute;width:",[0,750],"}\n.",[1],"content .",[1],"title.",[1],"data-v-91c389dc{height:",[0,218],";margin-left:",[0,40],";width:",[0,674],"}\n.",[1],"content .",[1],"star.",[1],"data-v-91c389dc{-webkit-animation:star-data-v-91c389dc 1s linear infinite;animation:star-data-v-91c389dc 1s linear infinite;height:",[0,128],";position:relative;top:",[0,-120],";width:",[0,128],"}\n@-webkit-keyframes star-data-v-91c389dc{0%{-webkit-transform:scale(1);transform:scale(1)}\n50%{opacity:.85;-webkit-transform:scale(.97);transform:scale(.97)}\n100%{-webkit-transform:scale(1);transform:scale(1)}\n}@keyframes star-data-v-91c389dc{0%{-webkit-transform:scale(1);transform:scale(1)}\n50%{opacity:.85;-webkit-transform:scale(.97);transform:scale(.97)}\n100%{-webkit-transform:scale(1);transform:scale(1)}\n}.",[1],"content .",[1],"placeholder.",[1],"data-v-91c389dc{min-height:",[0,820],"}\n.",[1],"content .",[1],"circle.",[1],"data-v-91c389dc{border-radius:50%;opacity:0;overflow:hidden;position:absolute;z-index:2}\n.",[1],"content .",[1],"circle .",[1],"circle-img.",[1],"data-v-91c389dc{height:100%;width:100%}\n.",[1],"content .",[1],"circle-1.",[1],"data-v-91c389dc{-webkit-animation:circleAini1-data-v-91c389dc 10s linear infinite;animation:circleAini1-data-v-91c389dc 10s linear infinite;-webkit-animation-delay:.2s;animation-delay:.2s;height:",[0,250],";left:",[0,30],";top:",[0,450],";width:",[0,250],"}\n@-webkit-keyframes circleAini1-data-v-91c389dc{0%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n15%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n50%{opacity:1;-webkit-transform:scale(1) translate(",[0,-10],",",[0,10],");transform:scale(1) translate(",[0,-10],",",[0,10],")}\n85%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n100%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n}@keyframes circleAini1-data-v-91c389dc{0%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n15%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n50%{opacity:1;-webkit-transform:scale(1) translate(",[0,-10],",",[0,10],");transform:scale(1) translate(",[0,-10],",",[0,10],")}\n85%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n100%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n}.",[1],"content .",[1],"circle-2.",[1],"data-v-91c389dc{-webkit-animation:circleAini2-data-v-91c389dc 8s linear infinite;animation:circleAini2-data-v-91c389dc 8s linear infinite;-webkit-animation-delay:.6s;animation-delay:.6s;height:",[0,250],";left:",[0,-70],";top:",[0,730],";width:",[0,250],"}\n@-webkit-keyframes circleAini2-data-v-91c389dc{0%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n15%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n50%{opacity:1;-webkit-transform:scale(1) translate(",[0,-10],",",[0,10],");transform:scale(1) translate(",[0,-10],",",[0,10],")}\n85%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n100%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n}@keyframes circleAini2-data-v-91c389dc{0%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n15%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n50%{opacity:1;-webkit-transform:scale(1) translate(",[0,-10],",",[0,10],");transform:scale(1) translate(",[0,-10],",",[0,10],")}\n85%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n100%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n}.",[1],"content .",[1],"circle-3.",[1],"data-v-91c389dc{-webkit-animation:circleAini3-data-v-91c389dc 6s linear infinite;animation:circleAini3-data-v-91c389dc 6s linear infinite;height:",[0,320],";left:",[0,230],";top:",[0,650],";width:",[0,320],"}\n@-webkit-keyframes circleAini3-data-v-91c389dc{0%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n15%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n50%{opacity:1;-webkit-transform:scale(1) translate(",[0,-10],",",[0,-10],");transform:scale(1) translate(",[0,-10],",",[0,-10],")}\n85%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n100%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n}@keyframes circleAini3-data-v-91c389dc{0%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n15%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n50%{opacity:1;-webkit-transform:scale(1) translate(",[0,-10],",",[0,-10],");transform:scale(1) translate(",[0,-10],",",[0,-10],")}\n85%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n100%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n}.",[1],"content .",[1],"circle-4.",[1],"data-v-91c389dc{-webkit-animation:circleAini4-data-v-91c389dc 7s linear infinite;animation:circleAini4-data-v-91c389dc 7s linear infinite;-webkit-animation-delay:.4s;animation-delay:.4s;height:",[0,250],";left:",[0,80],";top:",[0,990],";width:",[0,250],"}\n@-webkit-keyframes circleAini4-data-v-91c389dc{0%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n15%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n50%{opacity:1;-webkit-transform:scale(1) translateY(",[0,-10],");transform:scale(1) translateY(",[0,-10],")}\n85%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n100%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n}@keyframes circleAini4-data-v-91c389dc{0%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n15%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n50%{opacity:1;-webkit-transform:scale(1) translateY(",[0,-10],");transform:scale(1) translateY(",[0,-10],")}\n85%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n100%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n}.",[1],"content .",[1],"circle-5.",[1],"data-v-91c389dc{-webkit-animation:circleAini5-data-v-91c389dc 9s linear infinite;animation:circleAini5-data-v-91c389dc 9s linear infinite;-webkit-animation-delay:.8s;animation-delay:.8s;height:",[0,280],";left:",[0,550],";top:",[0,550],";width:",[0,280],"}\n@-webkit-keyframes circleAini5-data-v-91c389dc{0%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n15%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n50%{opacity:1;-webkit-transform:scale(1) translate(",[0,10],",",[0,10],");transform:scale(1) translate(",[0,10],",",[0,10],")}\n85%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n100%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n}@keyframes circleAini5-data-v-91c389dc{0%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n15%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n50%{opacity:1;-webkit-transform:scale(1) translate(",[0,10],",",[0,10],");transform:scale(1) translate(",[0,10],",",[0,10],")}\n85%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n100%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n}.",[1],"content .",[1],"circle-6.",[1],"data-v-91c389dc{-webkit-animation:circleAini6-data-v-91c389dc 11s linear infinite;animation:circleAini6-data-v-91c389dc 11s linear infinite;-webkit-animation-delay:1s;animation-delay:1s;height:",[0,240],";left:",[0,550],";top:",[0,870],";width:",[0,240],"}\n@-webkit-keyframes circleAini6-data-v-91c389dc{0%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n15%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n50%{opacity:1;-webkit-transform:scale(1) translate(",[0,10],",",[0,-10],");transform:scale(1) translate(",[0,10],",",[0,-10],")}\n85%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n100%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n}@keyframes circleAini6-data-v-91c389dc{0%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n15%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n50%{opacity:1;-webkit-transform:scale(1) translate(",[0,10],",",[0,-10],");transform:scale(1) translate(",[0,10],",",[0,-10],")}\n85%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}\n100%{opacity:0;-webkit-transform:scale(.7);transform:scale(.7)}\n}.",[1],"content .",[1],"btn-wrap.",[1],"data-v-91c389dc{position:relative;z-index:2}\n.",[1],"content .",[1],"btn-wrap .",[1],"login-btn.",[1],"data-v-91c389dc{opacity:0}\n.",[1],"content .",[1],"slogn.",[1],"data-v-91c389dc{color:#6794f4;font-size:",[0,28],";font-weight:500;margin-top:",[0,50],";position:relative;text-align:center;z-index:2}\n",],undefined,{path:"./pages/enterStep/stepOne.wxss"});
}