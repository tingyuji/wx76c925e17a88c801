(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/enterStep/stepTwo" ], {
    "023d": function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("6a5a"), i = n.n(a);
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(r);
        e.default = i.a;
    },
    3756: function(t, e, n) {
        "use strict";
        var a = n("cf06");
        n.n(a).a;
    },
    "6a5a": function(t, e, n) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var n = {
                data: function() {
                    return {
                        type: "create",
                        sexyArr: [ {
                            value: "male",
                            name: "男孩",
                            avatar: "img_boy_s.png"
                        }, {
                            value: "female",
                            name: "女孩",
                            avatar: "img_girl_s.png"
                        } ],
                        relationArr: [ "妈妈", "爸爸", "爷爷", "奶奶", "外公", "外婆", "亲人" ],
                        param: {
                            gender: "male",
                            nickname: "",
                            standing: "妈妈",
                            init_amount: 0
                        }
                    };
                },
                onLoad: function(t) {
                    t.type && (this.type = t.type, this.getStanding());
                },
                methods: {
                    getStanding: function() {
                        var t = this;
                        this.$api.commonApi.userInfo({}, !0, this).then(function(e) {
                            t.param.standing = e.data.standing;
                        });
                    },
                    numberChange: function(t) {
                        this.param.init_amount = t;
                    },
                    nextStep: function() {
                        var e = this;
                        if (!this.param.nickname) return this.$util.msg("请填写宝贝昵称");
                        "create" == this.type ? this.$api.commonApi.childrenSet(this.param, !0, this).then(function(n) {
                            t.setStorageSync("child_id", n.data.user.last_child_id), t.setStorageSync("token", n.data.token), 
                            t.setStorageSync("userInfo", n.data.user), e.goPage("/pages/enterStep/stepThree", "redirectTo");
                        }) : "add" == this.type && this.$api.commonApi.childrenAdd(this.param, !0, this).then(function(n) {
                            t.setStorageSync("child_id", n.data.user.last_child_id), t.setStorageSync("token", n.data.token), 
                            t.setStorageSync("userInfo", n.data.user), e.goPage("/pages/enterStep/stepThree?type=add", "redirectTo");
                        });
                    }
                }
            };
            e.default = n;
        }).call(this, n("df3c").default);
    },
    "71e6": function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("b5b4"), i = n("023d");
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(r);
        n("3756");
        var u = n("828b"), o = Object(u.a)(i.default, a.b, a.c, !1, null, "d80913c2", null, !1, a.a, void 0);
        e.default = o.exports;
    },
    "875c": function(t, e, n) {
        "use strict";
        (function(t, e) {
            var a = n("47a9");
            n("e465"), a(n("3240"));
            var i = a(n("71e6"));
            t.__webpack_require_UNI_MP_PLUGIN__ = n, e(i.default);
        }).call(this, n("3223").default, n("df3c").createPage);
    },
    b5b4: function(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return r;
        }), n.d(e, "a", function() {
            return a;
        });
        var a = {
            pageLoading: function() {
                return n.e("components/pageLoading/pageLoading").then(n.bind(null, "7f33"));
            },
            uniNumberBox: function() {
                return n.e("uni_modules/uni-number-box/components/uni-number-box/uni-number-box").then(n.bind(null, "2406"));
            },
            mButton: function() {
                return n.e("components/mButton/mButton").then(n.bind(null, "fac5"));
            }
        }, i = function() {
            var t = this;
            t.$createElement;
            t._self._c, t._isMounted || (t.e0 = function(e, n) {
                var a = arguments[arguments.length - 1].currentTarget.dataset, i = a.eventParams || a["event-params"];
                n = i.item, t.param.standing = n;
            }, t.e1 = function(e, n) {
                var a = arguments[arguments.length - 1].currentTarget.dataset, i = a.eventParams || a["event-params"];
                n = i.item, t.param.gender = n.value;
            });
        }, r = [];
    },
    cf06: function(t, e, n) {}
}, [ [ "875c", "common/runtime", "common/vendor" ] ] ]);