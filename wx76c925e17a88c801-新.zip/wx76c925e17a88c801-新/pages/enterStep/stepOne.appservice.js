$gwx_XC_26=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_26 || [];
function gz$gwx_XC_26_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_26_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'__e'])
Z([3,'btn-wrap data-v-91c389dc'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'submit']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'__l'])
Z([3,'data-v-91c389dc'])
Z([3,'开启积分制'])
Z([3,'75a511c0-1'])
Z([[2,'&&'],[[2,'!'],[[6],[[7],[3,'btnData']],[3,'mobile']]],[[6],[[7],[3,'btnData']],[3,'fromApp']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_26_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_26=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_26=true;
var x=['./pages/enterStep/stepOne.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_26_1()
var tIE=_mz(z,'view',['bindtap',0,'class',1,'data-event-opts',1],[],e,s,gg)
var bKE=_mz(z,'m-button',['bind:__l',3,'class',1,'text',2,'vueId',3],[],e,s,gg)
_(tIE,bKE)
var eJE=_v()
_(tIE,eJE)
if(_oz(z,7,e,s,gg)){eJE.wxVkey=1
}
eJE.wxXCkey=1
_(r,tIE)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_26";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_26();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/enterStep/stepOne.wxml'] = [$gwx_XC_26, './pages/enterStep/stepOne.wxml'];else __wxAppCode__['pages/enterStep/stepOne.wxml'] = $gwx_XC_26( './pages/enterStep/stepOne.wxml' );
	;__wxRoute = "pages/enterStep/stepOne";__wxRouteBegin = true;__wxAppCurrentFile__="pages/enterStep/stepOne.js";define("pages/enterStep/stepOne.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/enterStep/stepOne"],{2526:function(t,n,i){"use strict";(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var i={data:function(){return{img1:"",img2:"",img3:"",img4:"",img5:"",img6:"",imgArr:["https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/startup_page_icon_1.png","https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/startup_page_icon_2.png","https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/startup_page_icon_3.png","https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/startup_page_icon_4.png","https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/startup_page_icon_5.png","https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/startup_page_icon_6.png","https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/startup_page_icon_7.png","https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/startup_page_icon_8.png","https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/startup_page_icon_9.png","https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/startup_page_icon_10.png","https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/startup_page_icon_11.png"],btnData:{mobile:!1,fromApp:!1}}},onLoad:function(){var n=this;this.$nextTick((function(){getApp().globalData.fromApp&&(n.btnData.fromApp=!0),t.getStorageSync("userInfo").mobile&&(n.btnData.mobile=!0)})),setTimeout((function(){n.changeImg1()}),200),setTimeout((function(){n.changeImg2()}),600),this.changeImg3(),setTimeout((function(){n.changeImg4()}),400),setTimeout((function(){n.changeImg5()}),800),setTimeout((function(){n.changeImg6()}),1e3)},methods:{changeImg1:function(){var t=this;this.img1=this.imgArr[0],this.sortArr(),setTimeout((function(){t.changeImg1()}),1e4)},changeImg2:function(){var t=this;this.img2=this.imgArr[0],this.sortArr(),setTimeout((function(){t.changeImg2()}),8e3)},changeImg3:function(){var t=this;this.img3=this.imgArr[0],this.sortArr(),setTimeout((function(){t.changeImg3()}),6e3)},changeImg4:function(){var t=this;this.img4=this.imgArr[0],this.sortArr(),setTimeout((function(){t.changeImg4()}),7e3)},changeImg5:function(){var t=this;this.img5=this.imgArr[0],this.sortArr(),setTimeout((function(){t.changeImg5()}),9e3)},changeImg6:function(){var t=this;this.img6=this.imgArr[0],this.sortArr(),setTimeout((function(){t.changeImg6()}),11e3)},sortArr:function(){this.imgArr.push(this.imgArr[0]),this.imgArr.shift()},submit:function(){getApp().globalData.fromApp&&!this.btnData.mobile||this.goPage("/pages/enterStep/stepTwo","redirectTo")},decryptPhoneNumber:function(t){var n=this;t.detail.code?this.$api.commonApi.bindPhone({phone_code:t.detail.code},!0,this).then((function(t){n.getUserInfo()})):this.$util.msg("授权失败")},getUserInfo:function(){var n=this;this.$api.commonApi.userInfo({},!0,this).then((function(i){n.userInfo=i.data,t.setStorageSync("userInfo",i.data),n.goPage("/pages/enterStep/stepTwo","redirectTo")}))}}};n.default=i}).call(this,i("df3c").default)},"2e3d":function(t,n,i){},3194:function(t,n,i){"use strict";i.r(n);var e=i("2526"),a=i.n(e);for(var o in e)["default"].indexOf(o)<0&&function(t){i.d(n,t,(function(){return e[t]}))}(o);n.default=a.a},ad52:function(t,n,i){"use strict";(function(t,n){var e=i("47a9");i("e465"),e(i("3240"));var a=e(i("b86d"));t.__webpack_require_UNI_MP_PLUGIN__=i,n(a.default)}).call(this,i("3223").default,i("df3c").createPage)},b86d:function(t,n,i){"use strict";i.r(n);var e=i("f51f"),a=i("3194");for(var o in a)["default"].indexOf(o)<0&&function(t){i.d(n,t,(function(){return a[t]}))}(o);i("ecee");var s=i("828b"),c=Object(s.a)(a.default,e.b,e.c,!1,null,"91c389dc",null,!1,e.a,void 0);n.default=c.exports},ecee:function(t,n,i){"use strict";var e=i("2e3d");i.n(e).a},f51f:function(t,n,i){"use strict";i.d(n,"b",(function(){return a})),i.d(n,"c",(function(){return o})),i.d(n,"a",(function(){return e}));var e={mButton:function(){return i.e("components/mButton/mButton").then(i.bind(null,"fac5"))}},a=function(){this.$createElement;this._self._c},o=[]}},[["ad52","common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/enterStep/stepOne.js'});require("pages/enterStep/stepOne.js");