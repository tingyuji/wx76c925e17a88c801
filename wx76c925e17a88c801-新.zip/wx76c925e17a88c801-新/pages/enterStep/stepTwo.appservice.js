$gwx_XC_28=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_28 || [];
function gz$gwx_XC_28_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_28_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_28_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_28_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'content flex-column flex-align-center data-v-d80913c2'])
Z([3,'__l'])
Z([3,'data-v-d80913c2'])
Z([[7],[3,'loadingShow']])
Z([3,'6a337d9a-1'])
Z([[2,'=='],[[7],[3,'type']],[1,'create']])
Z(z[1])
Z([3,'__e'])
Z(z[2])
Z([[4],[[5],[[4],[[5],[[5],[1,'^change']],[[4],[[5],[[4],[[5],[1,'numberChange']]]]]]]]])
Z([1,68])
Z([1,70])
Z([1,0])
Z(z[12])
Z([3,'6a337d9a-2'])
Z([[2,'?:'],[[6],[[7],[3,'param']],[3,'nickname']],[1,'#765DF4'],[1,'#e5e5e5']])
Z(z[1])
Z(z[7])
Z(z[15])
Z(z[2])
Z([[4],[[5],[[4],[[5],[[5],[1,'^submit']],[[4],[[5],[[4],[[5],[1,'nextStep']]]]]]]]])
Z([3,'下一步'])
Z([[2,'?:'],[[6],[[7],[3,'param']],[3,'nickname']],[1,'#FFFFFF'],[1,'#999999']])
Z([3,'6a337d9a-3'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_28_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_28_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_28=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_28=true;
var x=['./pages/enterStep/stepTwo.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_28_1()
var f3E=_n('view')
_rz(z,f3E,'class',0,e,s,gg)
var h5E=_mz(z,'page-loading',['bind:__l',1,'class',1,'loadingShow_',2,'vueId',3],[],e,s,gg)
_(f3E,h5E)
var c4E=_v()
_(f3E,c4E)
if(_oz(z,5,e,s,gg)){c4E.wxVkey=1
}
var o6E=_mz(z,'uni-number-box',['bind:__l',6,'bind:change',1,'class',2,'data-event-opts',3,'height',4,'midWidth',5,'min',6,'value',7,'vueId',8],[],e,s,gg)
_(f3E,o6E)
var c7E=_mz(z,'m-button',['bgColor',15,'bind:__l',1,'bind:submit',2,'borderColor',3,'class',4,'data-event-opts',5,'text',6,'textColor',7,'vueId',8],[],e,s,gg)
_(f3E,c7E)
c4E.wxXCkey=1
_(r,f3E)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_28";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_28();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/enterStep/stepTwo.wxml'] = [$gwx_XC_28, './pages/enterStep/stepTwo.wxml'];else __wxAppCode__['pages/enterStep/stepTwo.wxml'] = $gwx_XC_28( './pages/enterStep/stepTwo.wxml' );
	;__wxRoute = "pages/enterStep/stepTwo";__wxRouteBegin = true;__wxAppCurrentFile__="pages/enterStep/stepTwo.js";define("pages/enterStep/stepTwo.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/enterStep/stepTwo"],{"023d":function(t,e,n){"use strict";n.r(e);var a=n("6a5a"),i=n.n(a);for(var r in a)["default"].indexOf(r)<0&&function(t){n.d(e,t,(function(){return a[t]}))}(r);e.default=i.a},3756:function(t,e,n){"use strict";var a=n("cf06");n.n(a).a},"6a5a":function(t,e,n){"use strict";(function(t){Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var n={data:function(){return{type:"create",sexyArr:[{value:"male",name:"男孩",avatar:"img_boy_s.png"},{value:"female",name:"女孩",avatar:"img_girl_s.png"}],relationArr:["妈妈","爸爸","爷爷","奶奶","外公","外婆","亲人"],param:{gender:"male",nickname:"",standing:"妈妈",init_amount:0}}},onLoad:function(t){t.type&&(this.type=t.type,this.getStanding())},methods:{getStanding:function(){var t=this;this.$api.commonApi.userInfo({},!0,this).then((function(e){t.param.standing=e.data.standing}))},numberChange:function(t){this.param.init_amount=t},nextStep:function(){var e=this;if(!this.param.nickname)return this.$util.msg("请填写宝贝昵称");"create"==this.type?this.$api.commonApi.childrenSet(this.param,!0,this).then((function(n){t.setStorageSync("child_id",n.data.user.last_child_id),t.setStorageSync("token",n.data.token),t.setStorageSync("userInfo",n.data.user),e.goPage("/pages/enterStep/stepThree","redirectTo")})):"add"==this.type&&this.$api.commonApi.childrenAdd(this.param,!0,this).then((function(n){t.setStorageSync("child_id",n.data.user.last_child_id),t.setStorageSync("token",n.data.token),t.setStorageSync("userInfo",n.data.user),e.goPage("/pages/enterStep/stepThree?type=add","redirectTo")}))}}};e.default=n}).call(this,n("df3c").default)},"71e6":function(t,e,n){"use strict";n.r(e);var a=n("b5b4"),i=n("023d");for(var r in i)["default"].indexOf(r)<0&&function(t){n.d(e,t,(function(){return i[t]}))}(r);n("3756");var u=n("828b"),o=Object(u.a)(i.default,a.b,a.c,!1,null,"d80913c2",null,!1,a.a,void 0);e.default=o.exports},"875c":function(t,e,n){"use strict";(function(t,e){var a=n("47a9");n("e465"),a(n("3240"));var i=a(n("71e6"));t.__webpack_require_UNI_MP_PLUGIN__=n,e(i.default)}).call(this,n("3223").default,n("df3c").createPage)},b5b4:function(t,e,n){"use strict";n.d(e,"b",(function(){return i})),n.d(e,"c",(function(){return r})),n.d(e,"a",(function(){return a}));var a={pageLoading:function(){return n.e("components/pageLoading/pageLoading").then(n.bind(null,"7f33"))},uniNumberBox:function(){return n.e("uni_modules/uni-number-box/components/uni-number-box/uni-number-box").then(n.bind(null,"2406"))},mButton:function(){return n.e("components/mButton/mButton").then(n.bind(null,"fac5"))}},i=function(){var t=this;t.$createElement;t._self._c,t._isMounted||(t.e0=function(e,n){var a=arguments[arguments.length-1].currentTarget.dataset,i=a.eventParams||a["event-params"];n=i.item,t.param.standing=n},t.e1=function(e,n){var a=arguments[arguments.length-1].currentTarget.dataset,i=a.eventParams||a["event-params"];n=i.item,t.param.gender=n.value})},r=[]},cf06:function(t,e,n){}},[["875c","common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/enterStep/stepTwo.js'});require("pages/enterStep/stepTwo.js");