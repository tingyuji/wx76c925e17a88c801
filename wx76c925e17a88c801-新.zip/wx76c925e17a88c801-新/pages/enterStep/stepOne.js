(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/enterStep/stepOne" ], {
    2526: function(t, n, i) {
        "use strict";
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var i = {
                data: function() {
                    return {
                        img1: "",
                        img2: "",
                        img3: "",
                        img4: "",
                        img5: "",
                        img6: "",
                        imgArr: [ "https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/startup_page_icon_1.png", "https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/startup_page_icon_2.png", "https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/startup_page_icon_3.png", "https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/startup_page_icon_4.png", "https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/startup_page_icon_5.png", "https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/startup_page_icon_6.png", "https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/startup_page_icon_7.png", "https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/startup_page_icon_8.png", "https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/startup_page_icon_9.png", "https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/startup_page_icon_10.png", "https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/startup_page_icon_11.png" ],
                        btnData: {
                            mobile: !1,
                            fromApp: !1
                        }
                    };
                },
                onLoad: function() {
                    var n = this;
                    this.$nextTick(function() {
                        getApp().globalData.fromApp && (n.btnData.fromApp = !0), t.getStorageSync("userInfo").mobile && (n.btnData.mobile = !0);
                    }), setTimeout(function() {
                        n.changeImg1();
                    }, 200), setTimeout(function() {
                        n.changeImg2();
                    }, 600), this.changeImg3(), setTimeout(function() {
                        n.changeImg4();
                    }, 400), setTimeout(function() {
                        n.changeImg5();
                    }, 800), setTimeout(function() {
                        n.changeImg6();
                    }, 1e3);
                },
                methods: {
                    changeImg1: function() {
                        var t = this;
                        this.img1 = this.imgArr[0], this.sortArr(), setTimeout(function() {
                            t.changeImg1();
                        }, 1e4);
                    },
                    changeImg2: function() {
                        var t = this;
                        this.img2 = this.imgArr[0], this.sortArr(), setTimeout(function() {
                            t.changeImg2();
                        }, 8e3);
                    },
                    changeImg3: function() {
                        var t = this;
                        this.img3 = this.imgArr[0], this.sortArr(), setTimeout(function() {
                            t.changeImg3();
                        }, 6e3);
                    },
                    changeImg4: function() {
                        var t = this;
                        this.img4 = this.imgArr[0], this.sortArr(), setTimeout(function() {
                            t.changeImg4();
                        }, 7e3);
                    },
                    changeImg5: function() {
                        var t = this;
                        this.img5 = this.imgArr[0], this.sortArr(), setTimeout(function() {
                            t.changeImg5();
                        }, 9e3);
                    },
                    changeImg6: function() {
                        var t = this;
                        this.img6 = this.imgArr[0], this.sortArr(), setTimeout(function() {
                            t.changeImg6();
                        }, 11e3);
                    },
                    sortArr: function() {
                        this.imgArr.push(this.imgArr[0]), this.imgArr.shift();
                    },
                    submit: function() {
                        getApp().globalData.fromApp && !this.btnData.mobile || this.goPage("/pages/enterStep/stepTwo", "redirectTo");
                    },
                    decryptPhoneNumber: function(t) {
                        var n = this;
                        t.detail.code ? this.$api.commonApi.bindPhone({
                            phone_code: t.detail.code
                        }, !0, this).then(function(t) {
                            n.getUserInfo();
                        }) : this.$util.msg("授权失败");
                    },
                    getUserInfo: function() {
                        var n = this;
                        this.$api.commonApi.userInfo({}, !0, this).then(function(i) {
                            n.userInfo = i.data, t.setStorageSync("userInfo", i.data), n.goPage("/pages/enterStep/stepTwo", "redirectTo");
                        });
                    }
                }
            };
            n.default = i;
        }).call(this, i("df3c").default);
    },
    "2e3d": function(t, n, i) {},
    3194: function(t, n, i) {
        "use strict";
        i.r(n);
        var e = i("2526"), a = i.n(e);
        for (var o in e) [ "default" ].indexOf(o) < 0 && function(t) {
            i.d(n, t, function() {
                return e[t];
            });
        }(o);
        n.default = a.a;
    },
    ad52: function(t, n, i) {
        "use strict";
        (function(t, n) {
            var e = i("47a9");
            i("e465"), e(i("3240"));
            var a = e(i("b86d"));
            t.__webpack_require_UNI_MP_PLUGIN__ = i, n(a.default);
        }).call(this, i("3223").default, i("df3c").createPage);
    },
    b86d: function(t, n, i) {
        "use strict";
        i.r(n);
        var e = i("f51f"), a = i("3194");
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(t) {
            i.d(n, t, function() {
                return a[t];
            });
        }(o);
        i("ecee");
        var s = i("828b"), c = Object(s.a)(a.default, e.b, e.c, !1, null, "91c389dc", null, !1, e.a, void 0);
        n.default = c.exports;
    },
    ecee: function(t, n, i) {
        "use strict";
        var e = i("2e3d");
        i.n(e).a;
    },
    f51f: function(t, n, i) {
        "use strict";
        i.d(n, "b", function() {
            return a;
        }), i.d(n, "c", function() {
            return o;
        }), i.d(n, "a", function() {
            return e;
        });
        var e = {
            mButton: function() {
                return i.e("components/mButton/mButton").then(i.bind(null, "fac5"));
            }
        }, a = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    }
}, [ [ "ad52", "common/runtime", "common/vendor" ] ] ]);