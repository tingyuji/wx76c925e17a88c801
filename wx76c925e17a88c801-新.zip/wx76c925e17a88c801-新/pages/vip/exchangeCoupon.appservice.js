$gwx_XC_49=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_49 || [];
function gz$gwx_XC_49_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_49_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_49_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_49_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'content data-v-1f037c24'])
Z([3,'__l'])
Z([3,'data-v-1f037c24'])
Z([[7],[3,'loadingShow']])
Z([3,'00c28f1c-1'])
Z([[2,'?:'],[[7],[3,'code']],[1,'#765DF4'],[1,'#E5E5E5']])
Z(z[1])
Z([3,'__e'])
Z(z[5])
Z(z[2])
Z([[4],[[5],[[4],[[5],[[5],[1,'^submit']],[[4],[[5],[[4],[[5],[1,'exchange']]]]]]]]])
Z([3,'兑换'])
Z([[2,'?:'],[[7],[3,'code']],[1,'#FFF'],[1,'#999']])
Z([3,'00c28f1c-2'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_49_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_49_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_49=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_49=true;
var x=['./pages/vip/exchangeCoupon.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_49_1()
var t7P=_n('view')
_rz(z,t7P,'class',0,e,s,gg)
var e8P=_mz(z,'page-loading',['bind:__l',1,'class',1,'loadingShow_',2,'vueId',3],[],e,s,gg)
_(t7P,e8P)
var b9P=_mz(z,'m-button',['bgColor',5,'bind:__l',1,'bind:submit',2,'borderColor',3,'class',4,'data-event-opts',5,'text',6,'textColor',7,'vueId',8],[],e,s,gg)
_(t7P,b9P)
_(r,t7P)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_49";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_49();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/vip/exchangeCoupon.wxml'] = [$gwx_XC_49, './pages/vip/exchangeCoupon.wxml'];else __wxAppCode__['pages/vip/exchangeCoupon.wxml'] = $gwx_XC_49( './pages/vip/exchangeCoupon.wxml' );
	;__wxRoute = "pages/vip/exchangeCoupon";__wxRouteBegin = true;__wxAppCurrentFile__="pages/vip/exchangeCoupon.js";define("pages/vip/exchangeCoupon.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/vip/exchangeCoupon"],{"0708":function(n,t,e){"use strict";e.r(t);var u=e("f83c"),i=e("b6b7");for(var o in i)["default"].indexOf(o)<0&&function(n){e.d(t,n,(function(){return i[n]}))}(o);e("f4d0");var c=e("828b"),a=Object(c.a)(i.default,u.b,u.c,!1,null,"1f037c24",null,!1,u.a,void 0);t.default=a.exports},4918:function(n,t,e){},5463:function(n,t,e){"use strict";(function(n){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var e={data:function(){return{code:""}},onLoad:function(){},methods:{exchange:function(){var t=this;if(!this.code)return this.$util.msg("请输入兑换码");this.$api.vipApi.couponExchange({key:this.code},!0,this).then((function(e){t.$util.msg("兑换成功"),n.$emit("refreshCoupon"),setTimeout((function(){n.navigateBack()}),1500)}))}}};t.default=e}).call(this,e("df3c").default)},b6b7:function(n,t,e){"use strict";e.r(t);var u=e("5463"),i=e.n(u);for(var o in u)["default"].indexOf(o)<0&&function(n){e.d(t,n,(function(){return u[n]}))}(o);t.default=i.a},c64d:function(n,t,e){"use strict";(function(n,t){var u=e("47a9");e("e465"),u(e("3240"));var i=u(e("0708"));n.__webpack_require_UNI_MP_PLUGIN__=e,t(i.default)}).call(this,e("3223").default,e("df3c").createPage)},f4d0:function(n,t,e){"use strict";var u=e("4918");e.n(u).a},f83c:function(n,t,e){"use strict";e.d(t,"b",(function(){return i})),e.d(t,"c",(function(){return o})),e.d(t,"a",(function(){return u}));var u={pageLoading:function(){return e.e("components/pageLoading/pageLoading").then(e.bind(null,"7f33"))},mButton:function(){return e.e("components/mButton/mButton").then(e.bind(null,"fac5"))}},i=function(){this.$createElement;this._self._c},o=[]}},[["c64d","common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/vip/exchangeCoupon.js'});require("pages/vip/exchangeCoupon.js");