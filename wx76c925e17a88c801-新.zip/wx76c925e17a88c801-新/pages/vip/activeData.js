(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/vip/activeData" ], {
    "0b45": function(t, a, e) {
        "use strict";
        e.d(a, "b", function() {
            return i;
        }), e.d(a, "c", function() {
            return c;
        }), e.d(a, "a", function() {
            return n;
        });
        var n = {
            pageLoading: function() {
                return e.e("components/pageLoading/pageLoading").then(e.bind(null, "7f33"));
            },
            empty: function() {
                return e.e("components/empty/empty").then(e.bind(null, "f810"));
            }
        }, i = function() {
            this.$createElement;
            var t = (this._self._c, !this.pageData.list.length && 2 == this.pageData.status), a = 2 != this.pageData.status || this.pageData.list.length;
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: t,
                    g1: a
                }
            });
        }, c = [];
    },
    "2b59": function(t, a, e) {},
    "963e": function(t, a, e) {
        "use strict";
        (function(t) {
            var n = e("47a9");
            Object.defineProperty(a, "__esModule", {
                value: !0
            }), a.default = void 0;
            var i = {
                mixins: [ n(e("6337")).default ],
                data: function() {
                    return {
                        id: 1,
                        activeData: {}
                    };
                },
                onLoad: function() {
                    this.getData(), this.getList();
                },
                onReachBottom: function() {
                    this.loadMore();
                },
                onShareAppMessage: function(a) {
                    var e = this.getShareData();
                    return {
                        path: "/pages/index?salt=".concat(t.getStorageSync("userInfo").salt),
                        title: e.title,
                        imageUrl: e.img
                    };
                },
                onShareTimeline: function(a) {
                    var e = this.getShareData();
                    return {
                        path: "/pages/index?salt=".concat(t.getStorageSync("userInfo").salt),
                        title: e.title,
                        imageUrl: e.img
                    };
                },
                methods: {
                    getShareData: function() {
                        var a = t.getStorageSync("child"), e = t.getStorageSync("userInfo");
                        return [ {
                            title: "家庭积分制不得了!".concat(a.nickname, "最近都开始主动做起家务了，好棒呀~~"),
                            img: "".concat(this.ossMoUrl, "img_share_1.png")
                        }, {
                            title: "".concat(e.nickname, "@你:管理孩子要用积分制，孩子开心，家长省心~~"),
                            img: "".concat(this.ossMoUrl, "img_share_2.png")
                        }, {
                            title: "".concat(a.nickname, "的时间观念有进步了呀，玩游戏、看电视全靠自己积分兑~~"),
                            img: "".concat(this.ossMoUrl, "img_share_3.png")
                        } ][Math.floor(3 * Math.random())];
                    },
                    getData: function() {
                        var t = this;
                        this.$api.activeApi.activity({
                            activity_id: this.id
                        }, !0, this).then(function(a) {
                            t.activeData = a.data;
                        });
                    },
                    getList: function() {
                        var t = this;
                        this.$api.activeApi.inviteRecord({
                            activity_id: this.id,
                            page: this.pageData.page,
                            per_page: this.pageData.limit
                        }, !1, this).then(function(a) {
                            t.initend(a.data);
                        });
                    }
                }
            };
            a.default = i;
        }).call(this, e("df3c").default);
    },
    "971a": function(t, a, e) {
        "use strict";
        (function(t, a) {
            var n = e("47a9");
            e("e465"), n(e("3240"));
            var i = n(e("a8ef"));
            t.__webpack_require_UNI_MP_PLUGIN__ = e, a(i.default);
        }).call(this, e("3223").default, e("df3c").createPage);
    },
    a8ef: function(t, a, e) {
        "use strict";
        e.r(a);
        var n = e("0b45"), i = e("fddc");
        for (var c in i) [ "default" ].indexOf(c) < 0 && function(t) {
            e.d(a, t, function() {
                return i[t];
            });
        }(c);
        e("c22e");
        var o = e("828b"), r = Object(o.a)(i.default, n.b, n.c, !1, null, "280785e6", null, !1, n.a, void 0);
        a.default = r.exports;
    },
    c22e: function(t, a, e) {
        "use strict";
        var n = e("2b59");
        e.n(n).a;
    },
    fddc: function(t, a, e) {
        "use strict";
        e.r(a);
        var n = e("963e"), i = e.n(n);
        for (var c in n) [ "default" ].indexOf(c) < 0 && function(t) {
            e.d(a, t, function() {
                return n[t];
            });
        }(c);
        a.default = i.a;
    }
}, [ [ "971a", "common/runtime", "common/vendor" ] ] ]);