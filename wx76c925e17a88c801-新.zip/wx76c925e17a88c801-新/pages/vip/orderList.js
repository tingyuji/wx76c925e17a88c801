(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/vip/orderList" ], {
    "3e82": function(t, n, e) {
        "use strict";
        e.r(n);
        var i = e("f55c"), a = e.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(o);
        n.default = a.a;
    },
    6172: function(t, n, e) {
        "use strict";
        e.d(n, "b", function() {
            return a;
        }), e.d(n, "c", function() {
            return o;
        }), e.d(n, "a", function() {
            return i;
        });
        var i = {
            pageLoading: function() {
                return e.e("components/pageLoading/pageLoading").then(e.bind(null, "7f33"));
            },
            uniCountdown: function() {
                return e.e("components/uni-countdown/uni-countdown").then(e.bind(null, "6655"));
            },
            empty: function() {
                return e.e("components/empty/empty").then(e.bind(null, "f810"));
            }
        }, a = function() {
            this.$createElement;
            var t = (this._self._c, this.pageData.list.length || 0 == this.pageData.status);
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: t
                }
            });
        }, o = [];
    },
    "9d87": function(t, n, e) {
        "use strict";
        var i = e("cd98");
        e.n(i).a;
    },
    ca29: function(t, n, e) {
        "use strict";
        (function(t, n) {
            var i = e("47a9");
            e("e465"), i(e("3240"));
            var a = i(e("fd37"));
            t.__webpack_require_UNI_MP_PLUGIN__ = e, n(a.default);
        }).call(this, e("3223").default, e("df3c").createPage);
    },
    cd98: function(t, n, e) {},
    f55c: function(t, n, e) {
        "use strict";
        (function(t) {
            var i = e("47a9");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var a = {
                mixins: [ i(e("6337")).default ],
                data: function() {
                    return {
                        title: "Hello"
                    };
                },
                onLoad: function() {
                    this.getList();
                },
                onReachBottom: function() {
                    this.loadMore();
                },
                methods: {
                    getList: function() {
                        var t = this;
                        this.$api.vipApi.orderList({
                            status_map: "all",
                            page: this.pageData.page,
                            per_page: this.pageData.limit
                        }, !1, this).then(function(n) {
                            n.data.rows.filter(function(t) {
                                t.cancel_arr.countdown = t.cancel_arr.countdown + parseInt(new Date().getTime() / 1e3, 10);
                            }), t.initend(n.data);
                        });
                    },
                    timeup: function(t) {
                        t.status = 99, t.status_text = "已取消";
                    },
                    errTime: function() {},
                    cancel: function(t) {
                        var n = this;
                        this.$api.vipApi.orderCancel(t.id, {}, !0, this).then(function(e) {
                            n.$util.msg("订单取消成功"), t.status = 99, t.status_text = "已取消";
                        });
                    },
                    pay: function(n) {
                        var e = this;
                        this.loadingShow = !0, this.$api.vipApi.payVipOrder({
                            order_sn: n.order_sn,
                            trade_type: "JSAPI"
                        }, !1, this).then(function(i) {
                            var a = i.data.pay_data;
                            t.getProvider({
                                service: "payment",
                                success: function(i) {
                                    e.loadingShow = !1, t.requestPayment({
                                        provider: i.provider[0],
                                        timeStamp: a.timeStamp,
                                        nonceStr: a.nonceStr,
                                        package: a.package,
                                        signType: a.signType,
                                        paySign: a.paySign,
                                        success: function(t) {
                                            e.$api.vipApi.payVipCheck({
                                                order_sn: n.order_sn
                                            }, !0, e).then(function(t) {
                                                e.$util.msg("支付成功"), n.status = 9, n.status_text = "已支付";
                                            });
                                        }
                                    });
                                }
                            });
                        });
                    }
                }
            };
            n.default = a;
        }).call(this, e("df3c").default);
    },
    fd37: function(t, n, e) {
        "use strict";
        e.r(n);
        var i = e("6172"), a = e("3e82");
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(o);
        e("9d87");
        var u = e("828b"), r = Object(u.a)(a.default, i.b, i.c, !1, null, "634da538", null, !1, i.a, void 0);
        n.default = r.exports;
    }
}, [ [ "ca29", "common/runtime", "common/vendor" ] ] ]);