$gwx_XC_47=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_47 || [];
function gz$gwx_XC_47_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_47_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_47_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_47_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'content flex-column flex-align-center data-v-3bb07129'])
Z([3,'__l'])
Z([3,'data-v-3bb07129'])
Z([[7],[3,'loadingShow']])
Z([3,'2f42b9a4-1'])
Z([3,'record-wrap flex-column data-v-3bb07129'])
Z([[6],[[7],[3,'$root']],[3,'g0']])
Z(z[1])
Z(z[2])
Z([[2,'+'],[[7],[3,'ossMoUrl']],[1,'img_empty.png']])
Z([3,'100rpx'])
Z([3,'暂无记录'])
Z([3,'2f42b9a4-2'])
Z([[6],[[7],[3,'$root']],[3,'g1']])
Z(z[1])
Z([3,'data-v-3bb07129 vue-ref'])
Z([3,'slotModal'])
Z([1,false])
Z([3,'2f42b9a4-3'])
Z([[4],[[5],[1,'default']]])
Z(z[1])
Z([1,true])
Z(z[15])
Z([3,'绑定'])
Z([3,'防止帐号丢失和孩子数据隐私，请先绑定手机号码'])
Z([3,'mModalPhone'])
Z([3,'提示'])
Z([3,'2f42b9a4-4'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_47_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_47_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_47=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_47=true;
var x=['./pages/vip/activeRecord.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_47_1()
var oXO=_n('view')
_rz(z,oXO,'class',0,e,s,gg)
var lYO=_mz(z,'page-loading',['bind:__l',1,'class',1,'loadingShow_',2,'vueId',3],[],e,s,gg)
_(oXO,lYO)
var aZO=_n('view')
_rz(z,aZO,'class',5,e,s,gg)
var t1O=_v()
_(aZO,t1O)
if(_oz(z,6,e,s,gg)){t1O.wxVkey=1
var b3O=_mz(z,'empty',['bind:__l',7,'class',1,'icon',2,'paddingTop',3,'textA',4,'vueId',5],[],e,s,gg)
_(t1O,b3O)
}
var e2O=_v()
_(aZO,e2O)
if(_oz(z,13,e,s,gg)){e2O.wxVkey=1
}
t1O.wxXCkey=1
t1O.wxXCkey=3
e2O.wxXCkey=1
_(oXO,aZO)
var o4O=_mz(z,'slot-modal',['bind:__l',14,'class',1,'data-ref',2,'maskClose',3,'vueId',4,'vueSlots',5],[],e,s,gg)
_(oXO,o4O)
var x5O=_mz(z,'m-modal',['bind:__l',20,'bindPhone',1,'class',2,'confirmText',3,'content',4,'data-ref',5,'title',6,'vueId',7],[],e,s,gg)
_(oXO,x5O)
_(r,oXO)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_47";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_47();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/vip/activeRecord.wxml'] = [$gwx_XC_47, './pages/vip/activeRecord.wxml'];else __wxAppCode__['pages/vip/activeRecord.wxml'] = $gwx_XC_47( './pages/vip/activeRecord.wxml' );
	;__wxRoute = "pages/vip/activeRecord";__wxRouteBegin = true;__wxAppCurrentFile__="pages/vip/activeRecord.js";define("pages/vip/activeRecord.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/vip/activeRecord"],{"0f84":function(t,n,e){},"1c27":function(t,n,e){"use strict";(function(t,n){var a=e("47a9");e("e465"),a(e("3240"));var o=a(e("db82"));t.__webpack_require_UNI_MP_PLUGIN__=e,n(o.default)}).call(this,e("3223").default,e("df3c").createPage)},"392b":function(t,n,e){"use strict";e.d(n,"b",(function(){return o})),e.d(n,"c",(function(){return i})),e.d(n,"a",(function(){return a}));var a={pageLoading:function(){return e.e("components/pageLoading/pageLoading").then(e.bind(null,"7f33"))},empty:function(){return e.e("components/empty/empty").then(e.bind(null,"f810"))},slotModal:function(){return e.e("components/slotModal/slotModal").then(e.bind(null,"8d9e"))},mModal:function(){return e.e("components/mModal/mModal").then(e.bind(null,"68ea"))}},o=function(){var t=this,n=(t.$createElement,t._self._c,!t.pageData.list.length&&2==t.pageData.status),e=2!=t.pageData.status||t.pageData.list.length;t._isMounted||(t.e0=function(n){return t.$refs.slotModal.hide()}),t.$mp.data=Object.assign({},{$root:{g0:n,g1:e}})},i=[]},"94ac":function(t,n,e){"use strict";e.r(n);var a=e("d85d"),o=e.n(a);for(var i in a)["default"].indexOf(i)<0&&function(t){e.d(n,t,(function(){return a[t]}))}(i);n.default=o.a},b5a0:function(t,n,e){"use strict";var a=e("0f84");e.n(a).a},d85d:function(t,n,e){"use strict";(function(t){var a=e("47a9");Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var o={mixins:[a(e("6337")).default],data:function(){return{salt:"",loading:!0,account:{},shareString:""}},onLoad:function(){var n=this;this.$nextTick((function(){n.salt=t.getStorageSync("userInfo").salt})),this.getList(),this.getAccount(),t.$off("withdrawal").$on("withdrawal",(function(t){n.refresh(),n.getAccount()})),this.$nextTick((function(){var e=t.getStorageSync("userInfo");n.shareString="现一个超级实用工具——星目标，帮助3-12岁孩子养成生活、学习、成长习惯，让家庭积分卓有成效，让孩子轻松快乐升级。现在通过我的链接注册，立享超值优惠，来吧，良性亲子关系从此刻开始～ https://h5.xingmubiao.com/#/pages/invite?salt=".concat(e.salt,"&name=").concat(encodeURIComponent(e.nickname))}))},onShareAppMessage:function(n){var e=this.getShareData();return{path:"/pages/index?salt=".concat(t.getStorageSync("userInfo").salt),title:e.title,imageUrl:e.img}},onShareTimeline:function(n){var e=this.getShareData();return{path:"/pages/index?salt=".concat(t.getStorageSync("userInfo").salt),title:e.title,imageUrl:e.img}},onReachBottom:function(){this.loadMore()},methods:{share:function(){this.$refs.slotModal.hide()},getShareData:function(){var n=t.getStorageSync("child"),e=t.getStorageSync("userInfo");return[{title:"家庭积分制不得了!".concat(n.nickname,"最近都开始主动做起家务了，好棒呀~~"),img:"".concat(this.ossMoUrl,"img_share_1.png")},{title:"".concat(e.nickname,"@你:管理孩子要用积分制，孩子开心，家长省心~~"),img:"".concat(this.ossMoUrl,"img_share_2.png")},{title:"".concat(n.nickname,"的时间观念有进步了呀，玩游戏、看电视全靠自己积分兑~~"),img:"".concat(this.ossMoUrl,"img_share_3.png")}][Math.floor(3*Math.random())]},getAccount:function(){var t=this;this.$api.commonApi.balance({},this.loading,this).then((function(n){t.loading=!1,t.account=n.data}))},getList:function(){var t=this;this.$api.commonApi.balance_logs({page:this.pageData.page,per_page:this.pageData.limit},!1,this).then((function(n){t.initend(n.data)}))},copy:function(){var n=this;t.setClipboardData({data:n.shareString,success:function(){n.$util.msg("复制成功")}})},invite:function(){if(!t.getStorageSync("userInfo").mobile)return this.$refs.mModalPhone.show();this.$refs.slotModal.show()},withdraw:function(){if(!t.getStorageSync("userInfo").mobile)return this.$refs.mModalPhone.show();this.goPage("/pages/vip/withdraw")},service:function(){this.goPage("/pages/common/hostWachat")}}};n.default=o}).call(this,e("df3c").default)},db82:function(t,n,e){"use strict";e.r(n);var a=e("392b"),o=e("94ac");for(var i in o)["default"].indexOf(i)<0&&function(t){e.d(n,t,(function(){return o[t]}))}(i);e("b5a0");var c=e("828b"),s=Object(c.a)(o.default,a.b,a.c,!1,null,"3bb07129",null,!1,a.a,void 0);n.default=s.exports}},[["1c27","common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/vip/activeRecord.js'});require("pages/vip/activeRecord.js");