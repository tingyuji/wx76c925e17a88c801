$gwx_XC_50=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_50 || [];
function gz$gwx_XC_50_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_50_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_50_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_50_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'content data-v-634da538'])
Z([3,'__l'])
Z([3,'data-v-634da538'])
Z([[7],[3,'loadingShow']])
Z([3,'2dbd8396-1'])
Z([3,'__i0__'])
Z([3,'order'])
Z([[6],[[7],[3,'pageData']],[3,'list']])
Z([3,'id'])
Z([[2,'=='],[[6],[[7],[3,'order']],[3,'status']],[1,0]])
Z([3,'rbga(0,0,0,0)'])
Z(z[1])
Z([3,'__e'])
Z(z[12])
Z([3,'30rpx'])
Z(z[2])
Z([3,'#999999'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^timeup']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'timeup']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'pageData.list']],[1,'id']],[[6],[[7],[3,'order']],[3,'id']]]]]]]]]]]]]]],[[4],[[5],[[5],[1,'^errTime']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'errTime']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'pageData.list']],[1,'id']],[[6],[[7],[3,'order']],[3,'id']]]]]]]]]]]]]]]])
Z([1,true])
Z([1,false])
Z(z[16])
Z([[6],[[6],[[7],[3,'order']],[3,'cancel_arr']],[3,'countdown']])
Z([[2,'+'],[1,'2dbd8396-2-'],[[7],[3,'__i0__']]])
Z([[6],[[7],[3,'$root']],[3,'g0']])
Z([[2,'&&'],[[2,'=='],[[6],[[7],[3,'pageData']],[3,'total']],[1,0]],[[2,'=='],[[6],[[7],[3,'pageData']],[3,'status']],[1,2]]])
Z(z[1])
Z(z[2])
Z([3,'https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/img_empty.png'])
Z([3,'暂无优惠券'])
Z([3,'2dbd8396-3'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_50_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_50_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_50=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_50=true;
var x=['./pages/vip/orderList.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_50_1()
var xAQ=_n('view')
_rz(z,xAQ,'class',0,e,s,gg)
var cDQ=_mz(z,'page-loading',['bind:__l',1,'class',1,'loadingShow_',2,'vueId',3],[],e,s,gg)
_(xAQ,cDQ)
var hEQ=_v()
_(xAQ,hEQ)
var oFQ=function(oHQ,cGQ,lIQ,gg){
var tKQ=_v()
_(lIQ,tKQ)
if(_oz(z,9,oHQ,cGQ,gg)){tKQ.wxVkey=1
var eLQ=_mz(z,'uni-countdown',['backgroundColor',10,'bind:__l',1,'bind:errTime',2,'bind:timeup',3,'boxWidth',4,'class',5,'color',6,'data-event-opts',7,'noInter',8,'showDay',9,'splitorColor',10,'timestamp',11,'vueId',12],[],oHQ,cGQ,gg)
_(tKQ,eLQ)
}
tKQ.wxXCkey=1
tKQ.wxXCkey=3
return lIQ
}
hEQ.wxXCkey=4
_2z(z,7,oFQ,e,s,gg,hEQ,'order','__i0__','id')
var oBQ=_v()
_(xAQ,oBQ)
if(_oz(z,23,e,s,gg)){oBQ.wxVkey=1
}
var fCQ=_v()
_(xAQ,fCQ)
if(_oz(z,24,e,s,gg)){fCQ.wxVkey=1
var bMQ=_mz(z,'empty',['bind:__l',25,'class',1,'icon',2,'textA',3,'vueId',4],[],e,s,gg)
_(fCQ,bMQ)
}
oBQ.wxXCkey=1
fCQ.wxXCkey=1
fCQ.wxXCkey=3
_(r,xAQ)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_50";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_50();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/vip/orderList.wxml'] = [$gwx_XC_50, './pages/vip/orderList.wxml'];else __wxAppCode__['pages/vip/orderList.wxml'] = $gwx_XC_50( './pages/vip/orderList.wxml' );
	;__wxRoute = "pages/vip/orderList";__wxRouteBegin = true;__wxAppCurrentFile__="pages/vip/orderList.js";define("pages/vip/orderList.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/vip/orderList"],{"3e82":function(t,n,e){"use strict";e.r(n);var i=e("f55c"),a=e.n(i);for(var o in i)["default"].indexOf(o)<0&&function(t){e.d(n,t,(function(){return i[t]}))}(o);n.default=a.a},6172:function(t,n,e){"use strict";e.d(n,"b",(function(){return a})),e.d(n,"c",(function(){return o})),e.d(n,"a",(function(){return i}));var i={pageLoading:function(){return e.e("components/pageLoading/pageLoading").then(e.bind(null,"7f33"))},uniCountdown:function(){return e.e("components/uni-countdown/uni-countdown").then(e.bind(null,"6655"))},empty:function(){return e.e("components/empty/empty").then(e.bind(null,"f810"))}},a=function(){this.$createElement;var t=(this._self._c,this.pageData.list.length||0==this.pageData.status);this.$mp.data=Object.assign({},{$root:{g0:t}})},o=[]},"9d87":function(t,n,e){"use strict";var i=e("cd98");e.n(i).a},ca29:function(t,n,e){"use strict";(function(t,n){var i=e("47a9");e("e465"),i(e("3240"));var a=i(e("fd37"));t.__webpack_require_UNI_MP_PLUGIN__=e,n(a.default)}).call(this,e("3223").default,e("df3c").createPage)},cd98:function(t,n,e){},f55c:function(t,n,e){"use strict";(function(t){var i=e("47a9");Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a={mixins:[i(e("6337")).default],data:function(){return{title:"Hello"}},onLoad:function(){this.getList()},onReachBottom:function(){this.loadMore()},methods:{getList:function(){var t=this;this.$api.vipApi.orderList({status_map:"all",page:this.pageData.page,per_page:this.pageData.limit},!1,this).then((function(n){n.data.rows.filter((function(t){t.cancel_arr.countdown=t.cancel_arr.countdown+parseInt((new Date).getTime()/1e3,10)})),t.initend(n.data)}))},timeup:function(t){t.status=99,t.status_text="已取消"},errTime:function(){},cancel:function(t){var n=this;this.$api.vipApi.orderCancel(t.id,{},!0,this).then((function(e){n.$util.msg("订单取消成功"),t.status=99,t.status_text="已取消"}))},pay:function(n){var e=this;this.loadingShow=!0,this.$api.vipApi.payVipOrder({order_sn:n.order_sn,trade_type:"JSAPI"},!1,this).then((function(i){var a=i.data.pay_data;t.getProvider({service:"payment",success:function(i){e.loadingShow=!1,t.requestPayment({provider:i.provider[0],timeStamp:a.timeStamp,nonceStr:a.nonceStr,package:a.package,signType:a.signType,paySign:a.paySign,success:function(t){e.$api.vipApi.payVipCheck({order_sn:n.order_sn},!0,e).then((function(t){e.$util.msg("支付成功"),n.status=9,n.status_text="已支付"}))}})}})}))}}};n.default=a}).call(this,e("df3c").default)},fd37:function(t,n,e){"use strict";e.r(n);var i=e("6172"),a=e("3e82");for(var o in a)["default"].indexOf(o)<0&&function(t){e.d(n,t,(function(){return a[t]}))}(o);e("9d87");var u=e("828b"),r=Object(u.a)(a.default,i.b,i.c,!1,null,"634da538",null,!1,i.a,void 0);n.default=r.exports}},[["ca29","common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/vip/orderList.js'});require("pages/vip/orderList.js");