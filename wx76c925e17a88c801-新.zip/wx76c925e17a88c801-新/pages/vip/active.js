(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/vip/active" ], {
    "27d5": function(t, n, e) {
        "use strict";
        (function(t) {
            var a = e("47a9");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var i = a(e("7eb4")), o = a(e("ee10")), c = {
                data: function() {
                    return {
                        id: 1,
                        activeData: {},
                        account: {},
                        shareString: ""
                    };
                },
                onLoad: function() {
                    var n = this;
                    return (0, o.default)(i.default.mark(function e() {
                        return i.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.next = 2, n.$onLaunched;

                              case 2:
                                n.getData(), n.getAccount(), n.$api.commonApi.expert({}, !1, n), n.$nextTick(function() {
                                    var e = t.getStorageSync("userInfo");
                                    n.shareString = "科学育儿神器——星目标，3-12岁儿童积分制管理，轻松培养孩子好习惯！现在通过我的链接注册，立即享受超值优惠，来吧，良性亲子关系从此刻开始~ https://h5.xingmubiao.com/#/pages/invite?salt=".concat(e.salt);
                                });

                              case 6:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                    }))();
                },
                methods: {
                    getData: function() {
                        var t = this;
                        this.$api.activeApi.activity({
                            activity_id: this.id
                        }, !0, this).then(function(n) {
                            t.activeData = n.data;
                        });
                    },
                    getAccount: function() {
                        var t = this;
                        this.$api.commonApi.balance({}, !0, this).then(function(n) {
                            t.account = n.data;
                        });
                    },
                    copy: function() {
                        var n = this;
                        t.setClipboardData({
                            data: n.shareString,
                            success: function() {
                                n.$util.msg("复制成功");
                            }
                        });
                    },
                    invite: function() {
                        if (!t.getStorageSync("userInfo").mobile) return this.$refs.mModalPhone.show();
                        this.$refs.slotModal.show();
                    },
                    share: function() {
                        this.$refs.slotModal.hide();
                    }
                }
            };
            n.default = c;
        }).call(this, e("df3c").default);
    },
    "4fa3": function(t, n, e) {},
    "5a65": function(t, n, e) {
        "use strict";
        e.r(n);
        var a = e("27d5"), i = e.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(o);
        n.default = i.a;
    },
    cf3a: function(t, n, e) {
        "use strict";
        var a = e("4fa3");
        e.n(a).a;
    },
    ddb7: function(t, n, e) {
        "use strict";
        e.r(n);
        var a = e("ff7d"), i = e("5a65");
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(o);
        e("cf3a");
        var c = e("828b"), u = Object(c.a)(i.default, a.b, a.c, !1, null, "07d7097b", null, !1, a.a, void 0);
        n.default = u.exports;
    },
    eb7f: function(t, n, e) {
        "use strict";
        (function(t, n) {
            var a = e("47a9");
            e("e465"), a(e("3240"));
            var i = a(e("ddb7"));
            t.__webpack_require_UNI_MP_PLUGIN__ = e, n(i.default);
        }).call(this, e("3223").default, e("df3c").createPage);
    },
    ff7d: function(t, n, e) {
        "use strict";
        e.d(n, "b", function() {
            return i;
        }), e.d(n, "c", function() {
            return o;
        }), e.d(n, "a", function() {
            return a;
        });
        var a = {
            pageLoading: function() {
                return e.e("components/pageLoading/pageLoading").then(e.bind(null, "7f33"));
            },
            slotModal: function() {
                return e.e("components/slotModal/slotModal").then(e.bind(null, "8d9e"));
            },
            mModal: function() {
                return e.e("components/mModal/mModal").then(e.bind(null, "68ea"));
            }
        }, i = function() {
            var t = this;
            t.$createElement;
            t._self._c, t._isMounted || (t.e0 = function(n) {
                return t.$refs.slotModal.hide();
            });
        }, o = [];
    }
}, [ [ "eb7f", "common/runtime", "common/vendor" ] ] ]);