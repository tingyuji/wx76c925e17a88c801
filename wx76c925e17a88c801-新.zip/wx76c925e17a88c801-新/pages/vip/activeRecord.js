(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/vip/activeRecord" ], {
    "0f84": function(t, n, e) {},
    "1c27": function(t, n, e) {
        "use strict";
        (function(t, n) {
            var a = e("47a9");
            e("e465"), a(e("3240"));
            var o = a(e("db82"));
            t.__webpack_require_UNI_MP_PLUGIN__ = e, n(o.default);
        }).call(this, e("3223").default, e("df3c").createPage);
    },
    "392b": function(t, n, e) {
        "use strict";
        e.d(n, "b", function() {
            return o;
        }), e.d(n, "c", function() {
            return i;
        }), e.d(n, "a", function() {
            return a;
        });
        var a = {
            pageLoading: function() {
                return e.e("components/pageLoading/pageLoading").then(e.bind(null, "7f33"));
            },
            empty: function() {
                return e.e("components/empty/empty").then(e.bind(null, "f810"));
            },
            slotModal: function() {
                return e.e("components/slotModal/slotModal").then(e.bind(null, "8d9e"));
            },
            mModal: function() {
                return e.e("components/mModal/mModal").then(e.bind(null, "68ea"));
            }
        }, o = function() {
            var t = this, n = (t.$createElement, t._self._c, !t.pageData.list.length && 2 == t.pageData.status), e = 2 != t.pageData.status || t.pageData.list.length;
            t._isMounted || (t.e0 = function(n) {
                return t.$refs.slotModal.hide();
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    g0: n,
                    g1: e
                }
            });
        }, i = [];
    },
    "94ac": function(t, n, e) {
        "use strict";
        e.r(n);
        var a = e("d85d"), o = e.n(a);
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(i);
        n.default = o.a;
    },
    b5a0: function(t, n, e) {
        "use strict";
        var a = e("0f84");
        e.n(a).a;
    },
    d85d: function(t, n, e) {
        "use strict";
        (function(t) {
            var a = e("47a9");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var o = {
                mixins: [ a(e("6337")).default ],
                data: function() {
                    return {
                        salt: "",
                        loading: !0,
                        account: {},
                        shareString: ""
                    };
                },
                onLoad: function() {
                    var n = this;
                    this.$nextTick(function() {
                        n.salt = t.getStorageSync("userInfo").salt;
                    }), this.getList(), this.getAccount(), t.$off("withdrawal").$on("withdrawal", function(t) {
                        n.refresh(), n.getAccount();
                    }), this.$nextTick(function() {
                        var e = t.getStorageSync("userInfo");
                        n.shareString = "现一个超级实用工具——星目标，帮助3-12岁孩子养成生活、学习、成长习惯，让家庭积分卓有成效，让孩子轻松快乐升级。现在通过我的链接注册，立享超值优惠，来吧，良性亲子关系从此刻开始～ https://h5.xingmubiao.com/#/pages/invite?salt=".concat(e.salt, "&name=").concat(encodeURIComponent(e.nickname));
                    });
                },
                onShareAppMessage: function(n) {
                    var e = this.getShareData();
                    return {
                        path: "/pages/index?salt=".concat(t.getStorageSync("userInfo").salt),
                        title: e.title,
                        imageUrl: e.img
                    };
                },
                onShareTimeline: function(n) {
                    var e = this.getShareData();
                    return {
                        path: "/pages/index?salt=".concat(t.getStorageSync("userInfo").salt),
                        title: e.title,
                        imageUrl: e.img
                    };
                },
                onReachBottom: function() {
                    this.loadMore();
                },
                methods: {
                    share: function() {
                        this.$refs.slotModal.hide();
                    },
                    getShareData: function() {
                        var n = t.getStorageSync("child"), e = t.getStorageSync("userInfo");
                        return [ {
                            title: "家庭积分制不得了!".concat(n.nickname, "最近都开始主动做起家务了，好棒呀~~"),
                            img: "".concat(this.ossMoUrl, "img_share_1.png")
                        }, {
                            title: "".concat(e.nickname, "@你:管理孩子要用积分制，孩子开心，家长省心~~"),
                            img: "".concat(this.ossMoUrl, "img_share_2.png")
                        }, {
                            title: "".concat(n.nickname, "的时间观念有进步了呀，玩游戏、看电视全靠自己积分兑~~"),
                            img: "".concat(this.ossMoUrl, "img_share_3.png")
                        } ][Math.floor(3 * Math.random())];
                    },
                    getAccount: function() {
                        var t = this;
                        this.$api.commonApi.balance({}, this.loading, this).then(function(n) {
                            t.loading = !1, t.account = n.data;
                        });
                    },
                    getList: function() {
                        var t = this;
                        this.$api.commonApi.balance_logs({
                            page: this.pageData.page,
                            per_page: this.pageData.limit
                        }, !1, this).then(function(n) {
                            t.initend(n.data);
                        });
                    },
                    copy: function() {
                        var n = this;
                        t.setClipboardData({
                            data: n.shareString,
                            success: function() {
                                n.$util.msg("复制成功");
                            }
                        });
                    },
                    invite: function() {
                        if (!t.getStorageSync("userInfo").mobile) return this.$refs.mModalPhone.show();
                        this.$refs.slotModal.show();
                    },
                    withdraw: function() {
                        if (!t.getStorageSync("userInfo").mobile) return this.$refs.mModalPhone.show();
                        this.goPage("/pages/vip/withdraw");
                    },
                    service: function() {
                        this.goPage("/pages/common/hostWachat");
                    }
                }
            };
            n.default = o;
        }).call(this, e("df3c").default);
    },
    db82: function(t, n, e) {
        "use strict";
        e.r(n);
        var a = e("392b"), o = e("94ac");
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(i);
        e("b5a0");
        var c = e("828b"), s = Object(c.a)(o.default, a.b, a.c, !1, null, "3bb07129", null, !1, a.a, void 0);
        n.default = s.exports;
    }
}, [ [ "1c27", "common/runtime", "common/vendor" ] ] ]);