(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/common/hostWachat" ], {
    "0b06": function(n, t, e) {},
    "1e8a": function(n, t, e) {
        "use strict";
        (function(n) {
            var a = e("47a9");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = a(e("7eb4")), u = a(e("ee10")), c = (a(e("ed82")), {
                data: function() {
                    return {
                        title: "Hello"
                    };
                },
                onLoad: function() {},
                methods: {
                    saveImg: function() {
                        var t = this;
                        return (0, u.default)(o.default.mark(function e() {
                            var a;
                            return o.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    a = t, t.loadingShow = !0, n.downloadFile({
                                        url: "".concat(t.ossMoUrl, "img_wechat_host1.png"),
                                        success: function(t) {
                                            200 === t.statusCode && n.saveImageToPhotosAlbum({
                                                filePath: t.tempFilePath,
                                                success: function() {
                                                    a.loadingShow = !1, a.$util.msg("保存成功");
                                                }
                                            });
                                        }
                                    });

                                  case 3:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    }
                }
            });
            t.default = c;
        }).call(this, e("df3c").default);
    },
    "6c1f": function(n, t, e) {
        "use strict";
        e.r(t);
        var a = e("1e8a"), o = e.n(a);
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(u);
        t.default = o.a;
    },
    7369: function(n, t, e) {
        "use strict";
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return u;
        }), e.d(t, "a", function() {
            return a;
        });
        var a = {
            pageLoading: function() {
                return e.e("components/pageLoading/pageLoading").then(e.bind(null, "7f33"));
            },
            mButton: function() {
                return e.e("components/mButton/mButton").then(e.bind(null, "fac5"));
            }
        }, o = function() {
            this.$createElement;
            this._self._c;
        }, u = [];
    },
    bb7b: function(n, t, e) {
        "use strict";
        (function(n, t) {
            var a = e("47a9");
            e("e465"), a(e("3240"));
            var o = a(e("d928"));
            n.__webpack_require_UNI_MP_PLUGIN__ = e, t(o.default);
        }).call(this, e("3223").default, e("df3c").createPage);
    },
    d928: function(n, t, e) {
        "use strict";
        e.r(t);
        var a = e("7369"), o = e("6c1f");
        for (var u in o) [ "default" ].indexOf(u) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(u);
        e("da11");
        var c = e("828b"), i = Object(c.a)(o.default, a.b, a.c, !1, null, "4fe58985", null, !1, a.a, void 0);
        t.default = i.exports;
    },
    da11: function(n, t, e) {
        "use strict";
        var a = e("0b06");
        e.n(a).a;
    }
}, [ [ "bb7b", "common/runtime", "common/vendor" ] ] ]);