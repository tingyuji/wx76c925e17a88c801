$gwx_XC_24=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_24 || [];
function gz$gwx_XC_24_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_24_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_24_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_24_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'content flex-column flex-align-center data-v-4fe58985'])
Z([3,'__l'])
Z([3,'data-v-4fe58985'])
Z([[7],[3,'loadingShow']])
Z([3,'48e40f7e-1'])
Z(z[1])
Z(z[2])
Z([3,'长按二维码识别添加'])
Z([3,'48e40f7e-2'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_24_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_24_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_24=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_24=true;
var x=['./pages/common/hostWachat.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_24_1()
var oDE=_n('view')
_rz(z,oDE,'class',0,e,s,gg)
var cEE=_mz(z,'page-loading',['bind:__l',1,'class',1,'loadingShow_',2,'vueId',3],[],e,s,gg)
_(oDE,cEE)
var oFE=_mz(z,'m-button',['bind:__l',5,'class',1,'text',2,'vueId',3],[],e,s,gg)
_(oDE,oFE)
_(r,oDE)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_24";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_24();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/common/hostWachat.wxml'] = [$gwx_XC_24, './pages/common/hostWachat.wxml'];else __wxAppCode__['pages/common/hostWachat.wxml'] = $gwx_XC_24( './pages/common/hostWachat.wxml' );
	;__wxRoute = "pages/common/hostWachat";__wxRouteBegin = true;__wxAppCurrentFile__="pages/common/hostWachat.js";define("pages/common/hostWachat.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/common/hostWachat"],{"0b06":function(n,t,e){},"1e8a":function(n,t,e){"use strict";(function(n){var a=e("47a9");Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var o=a(e("7eb4")),u=a(e("ee10")),c=(a(e("ed82")),{data:function(){return{title:"Hello"}},onLoad:function(){},methods:{saveImg:function(){var t=this;return(0,u.default)(o.default.mark((function e(){var a;return o.default.wrap((function(e){for(;;)switch(e.prev=e.next){case 0:a=t,t.loadingShow=!0,n.downloadFile({url:"".concat(t.ossMoUrl,"img_wechat_host1.png"),success:function(t){200===t.statusCode&&n.saveImageToPhotosAlbum({filePath:t.tempFilePath,success:function(){a.loadingShow=!1,a.$util.msg("保存成功")}})}});case 3:case"end":return e.stop()}}),e)})))()}}});t.default=c}).call(this,e("df3c").default)},"6c1f":function(n,t,e){"use strict";e.r(t);var a=e("1e8a"),o=e.n(a);for(var u in a)["default"].indexOf(u)<0&&function(n){e.d(t,n,(function(){return a[n]}))}(u);t.default=o.a},7369:function(n,t,e){"use strict";e.d(t,"b",(function(){return o})),e.d(t,"c",(function(){return u})),e.d(t,"a",(function(){return a}));var a={pageLoading:function(){return e.e("components/pageLoading/pageLoading").then(e.bind(null,"7f33"))},mButton:function(){return e.e("components/mButton/mButton").then(e.bind(null,"fac5"))}},o=function(){this.$createElement;this._self._c},u=[]},bb7b:function(n,t,e){"use strict";(function(n,t){var a=e("47a9");e("e465"),a(e("3240"));var o=a(e("d928"));n.__webpack_require_UNI_MP_PLUGIN__=e,t(o.default)}).call(this,e("3223").default,e("df3c").createPage)},d928:function(n,t,e){"use strict";e.r(t);var a=e("7369"),o=e("6c1f");for(var u in o)["default"].indexOf(u)<0&&function(n){e.d(t,n,(function(){return o[n]}))}(u);e("da11");var c=e("828b"),i=Object(c.a)(o.default,a.b,a.c,!1,null,"4fe58985",null,!1,a.a,void 0);t.default=i.exports},da11:function(n,t,e){"use strict";var a=e("0b06");e.n(a).a}},[["bb7b","common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/common/hostWachat.js'});require("pages/common/hostWachat.js");