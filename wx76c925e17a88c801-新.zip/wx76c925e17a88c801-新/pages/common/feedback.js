(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/common/feedback" ], {
    "291d": function(n, t, e) {},
    "425c": function(n, t, e) {
        "use strict";
        e.r(t);
        var i = e("c99d"), u = e.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(n) {
            e.d(t, n, function() {
                return i[n];
            });
        }(o);
        t.default = u.a;
    },
    "4a0d": function(n, t, e) {
        "use strict";
        (function(n, t) {
            var i = e("47a9");
            e("e465"), i(e("3240"));
            var u = i(e("5840"));
            n.__webpack_require_UNI_MP_PLUGIN__ = e, t(u.default);
        }).call(this, e("3223").default, e("df3c").createPage);
    },
    5840: function(n, t, e) {
        "use strict";
        e.r(t);
        var i = e("dd46"), u = e("425c");
        for (var o in u) [ "default" ].indexOf(o) < 0 && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(o);
        e("8cd6");
        var c = e("828b"), a = Object(c.a)(u.default, i.b, i.c, !1, null, "4386ba1b", null, !1, i.a, void 0);
        t.default = a.exports;
    },
    "8cd6": function(n, t, e) {
        "use strict";
        var i = e("291d");
        e.n(i).a;
    },
    c99d: function(n, t, e) {
        "use strict";
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var e = {
                data: function() {
                    return {
                        type: "",
                        typeArr: [ {
                            name: "账号问题"
                        }, {
                            name: "支付问题"
                        }, {
                            name: "功能问题"
                        }, {
                            name: "兑换问题"
                        }, {
                            name: "其他问题"
                        } ],
                        contents: "",
                        images: []
                    };
                },
                methods: {
                    mPickerSubmit: function(n) {
                        this.type = this.typeArr[n].name;
                    },
                    moveImage: function(n, t) {
                        var e = JSON.parse(n);
                        e.length > 0 && e.sort(function(n, t) {
                            return n.index - t.index;
                        }), this.images = e;
                    },
                    upload: function(n) {
                        var t = JSON.parse(n);
                        this.images = t;
                    },
                    submit: function() {
                        var n = this;
                        if (!this.type) return this.$util.msg("请选择问题类型");
                        if (!this.contents) return this.$util.msg("请填写反馈内容");
                        var t = [];
                        this.images.length && this.images.filter(function(n) {
                            t.push(n.image);
                        }), this.$api.commonApi.feedback({
                            type: this.type,
                            contents: this.contents,
                            images: t
                        }, !0, this).then(function(t) {
                            n.$refs.mModal.show();
                        });
                    },
                    back: function() {
                        n.navigateBack();
                    }
                }
            };
            t.default = e;
        }).call(this, e("df3c").default);
    },
    dd46: function(n, t, e) {
        "use strict";
        e.d(t, "b", function() {
            return u;
        }), e.d(t, "c", function() {
            return o;
        }), e.d(t, "a", function() {
            return i;
        });
        var i = {
            multipleImg: function() {
                return Promise.all([ e.e("common/vendor"), e.e("components/multipleImg/multipleImg") ]).then(e.bind(null, "644b"));
            },
            mButton: function() {
                return e.e("components/mButton/mButton").then(e.bind(null, "fac5"));
            },
            mPicker: function() {
                return e.e("components/mPicker/mPicker").then(e.bind(null, "e94f"));
            },
            mModal: function() {
                return e.e("components/mModal/mModal").then(e.bind(null, "68ea"));
            }
        }, u = function() {
            var n = this;
            n.$createElement;
            n._self._c, n._isMounted || (n.e0 = function(t) {
                return n.$refs.mPicker.show();
            });
        }, o = [];
    }
}, [ [ "4a0d", "common/runtime", "common/vendor" ] ] ]);