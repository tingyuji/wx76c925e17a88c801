(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/common/playVideo" ], {
    "090e": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("db15"), c = n("5b07");
        for (var u in c) [ "default" ].indexOf(u) < 0 && function(e) {
            n.d(t, e, function() {
                return c[e];
            });
        }(u);
        n("2d4a");
        var r = n("828b"), i = Object(r.a)(c.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = i.exports;
    },
    "1ad6": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var a = n("47a9");
            n("e465"), a(n("3240"));
            var c = a(n("090e"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(c.default);
        }).call(this, n("3223").default, n("df3c").createPage);
    },
    "2cee": function(e, t, n) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = {
                data: function() {
                    return {
                        autoplay: !1,
                        loop: !1,
                        currentTime: 0,
                        src: ""
                    };
                },
                onLoad: function(e) {
                    e && e.src && (this.src = e.src), e && e.currentTime && (this.currentTime = e.currentTime);
                },
                methods: {
                    loadedmetadata: function() {
                        e.createVideoContext("video", this).play();
                    }
                }
            };
            t.default = n;
        }).call(this, n("df3c").default);
    },
    "2d4a": function(e, t, n) {
        "use strict";
        var a = n("83fe");
        n.n(a).a;
    },
    "5b07": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("2cee"), c = n.n(a);
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(u);
        t.default = c.a;
    },
    "83fe": function(e, t, n) {},
    db15: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return c;
        }), n.d(t, "a", function() {});
        var a = function() {
            this.$createElement;
            this._self._c;
        }, c = [];
    }
}, [ [ "1ad6", "common/runtime", "common/vendor" ] ] ]);