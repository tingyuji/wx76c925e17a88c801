(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/clock" ], {
    "47f2": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0, t.default = {
            data: function() {
                return {
                    src: "https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/cry.json",
                    src1: "https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/good.json",
                    src2: "https://mp-eeab6da6-80cd-4e80-844a-66b2a7203834.cdn.bspapp.com/cloudstorage/7b538fb7-d2d5-4524-bf21-6c20e3b5ce6f.json",
                    src3: "https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/excellent.json"
                };
            },
            methods: {
                onLoopComplete: function(e) {}
            }
        };
    },
    "6b56": function(e, t, n) {
        "use strict";
        n.r(t);
        var c = n("47f2"), o = n.n(c);
        for (var i in c) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return c[e];
            });
        }(i);
        t.default = o.a;
    },
    "7e5f": function(e, t, n) {
        "use strict";
        n.r(t);
        var c = n("fd2c"), o = n("6b56");
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(i);
        n("d683");
        var s = n("828b"), r = Object(s.a)(o.default, c.b, c.c, !1, null, null, null, !1, c.a, void 0);
        t.default = r.exports;
    },
    a2b6: function(e, t, n) {},
    c5cb: function(e, t, n) {
        "use strict";
        (function(e, t) {
            var c = n("47a9");
            n("e465"), c(n("3240"));
            var o = c(n("7e5f"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(o.default);
        }).call(this, n("3223").default, n("df3c").createPage);
    },
    d683: function(e, t, n) {
        "use strict";
        var c = n("a2b6");
        n.n(c).a;
    },
    fd2c: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {
            return c;
        });
        var c = {
            cLottie: function() {
                return Promise.all([ n.e("common/vendor"), n.e("uni_modules/c-lottie/components/c-lottie/c-lottie") ]).then(n.bind(null, "9b1b"));
            }
        }, o = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(t) {
                e.src = "https://mp-eeab6da6-80cd-4e80-844a-66b2a7203834.cdn.bspapp.com/cloudstorage/7b538fb7-d2d5-4524-bf21-6c20e3b5ce6f.json";
            }, e.e1 = function(t) {
                e.src = "https://mp-eeab6da6-80cd-4e80-844a-66b2a7203834.cdn.bspapp.com/cloudstorage/c42b5f05-06b9-43e7-8436-c1029eee610a.json";
            }, e.e2 = function(e) {
                return this.$refs.cLottieRef.call("play");
            }, e.e3 = function(e) {
                return this.$refs.cLottieRef.call("setDirection", -1);
            }, e.e4 = function(e) {
                return this.$refs.cLottieRef.call("pause");
            }, e.e5 = function(e) {
                return this.$refs.cLottieRef.call("stop");
            }, e.e6 = function(e) {
                return this.$refs.cLottieRef.call("setSpeed", 1);
            }, e.e7 = function(e) {
                return this.$refs.cLottieRef.call("setSpeed", 2);
            }, e.e8 = function(e) {
                return this.$refs.cLottieRef.call("goToAndStop", [ 2e3, !1 ]);
            }, e.e9 = function(e) {
                return this.$refs.cLottieRef.call("goToAndPlay", [ 2e3, !1 ]);
            }, e.e10 = function(e) {
                return this.$refs.cLottieRef.call("goToAndStop", [ 2, !0 ]);
            }, e.e11 = function(e) {
                return this.$refs.cLottieRef.call("goToAndPlay", [ 2, !0 ]);
            }, e.e12 = function(e) {
                return this.$refs.cLottieRef.call("playSegments", [ [ 10, 20 ], !1 ]);
            }, e.e13 = function(e) {
                return this.$refs.cLottieRef.call("playSegments", [ [ [ 0, 5 ], [ 10, 18 ] ], !0 ]);
            });
        }, i = [];
    }
}, [ [ "c5cb", "common/runtime", "common/vendor" ] ] ]);