$gwx_XC_53=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_53 || [];
function gz$gwx_XC_53_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_53_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_53_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_53_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'content data-v-205c59ef'])
Z([3,'__l'])
Z([3,'data-v-205c59ef'])
Z([[7],[3,'loadingShow']])
Z([3,'e5a104c8-1'])
Z([3,'cell-wrap data-v-205c59ef'])
Z([[2,'=='],[[6],[[7],[3,'param']],[3,'pid']],[1,0]])
Z(z[1])
Z([3,'__e'])
Z(z[2])
Z([[4],[[5],[[4],[[5],[[5],[1,'^change']],[[4],[[5],[[4],[[5],[1,'starChange']]]]]]]]])
Z([1,60])
Z([1,70])
Z([1,1])
Z([[6],[[7],[3,'param']],[3,'star']])
Z([3,'e5a104c8-2'])
Z(z[1])
Z(z[8])
Z(z[2])
Z([[4],[[5],[[4],[[5],[[5],[1,'^change']],[[4],[[5],[[4],[[5],[1,'unitChange']]]]]]]]])
Z(z[11])
Z(z[12])
Z(z[13])
Z([[6],[[7],[3,'param']],[3,'number']])
Z([3,'e5a104c8-3'])
Z([[2,'||'],[[2,'!'],[[6],[[7],[3,'param']],[3,'id']]],[[2,'=='],[[6],[[7],[3,'param']],[3,'pid']],[1,0]]])
Z([3,'fix-bottom data-v-205c59ef'])
Z([[2,'&&'],[[6],[[7],[3,'param']],[3,'id']],[[2,'!='],[[6],[[7],[3,'param']],[3,'pid']],[1,0]]])
Z([3,'transparent'])
Z(z[1])
Z(z[8])
Z([3,'#E5E5E5'])
Z(z[2])
Z([[4],[[5],[[4],[[5],[[5],[1,'^submit']],[[4],[[5],[[4],[[5],[[5],[1,'save']],[[4],[[5],[1,true]]]]]]]]]]])
Z([[2,'?:'],[[2,'=='],[[6],[[7],[3,'param']],[3,'status']],[1,1]],[1,'禁用'],[1,'启用']])
Z([3,'#999999'])
Z([3,'e5a104c8-4'])
Z([[2,'&&'],[[2,'=='],[[6],[[7],[3,'param']],[3,'pid']],[1,0]],[[6],[[7],[3,'param']],[3,'id']]])
Z(z[28])
Z(z[1])
Z(z[8])
Z(z[31])
Z(z[2])
Z([[4],[[5],[[4],[[5],[[5],[1,'^submit']],[[4],[[5],[[4],[[5],[1,'e3']]]]]]]]])
Z([3,'删除'])
Z(z[35])
Z([3,'e5a104c8-5'])
Z(z[1])
Z(z[8])
Z(z[2])
Z([[4],[[5],[[4],[[5],[[5],[1,'^submit']],[[4],[[5],[[4],[[5],[1,'save']]]]]]]]])
Z([3,'保存'])
Z([3,'e5a104c8-6'])
Z(z[1])
Z([1,false])
Z([3,'data-v-205c59ef vue-ref'])
Z([3,'mPopup'])
Z(z[54])
Z([3,'0rpx'])
Z([3,'e5a104c8-7'])
Z([[4],[[5],[1,'default']]])
Z(z[1])
Z(z[8])
Z(z[55])
Z([3,'确认删除该星愿？'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^submit']],[[4],[[5],[[4],[[5],[1,'deleted']]]]]]]]])
Z([3,'mModal'])
Z([3,'e5a104c8-8'])
Z([1,50])
Z(z[1])
Z(z[8])
Z(z[55])
Z([[4],[[5],[[4],[[5],[[5],[1,'^upload']],[[4],[[5],[[4],[[5],[1,'upLoadIcon']]]]]]]]])
Z([3,'singleImg'])
Z(z[54])
Z(z[54])
Z([3,'prize'])
Z([3,'e5a104c8-9'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_53_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_53_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_53=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_53=true;
var x=['./pages/wish/goodsAdd.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_53_1()
var xUR=_n('view')
_rz(z,xUR,'class',0,e,s,gg)
var oVR=_mz(z,'page-loading',['bind:__l',1,'class',1,'loadingShow_',2,'vueId',3],[],e,s,gg)
_(xUR,oVR)
var fWR=_n('view')
_rz(z,fWR,'class',5,e,s,gg)
var cXR=_v()
_(fWR,cXR)
if(_oz(z,6,e,s,gg)){cXR.wxVkey=1
}
var oZR=_mz(z,'uni-number-box',['bind:__l',7,'bind:change',1,'class',2,'data-event-opts',3,'height',4,'midWidth',5,'min',6,'value',7,'vueId',8],[],e,s,gg)
_(fWR,oZR)
var c1R=_mz(z,'uni-number-box',['bind:__l',16,'bind:change',1,'class',2,'data-event-opts',3,'height',4,'midWidth',5,'min',6,'value',7,'vueId',8],[],e,s,gg)
_(fWR,c1R)
var hYR=_v()
_(fWR,hYR)
if(_oz(z,25,e,s,gg)){hYR.wxVkey=1
}
cXR.wxXCkey=1
hYR.wxXCkey=1
_(xUR,fWR)
var o2R=_n('view')
_rz(z,o2R,'class',26,e,s,gg)
var l3R=_v()
_(o2R,l3R)
if(_oz(z,27,e,s,gg)){l3R.wxVkey=1
var t5R=_mz(z,'m-button',['bgColor',28,'bind:__l',1,'bind:submit',2,'borderColor',3,'class',4,'data-event-opts',5,'text',6,'textColor',7,'vueId',8],[],e,s,gg)
_(l3R,t5R)
}
var a4R=_v()
_(o2R,a4R)
if(_oz(z,37,e,s,gg)){a4R.wxVkey=1
var e6R=_mz(z,'m-button',['bgColor',38,'bind:__l',1,'bind:submit',2,'borderColor',3,'class',4,'data-event-opts',5,'text',6,'textColor',7,'vueId',8],[],e,s,gg)
_(a4R,e6R)
}
var b7R=_mz(z,'m-button',['bind:__l',47,'bind:submit',1,'class',2,'data-event-opts',3,'text',4,'vueId',5],[],e,s,gg)
_(o2R,b7R)
l3R.wxXCkey=1
l3R.wxXCkey=3
a4R.wxXCkey=1
a4R.wxXCkey=3
_(xUR,o2R)
var o8R=_mz(z,'m-popup',['bind:__l',53,'btnShow',1,'class',2,'data-ref',3,'iosSafeArea',4,'padding',5,'vueId',6,'vueSlots',7],[],e,s,gg)
_(xUR,o8R)
var x9R=_mz(z,'m-modal',['bind:__l',61,'bind:submit',1,'class',2,'content',3,'data-event-opts',4,'data-ref',5,'vueId',6],[],e,s,gg)
_(xUR,x9R)
var o0R=_mz(z,'single-img',['addSize',68,'bind:__l',1,'bind:upload',2,'class',3,'data-event-opts',4,'data-ref',5,'showDel',6,'showImg',7,'uploadModel',8,'vueId',9],[],e,s,gg)
_(xUR,o0R)
_(r,xUR)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_53";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_53();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/wish/goodsAdd.wxml'] = [$gwx_XC_53, './pages/wish/goodsAdd.wxml'];else __wxAppCode__['pages/wish/goodsAdd.wxml'] = $gwx_XC_53( './pages/wish/goodsAdd.wxml' );
	;__wxRoute = "pages/wish/goodsAdd";__wxRouteBegin = true;__wxAppCurrentFile__="pages/wish/goodsAdd.js";define("pages/wish/goodsAdd.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/wish/goodsAdd"],{"1b0a":function(t,n,e){},"2ec7":function(t,n,e){"use strict";e.r(n);var i=e("48ed"),a=e("dc39");for(var r in a)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return a[t]}))}(r);e("aa71");var s=e("828b"),o=Object(s.a)(a.default,i.b,i.c,!1,null,"205c59ef",null,!1,i.a,void 0);n.default=o.exports},"48ed":function(t,n,e){"use strict";e.d(n,"b",(function(){return a})),e.d(n,"c",(function(){return r})),e.d(n,"a",(function(){return i}));var i={pageLoading:function(){return e.e("components/pageLoading/pageLoading").then(e.bind(null,"7f33"))},uniNumberBox:function(){return e.e("uni_modules/uni-number-box/components/uni-number-box/uni-number-box").then(e.bind(null,"2406"))},mButton:function(){return e.e("components/mButton/mButton").then(e.bind(null,"fac5"))},mPopup:function(){return e.e("components/mPopup/mPopup").then(e.bind(null,"ae6f"))},mModal:function(){return e.e("components/mModal/mModal").then(e.bind(null,"68ea"))},singleImg:function(){return Promise.all([e.e("common/vendor"),e.e("components/singleImg/singleImg")]).then(e.bind(null,"afd9"))}},a=function(){var t=this;t.$createElement;t._self._c,t._isMounted||(t.e0=function(n){t.param.id&&0!=t.param.pid&&t.changeName()},t.e1=function(n){t.param.id&&0!=t.param.pid&&t.changeName()},t.e2=function(n,e){var i=arguments[arguments.length-1].currentTarget.dataset,a=i.eventParams||i["event-params"];e=a.item,t.param.unit=e},t.e3=function(n){return t.$refs.mModal.show()},t.e4=function(n){return t.$refs.singleImg.chooseImage()})},r=[]},aa71:function(t,n,e){"use strict";var i=e("1b0a");e.n(i).a},c605:function(t,n,e){"use strict";(function(t,n){var i=e("47a9");e("e465"),i(e("3240"));var a=i(e("2ec7"));t.__webpack_require_UNI_MP_PLUGIN__=e,n(a.default)}).call(this,e("3223").default,e("df3c").createPage)},d58c:function(t,n,e){"use strict";(function(t){var i=e("47a9");Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a=i(e("7ca3"));function r(t,n){var e=Object.keys(t);if(Object.getOwnPropertySymbols){var i=Object.getOwnPropertySymbols(t);n&&(i=i.filter((function(n){return Object.getOwnPropertyDescriptor(t,n).enumerable}))),e.push.apply(e,i)}return e}function s(t){for(var n=1;n<arguments.length;n++){var e=null!=arguments[n]?arguments[n]:{};n%2?r(Object(e),!0).forEach((function(n){(0,a.default)(t,n,e[n])})):Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(e)):r(Object(e)).forEach((function(n){Object.defineProperty(t,n,Object.getOwnPropertyDescriptor(e,n))}))}return t}var o={data:function(){return{icons:[],iconIndex:null,unitArr:["个","次","台","分钟","箱","瓶","只"],param:{child_id:t.getStorageSync("child_id"),id:"",pid:0,name:"",icon:"",star:1,number:1,unit:"个",status:1,remark:""}}},onLoad:function(n){if(n&&n.goods){t.setNavigationBarTitle({title:"编辑星愿"});var e=JSON.parse(decodeURIComponent(n.goods));this.param=s(s({},this.param),e)}this.getIcons()},methods:{getIcons:function(){var t=this;this.$api.wishApi.prizesIcons({per_page:1e4},!1,this).then((function(n){t.icons=n.data.rows}))},changePic:function(){if(this.param.id&&0!=this.param.pid)return this.$util.msg("系统星愿只支持修改单价和单位数量",1500);this.$refs.mPopup.show()},changeName:function(){this.$util.msg("系统星愿只支持修改单价",1500)},selectIcon:function(t){this.iconIndex=t,this.param.icon=this.icons[this.iconIndex].icon,this.param.name||(this.param.unit=this.icons[this.iconIndex].unit),this.param.name||(this.param.name=this.icons[this.iconIndex].name),this.$refs.mPopup.hide()},upLoadIcon:function(t){this.param.icon=t,this.$refs.mPopup.hide()},starChange:function(t){this.param.star=t},unitChange:function(t){this.param.number=t},save:function(n){var e=this;return this.param.icon?this.param.name?this.param.star?this.param.number?(this.param.name=this.param.name.trim(),this.param.remark=this.param.remark.trim(),n&&(this.param.status=1==this.param.status?0:1),void(this.param.id?this.$api.wishApi.prizesEdit(this.param.id,this.param,!0,this).then((function(i){e.$util.msg("".concat(n&&0==e.param.status?"禁用":n&&1==e.param.status?"启用":"保存","成功")),t.$emit("wish_refresh"),setTimeout((function(){t.navigateBack()}),1e3)})):this.$api.wishApi.prizesAdd(this.param,!0,this).then((function(n){e.$util.msg("保存成功"),t.$emit("wish_refresh"),setTimeout((function(){t.navigateBack()}),1e3)})))):this.$util.msg("请填写兑换数量"):this.$util.msg("请填写星愿单价"):this.$util.msg("shia 请填写星愿名称"):this.$util.msg("请选择星愿图标")},deleted:function(){var n=this;this.$api.wishApi.prizesDelect(this.param.id,this.param,!0,this).then((function(e){n.$util.msg("删除成功"),t.$emit("wish_refresh"),setTimeout((function(){t.navigateBack()}),1e3)}))}}};n.default=o}).call(this,e("df3c").default)},dc39:function(t,n,e){"use strict";e.r(n);var i=e("d58c"),a=e.n(i);for(var r in i)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return i[t]}))}(r);n.default=a.a}},[["c605","common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/wish/goodsAdd.js'});require("pages/wish/goodsAdd.js");