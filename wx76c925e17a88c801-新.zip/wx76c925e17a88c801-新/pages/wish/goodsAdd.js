(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/wish/goodsAdd" ], {
    "1b0a": function(t, n, e) {},
    "2ec7": function(t, n, e) {
        "use strict";
        e.r(n);
        var i = e("48ed"), a = e("dc39");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(r);
        e("aa71");
        var s = e("828b"), o = Object(s.a)(a.default, i.b, i.c, !1, null, "205c59ef", null, !1, i.a, void 0);
        n.default = o.exports;
    },
    "48ed": function(t, n, e) {
        "use strict";
        e.d(n, "b", function() {
            return a;
        }), e.d(n, "c", function() {
            return r;
        }), e.d(n, "a", function() {
            return i;
        });
        var i = {
            pageLoading: function() {
                return e.e("components/pageLoading/pageLoading").then(e.bind(null, "7f33"));
            },
            uniNumberBox: function() {
                return e.e("uni_modules/uni-number-box/components/uni-number-box/uni-number-box").then(e.bind(null, "2406"));
            },
            mButton: function() {
                return e.e("components/mButton/mButton").then(e.bind(null, "fac5"));
            },
            mPopup: function() {
                return e.e("components/mPopup/mPopup").then(e.bind(null, "ae6f"));
            },
            mModal: function() {
                return e.e("components/mModal/mModal").then(e.bind(null, "68ea"));
            },
            singleImg: function() {
                return Promise.all([ e.e("common/vendor"), e.e("components/singleImg/singleImg") ]).then(e.bind(null, "afd9"));
            }
        }, a = function() {
            var t = this;
            t.$createElement;
            t._self._c, t._isMounted || (t.e0 = function(n) {
                t.param.id && 0 != t.param.pid && t.changeName();
            }, t.e1 = function(n) {
                t.param.id && 0 != t.param.pid && t.changeName();
            }, t.e2 = function(n, e) {
                var i = arguments[arguments.length - 1].currentTarget.dataset, a = i.eventParams || i["event-params"];
                e = a.item, t.param.unit = e;
            }, t.e3 = function(n) {
                return t.$refs.mModal.show();
            }, t.e4 = function(n) {
                return t.$refs.singleImg.chooseImage();
            });
        }, r = [];
    },
    aa71: function(t, n, e) {
        "use strict";
        var i = e("1b0a");
        e.n(i).a;
    },
    c605: function(t, n, e) {
        "use strict";
        (function(t, n) {
            var i = e("47a9");
            e("e465"), i(e("3240"));
            var a = i(e("2ec7"));
            t.__webpack_require_UNI_MP_PLUGIN__ = e, n(a.default);
        }).call(this, e("3223").default, e("df3c").createPage);
    },
    d58c: function(t, n, e) {
        "use strict";
        (function(t) {
            var i = e("47a9");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var a = i(e("7ca3"));
            function r(t, n) {
                var e = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    n && (i = i.filter(function(n) {
                        return Object.getOwnPropertyDescriptor(t, n).enumerable;
                    })), e.push.apply(e, i);
                }
                return e;
            }
            function s(t) {
                for (var n = 1; n < arguments.length; n++) {
                    var e = null != arguments[n] ? arguments[n] : {};
                    n % 2 ? r(Object(e), !0).forEach(function(n) {
                        (0, a.default)(t, n, e[n]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(e)) : r(Object(e)).forEach(function(n) {
                        Object.defineProperty(t, n, Object.getOwnPropertyDescriptor(e, n));
                    });
                }
                return t;
            }
            var o = {
                data: function() {
                    return {
                        icons: [],
                        iconIndex: null,
                        unitArr: [ "个", "次", "台", "分钟", "箱", "瓶", "只" ],
                        param: {
                            child_id: t.getStorageSync("child_id"),
                            id: "",
                            pid: 0,
                            name: "",
                            icon: "",
                            star: 1,
                            number: 1,
                            unit: "个",
                            status: 1,
                            remark: ""
                        }
                    };
                },
                onLoad: function(n) {
                    if (n && n.goods) {
                        t.setNavigationBarTitle({
                            title: "编辑星愿"
                        });
                        var e = JSON.parse(decodeURIComponent(n.goods));
                        this.param = s(s({}, this.param), e);
                    }
                    this.getIcons();
                },
                methods: {
                    getIcons: function() {
                        var t = this;
                        this.$api.wishApi.prizesIcons({
                            per_page: 1e4
                        }, !1, this).then(function(n) {
                            t.icons = n.data.rows;
                        });
                    },
                    changePic: function() {
                        if (this.param.id && 0 != this.param.pid) return this.$util.msg("系统星愿只支持修改单价和单位数量", 1500);
                        this.$refs.mPopup.show();
                    },
                    changeName: function() {
                        this.$util.msg("系统星愿只支持修改单价", 1500);
                    },
                    selectIcon: function(t) {
                        this.iconIndex = t, this.param.icon = this.icons[this.iconIndex].icon, this.param.name || (this.param.unit = this.icons[this.iconIndex].unit), 
                        this.param.name || (this.param.name = this.icons[this.iconIndex].name), this.$refs.mPopup.hide();
                    },
                    upLoadIcon: function(t) {
                        this.param.icon = t, this.$refs.mPopup.hide();
                    },
                    starChange: function(t) {
                        this.param.star = t;
                    },
                    unitChange: function(t) {
                        this.param.number = t;
                    },
                    save: function(n) {
                        var e = this;
                        return this.param.icon ? this.param.name ? this.param.star ? this.param.number ? (this.param.name = this.param.name.trim(), 
                        this.param.remark = this.param.remark.trim(), n && (this.param.status = 1 == this.param.status ? 0 : 1), 
                        void (this.param.id ? this.$api.wishApi.prizesEdit(this.param.id, this.param, !0, this).then(function(i) {
                            e.$util.msg("".concat(n && 0 == e.param.status ? "禁用" : n && 1 == e.param.status ? "启用" : "保存", "成功")), 
                            t.$emit("wish_refresh"), setTimeout(function() {
                                t.navigateBack();
                            }, 1e3);
                        }) : this.$api.wishApi.prizesAdd(this.param, !0, this).then(function(n) {
                            e.$util.msg("保存成功"), t.$emit("wish_refresh"), setTimeout(function() {
                                t.navigateBack();
                            }, 1e3);
                        }))) : this.$util.msg("请填写兑换数量") : this.$util.msg("请填写星愿单价") : this.$util.msg("shia 请填写星愿名称") : this.$util.msg("请选择星愿图标");
                    },
                    deleted: function() {
                        var n = this;
                        this.$api.wishApi.prizesDelect(this.param.id, this.param, !0, this).then(function(e) {
                            n.$util.msg("删除成功"), t.$emit("wish_refresh"), setTimeout(function() {
                                t.navigateBack();
                            }, 1e3);
                        });
                    }
                }
            };
            n.default = o;
        }).call(this, e("df3c").default);
    },
    dc39: function(t, n, e) {
        "use strict";
        e.r(n);
        var i = e("d58c"), a = e.n(i);
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(r);
        n.default = a.a;
    }
}, [ [ "c605", "common/runtime", "common/vendor" ] ] ]);