$gwx_XC_30=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_30 || [];
function gz$gwx_XC_30_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_30_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_30_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_30_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'content data-v-d8d2b3a8'])
Z([3,'__l'])
Z([3,'data-v-d8d2b3a8'])
Z([[7],[3,'loadingShow']])
Z([3,'35a7246c-1'])
Z([3,'form-wrap flex-column flex-align-center data-v-d8d2b3a8'])
Z([3,'__e'])
Z([3,'agreement-wrap flex-align-center data-v-d8d2b3a8'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e1']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'#FFEA00'])
Z(z[1])
Z(z[2])
Z([3,'#000000'])
Z([1,24])
Z([1,34])
Z([[7],[3,'agree']])
Z([3,'35a7246c-2'])
Z(z[14])
Z([[6],[[7],[3,'agreement']],[3,'user']])
Z(z[1])
Z(z[6])
Z(z[2])
Z([[4],[[5],[[4],[[5],[[5],[1,'^submit']],[[4],[[5],[[4],[[5],[1,'login']]]]]]]]])
Z([3,'登录'])
Z([3,'35a7246c-3'])
Z(z[1])
Z([3,'data-v-d8d2b3a8 vue-ref'])
Z([3,'slotModal'])
Z([1,false])
Z([3,'35a7246c-4'])
Z([[4],[[5],[1,'default']]])
Z(z[18])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_30_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_30_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_30=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_30=true;
var x=['./pages/login/login.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_30_1()
var bWG=_n('view')
_rz(z,bWG,'class',0,e,s,gg)
var oXG=_mz(z,'page-loading',['bind:__l',1,'class',1,'loadingShow_',2,'vueId',3],[],e,s,gg)
_(bWG,oXG)
var xYG=_n('view')
_rz(z,xYG,'class',5,e,s,gg)
var oZG=_mz(z,'view',['bindtap',6,'class',1,'data-event-opts',2],[],e,s,gg)
var c2G=_mz(z,'m-radio',['actBgColor',9,'bind:__l',1,'class',2,'color',3,'fontSize',4,'height',5,'selected',6,'vueId',7,'width',8],[],e,s,gg)
_(oZG,c2G)
var f1G=_v()
_(oZG,f1G)
if(_oz(z,18,e,s,gg)){f1G.wxVkey=1
}
f1G.wxXCkey=1
_(xYG,oZG)
var h3G=_mz(z,'m-button',['bind:__l',19,'bind:submit',1,'class',2,'data-event-opts',3,'text',4,'vueId',5],[],e,s,gg)
_(xYG,h3G)
_(bWG,xYG)
var o4G=_mz(z,'slot-modal',['bind:__l',25,'class',1,'data-ref',2,'maskClose',3,'vueId',4,'vueSlots',5],[],e,s,gg)
var c5G=_v()
_(o4G,c5G)
if(_oz(z,31,e,s,gg)){c5G.wxVkey=1
}
c5G.wxXCkey=1
_(bWG,o4G)
_(r,bWG)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_30";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_30();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/login/login.wxml'] = [$gwx_XC_30, './pages/login/login.wxml'];else __wxAppCode__['pages/login/login.wxml'] = $gwx_XC_30( './pages/login/login.wxml' );
	;__wxRoute = "pages/login/login";__wxRouteBegin = true;__wxAppCurrentFile__="pages/login/login.js";define("pages/login/login.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/login/login"],{"0e11":function(e,t,n){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var n={data:function(){return{back:!1,getCodeStr:"获取验证码",msgCodeTime:60,msgCodeTimer:null,agree:!1,agreement:{},loginData:{driver:"verify_code",phone:"",verify_code:""}}},onLoad:function(e){1==e.back&&(this.back=!0),this.init()},methods:{init:function(){var e=this;this.$api.commonApi.configurations({key:"app_auth"},!1,this).then((function(t){e.agreement=t.data.app_auth}))},sendCodeMessage:function(){var e=this,t=this.loginData.phone;return t?this.$util.checkPhoneNumber(t)?void this.$api.commonApi.getMsgCode({type:"login",phone:this.loginData.phone},!0,this).then((function(t){e.$util.msg("验证码已发送"),e.msgCodeTimer=setInterval((function(){e.msgCodeTime>0?(e.msgCodeTime--,e.getCodeStr=e.msgCodeTime+"s后重新获取"):(clearInterval(e.msgCodeTimer),e.msgCodeTime=60,e.getCodeStr="获取验证码")}),1e3)})):this.$util.msg("请输入正确手机号"):this.$util.msg("请输入手机号")},agreementModal:function(){this.$refs.slotModal.hide(),this.agree=!0,this.login()},login:function(){var t=this;return this.loginData.phone?this.loginData.verify_code?this.agree?void this.$api.commonApi.silentLogin(this.loginData,!0,this).then((function(n){e.setStorageSync("token",n.data.token),e.setStorageSync("userInfo",n.data.user),n.data.user.last_child_id&&e.setStorageSync("child_id",n.data.user.last_child_id),e.reLaunch({url:"/pages/index"}),setTimeout((function(){t.getPackage(),t.getBehaviorsList(),t.getBehaviorsCate()}),1e3)})):this.$refs.slotModal.show():this.$util.msg("请输入验证码"):this.$util.msg("请输入手机号")},getPackage:function(){this.$api.behaviorsApi.behaviorsPackage({},!1,this).then((function(t){e.setStorageSync("packageArr",t.data)}))},getBehaviorsList:function(){this.$api.behaviorsApi.behaviorsList({},!1,this).then((function(t){t.data.filter((function(e,t){e.value=e.id})),e.setStorageSync("behaviorsList",t.data)}))},getBehaviorsCate:function(){this.$api.behaviorsApi.behaviorsCate({},!1,this).then((function(t){e.setStorageSync("behaviorsCate",t.data)}))}}};t.default=n}).call(this,n("df3c").default)},"72b5":function(e,t,n){"use strict";n.d(t,"b",(function(){return a})),n.d(t,"c",(function(){return i})),n.d(t,"a",(function(){return o}));var o={pageLoading:function(){return n.e("components/pageLoading/pageLoading").then(n.bind(null,"7f33"))},mRadio:function(){return n.e("components/mRadio/mRadio").then(n.bind(null,"b7a0"))},mButton:function(){return n.e("components/mButton/mButton").then(n.bind(null,"fac5"))},slotModal:function(){return n.e("components/slotModal/slotModal").then(n.bind(null,"8d9e"))}},a=function(){var e=this;e.$createElement;e._self._c,e._isMounted||(e.e0=function(t){60==e.msgCodeTime&&e.sendCodeMessage()},e.e1=function(t){e.agree=!e.agree},e.e2=function(t){t.stopPropagation(),e.goPage("/pages/common/agreement?title="+e.agreement.user.name+"&content="+encodeURIComponent(e.agreement.user.value))},e.e3=function(t){t.stopPropagation(),e.goPage("/pages/common/agreement?title="+e.agreement.privacy.name+"&content="+encodeURIComponent(e.agreement.privacy.value))},e.e4=function(t){t.stopPropagation(),e.goPage("/pages/common/agreement?title="+e.agreement.user.name+"&content="+encodeURIComponent(e.agreement.user.value))},e.e5=function(t){t.stopPropagation(),e.goPage("/pages/common/agreement?title="+e.agreement.privacy.name+"&content="+encodeURIComponent(e.agreement.privacy.value))},e.e6=function(t){return e.$refs.slotModal.hide()})},i=[]},"75a3":function(e,t,n){},"8a80":function(e,t,n){"use strict";(function(e,t){var o=n("47a9");n("e465"),o(n("3240"));var a=o(n("b9d5"));e.__webpack_require_UNI_MP_PLUGIN__=n,t(a.default)}).call(this,n("3223").default,n("df3c").createPage)},"8e67":function(e,t,n){"use strict";var o=n("75a3");n.n(o).a},ac83:function(e,t,n){"use strict";n.r(t);var o=n("0e11"),a=n.n(o);for(var i in o)["default"].indexOf(i)<0&&function(e){n.d(t,e,(function(){return o[e]}))}(i);t.default=a.a},b9d5:function(e,t,n){"use strict";n.r(t);var o=n("72b5"),a=n("ac83");for(var i in a)["default"].indexOf(i)<0&&function(e){n.d(t,e,(function(){return a[e]}))}(i);n("8e67");var r=n("828b"),s=Object(r.a)(a.default,o.b,o.c,!1,null,"d8d2b3a8",null,!1,o.a,void 0);t.default=s.exports}},[["8a80","common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/login/login.js'});require("pages/login/login.js");