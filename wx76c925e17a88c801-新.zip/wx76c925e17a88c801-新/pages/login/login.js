(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/login/login" ], {
    "0e11": function(e, t, n) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = {
                data: function() {
                    return {
                        back: !1,
                        getCodeStr: "获取验证码",
                        msgCodeTime: 60,
                        msgCodeTimer: null,
                        agree: !1,
                        agreement: {},
                        loginData: {
                            driver: "verify_code",
                            phone: "",
                            verify_code: ""
                        }
                    };
                },
                onLoad: function(e) {
                    1 == e.back && (this.back = !0), this.init();
                },
                methods: {
                    init: function() {
                        var e = this;
                        this.$api.commonApi.configurations({
                            key: "app_auth"
                        }, !1, this).then(function(t) {
                            e.agreement = t.data.app_auth;
                        });
                    },
                    sendCodeMessage: function() {
                        var e = this, t = this.loginData.phone;
                        return t ? this.$util.checkPhoneNumber(t) ? void this.$api.commonApi.getMsgCode({
                            type: "login",
                            phone: this.loginData.phone
                        }, !0, this).then(function(t) {
                            e.$util.msg("验证码已发送"), e.msgCodeTimer = setInterval(function() {
                                e.msgCodeTime > 0 ? (e.msgCodeTime--, e.getCodeStr = e.msgCodeTime + "s后重新获取") : (clearInterval(e.msgCodeTimer), 
                                e.msgCodeTime = 60, e.getCodeStr = "获取验证码");
                            }, 1e3);
                        }) : this.$util.msg("请输入正确手机号") : this.$util.msg("请输入手机号");
                    },
                    agreementModal: function() {
                        this.$refs.slotModal.hide(), this.agree = !0, this.login();
                    },
                    login: function() {
                        var t = this;
                        return this.loginData.phone ? this.loginData.verify_code ? this.agree ? void this.$api.commonApi.silentLogin(this.loginData, !0, this).then(function(n) {
                            e.setStorageSync("token", n.data.token), e.setStorageSync("userInfo", n.data.user), 
                            n.data.user.last_child_id && e.setStorageSync("child_id", n.data.user.last_child_id), 
                            e.reLaunch({
                                url: "/pages/index"
                            }), setTimeout(function() {
                                t.getPackage(), t.getBehaviorsList(), t.getBehaviorsCate();
                            }, 1e3);
                        }) : this.$refs.slotModal.show() : this.$util.msg("请输入验证码") : this.$util.msg("请输入手机号");
                    },
                    getPackage: function() {
                        this.$api.behaviorsApi.behaviorsPackage({}, !1, this).then(function(t) {
                            e.setStorageSync("packageArr", t.data);
                        });
                    },
                    getBehaviorsList: function() {
                        this.$api.behaviorsApi.behaviorsList({}, !1, this).then(function(t) {
                            t.data.filter(function(e, t) {
                                e.value = e.id;
                            }), e.setStorageSync("behaviorsList", t.data);
                        });
                    },
                    getBehaviorsCate: function() {
                        this.$api.behaviorsApi.behaviorsCate({}, !1, this).then(function(t) {
                            e.setStorageSync("behaviorsCate", t.data);
                        });
                    }
                }
            };
            t.default = n;
        }).call(this, n("df3c").default);
    },
    "72b5": function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {
            return o;
        });
        var o = {
            pageLoading: function() {
                return n.e("components/pageLoading/pageLoading").then(n.bind(null, "7f33"));
            },
            mRadio: function() {
                return n.e("components/mRadio/mRadio").then(n.bind(null, "b7a0"));
            },
            mButton: function() {
                return n.e("components/mButton/mButton").then(n.bind(null, "fac5"));
            },
            slotModal: function() {
                return n.e("components/slotModal/slotModal").then(n.bind(null, "8d9e"));
            }
        }, a = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(t) {
                60 == e.msgCodeTime && e.sendCodeMessage();
            }, e.e1 = function(t) {
                e.agree = !e.agree;
            }, e.e2 = function(t) {
                t.stopPropagation(), e.goPage("/pages/common/agreement?title=" + e.agreement.user.name + "&content=" + encodeURIComponent(e.agreement.user.value));
            }, e.e3 = function(t) {
                t.stopPropagation(), e.goPage("/pages/common/agreement?title=" + e.agreement.privacy.name + "&content=" + encodeURIComponent(e.agreement.privacy.value));
            }, e.e4 = function(t) {
                t.stopPropagation(), e.goPage("/pages/common/agreement?title=" + e.agreement.user.name + "&content=" + encodeURIComponent(e.agreement.user.value));
            }, e.e5 = function(t) {
                t.stopPropagation(), e.goPage("/pages/common/agreement?title=" + e.agreement.privacy.name + "&content=" + encodeURIComponent(e.agreement.privacy.value));
            }, e.e6 = function(t) {
                return e.$refs.slotModal.hide();
            });
        }, i = [];
    },
    "75a3": function(e, t, n) {},
    "8a80": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var o = n("47a9");
            n("e465"), o(n("3240"));
            var a = o(n("b9d5"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(a.default);
        }).call(this, n("3223").default, n("df3c").createPage);
    },
    "8e67": function(e, t, n) {
        "use strict";
        var o = n("75a3");
        n.n(o).a;
    },
    ac83: function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("0e11"), a = n.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(i);
        t.default = a.a;
    },
    b9d5: function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("72b5"), a = n("ac83");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(i);
        n("8e67");
        var r = n("828b"), s = Object(r.a)(a.default, o.b, o.c, !1, null, "d8d2b3a8", null, !1, o.a, void 0);
        t.default = s.exports;
    }
}, [ [ "8a80", "common/runtime", "common/vendor" ] ] ]);