(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine" ], {
    "405a": function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("d502"), i = n("e18e");
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(a);
        n("d410");
        var r = n("828b"), s = Object(r.a)(i.default, o.b, o.c, !1, null, "55d32f1c", null, !1, o.a, void 0);
        t.default = s.exports;
    },
    "9f5d": function(e, t, n) {},
    a37a: function(e, t, n) {
        "use strict";
        (function(e, t) {
            var o = n("47a9");
            n("e465"), o(n("3240"));
            var i = o(n("405a"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(i.default);
        }).call(this, n("3223").default, n("df3c").createPage);
    },
    d410: function(e, t, n) {
        "use strict";
        var o = n("9f5d");
        n.n(o).a;
    },
    d502: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return i;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {
            return o;
        });
        var o = {
            pageLoading: function() {
                return n.e("components/pageLoading/pageLoading").then(n.bind(null, "7f33"));
            },
            checkChild: function() {
                return n.e("components/checkChild/checkChild").then(n.bind(null, "1e15"));
            },
            slotModal: function() {
                return n.e("components/slotModal/slotModal").then(n.bind(null, "8d9e"));
            },
            mPopup: function() {
                return n.e("components/mPopup/mPopup").then(n.bind(null, "ae6f"));
            },
            mRadio: function() {
                return n.e("components/mRadio/mRadio").then(n.bind(null, "b7a0"));
            },
            mModal: function() {
                return n.e("components/mModal/mModal").then(n.bind(null, "68ea"));
            },
            uniNumberBox: function() {
                return n.e("uni_modules/uni-number-box/components/uni-number-box/uni-number-box").then(n.bind(null, "2406"));
            },
            tabbar: function() {
                return n.e("components/tabbar/tabbar").then(n.bind(null, "09e8"));
            }
        }, i = function() {
            var e = this, t = (e.$createElement, e._self._c, e.banners.length), n = Math.abs(e.afterStar - e.child.score);
            e._isMounted || (e.e0 = function(t) {
                e.goPage("/pages/mine/setting?userInfo=" + encodeURIComponent(JSON.stringify(e.userInfo)));
            }, e.e1 = function(t) {
                return e.$refs.checkChild.show();
            }, e.e2 = function(t) {
                return e.$refs.mPopup3.show();
            }, e.e3 = function(t) {
                return e.$refs.slotModal.hide();
            }, e.e4 = function(t) {
                e.agreement = !e.agreement;
            }, e.e5 = function(t) {
                t.stopPropagation(), e.goPage("/pages/common/agreement?title=用户服务协议&content=" + encodeURIComponent(e.vipPriceData.agreement));
            }, e.e6 = function(t) {
                t.stopPropagation(), e.goPage("/pages/common/agreement?title=开通须知&content=" + encodeURIComponent(e.vipPriceData.open_notice));
            }, e.e7 = function(t) {
                t.stopPropagation(), e.goPage("/pages/common/agreement?title=用户服务协议&content=" + encodeURIComponent(e.vipPriceData.agreement));
            }, e.e8 = function(t) {
                t.stopPropagation(), e.goPage("/pages/common/agreement?title=开通须知&content=" + encodeURIComponent(e.vipPriceData.open_notice));
            }, e.e9 = function(t) {
                return e.$refs.slotModal2.hide();
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    g0: t,
                    g1: n
                }
            });
        }, a = [];
    },
    e03e: function(e, t, n) {
        "use strict";
        (function(e) {
            var o = n("47a9");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = o(n("7eb4")), a = o(n("ee10")), r = {
                data: function() {
                    return {
                        firstLoad: !0,
                        child_id: null,
                        customTop: 0,
                        userInfo: {},
                        child: {},
                        banners: [],
                        waitPayNum: 0,
                        vipPriceData: {},
                        vipIndex: 2,
                        coupon: null,
                        haveCoupon: null,
                        agreement: !1,
                        backdoorId: "",
                        afterStar: 0,
                        remark: "",
                        mPopup2Open: !1
                    };
                },
                onLoad: function() {
                    var t = this;
                    this.child_id = e.getStorageSync("child_id"), this.getCustomTop(), this.getBanners(), 
                    e.$off("selecteCoupon").$on("selecteCoupon", function(e) {
                        t.coupon = e;
                    }), e.$off("useCoupon").$on("useCoupon", function(e) {
                        t.coupon = e, t.checkSystem();
                    });
                },
                onShow: function() {
                    e.getStorageSync("renew") && (e.removeStorageSync("renew"), this.checkSystem()), 
                    this.getUserInfo(), this.getChildInfo(), this.getCoupon(), this.getOrder();
                },
                methods: {
                    share: function() {},
                    getCustomTop: function() {
                        this.customTop = getApp().globalData.capsuleInfo.bottom + 25;
                    },
                    getBanners: function() {
                        var e = this;
                        this.$api.activeApi.banners({}, !1, this).then(function(t) {
                            e.banners = t.data;
                        });
                    },
                    getUserInfo: function() {
                        var t = this;
                        this.$api.commonApi.userInfo({}, this.firstLoad, this).then(function(n) {
                            t.firstLoad = !1, t.userInfo = n.data, e.setStorageSync("userInfo", n.data);
                        });
                    },
                    getChildInfo: function() {
                        var t = this;
                        this.$api.commonApi.childrenInfo(this.child_id, {}, !1, this).then(function(n) {
                            e.setStorageSync("child", n.data), t.child = n.data, t.afterStar = t.child.score;
                        });
                    },
                    getOrder: function() {
                        var e = this;
                        this.$api.vipApi.orderList({
                            status_map: "waiting"
                        }, !1, this).then(function(t) {
                            e.waitPayNum = t.data.total;
                        });
                    },
                    getVipPrices: function() {
                        var e = this;
                        return new Promise(function(t, n) {
                            e.$api.vipApi.pricesList({}, !1, e).then(function(n) {
                                n.data.prices.filter(function(e) {
                                    var t = e.price.toString().split(".");
                                    e.price1 = t[0], e.price2 = t[1] ? t[1] : null;
                                }), e.vipPriceData = n.data, t();
                            });
                        });
                    },
                    checkVip: function(e) {
                        this.vipIndex = e, this.haveCoupon && Number(this.vipPriceData.prices[e].price) >= Number(this.haveCoupon.batch.used_amount) ? this.coupon = this.haveCoupon : this.coupon = null;
                    },
                    getCoupon: function() {
                        var e = this;
                        return (0, a.default)(i.default.mark(function t() {
                            return i.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, e.getVipPrices();

                                  case 2:
                                    e.$api.vipApi.couponList({
                                        status: 1,
                                        page: 1,
                                        per_page: 1
                                    }, !1, e).then(function(t) {
                                        t.data.rows.length ? (e.haveCoupon = t.data.rows[0], Number(e.vipPriceData.prices[e.vipIndex].price) >= Number(e.haveCoupon.batch.used_amount) ? e.coupon = e.haveCoupon : e.coupon = null) : e.coupon = null;
                                    });

                                  case 3:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    checkSystem: function() {
                        if (this.$util.pageClick(this, "点击VIP"), !e.getStorageSync("userInfo").mobile) return this.$refs.mModalPhone.show();
                        "ios" == getApp().globalData.systemName ? this.$refs.slotModal.show() : this.$refs.mPopup.show();
                    },
                    agreementModal: function() {
                        this.$refs.slotModal2.hide(), this.agreement = !0, this.payVip();
                    },
                    payVip: function() {
                        var t = this, n = this;
                        if (!this.agreement) return this.$refs.slotModal2.show();
                        this.loadingShow = !0, this.$api.vipApi.createVipOrder({
                            price_id: this.vipPriceData.prices[this.vipIndex].id,
                            coupon_id: this.coupon ? this.coupon.id : 0
                        }, !1, this).then(function(o) {
                            t.$api.vipApi.payVipOrder({
                                order_sn: o.data.order_sn,
                                trade_type: "JSAPI"
                            }, !1, t).then(function(t) {
                                var i = t.data.pay_data;
                                e.getProvider({
                                    service: "payment",
                                    success: function(t) {
                                        n.loadingShow = !1, e.requestPayment({
                                            provider: t.provider[0],
                                            timeStamp: i.timeStamp,
                                            nonceStr: i.nonceStr,
                                            package: i.package,
                                            signType: i.signType,
                                            paySign: i.paySign,
                                            success: function(e) {
                                                n.$api.vipApi.payVipCheck({
                                                    order_sn: o.data.order_sn
                                                }, !0, n).then(function(e) {
                                                    n.$util.msg("支付成功"), n.$refs.mPopup.hide(), n.getUserInfo(), n.getCoupon();
                                                });
                                            },
                                            fail: function(e) {
                                                n.getOrder(), n.getCoupon();
                                            }
                                        });
                                    }
                                });
                            });
                        });
                    },
                    backdoor: function() {
                        this.$api.commonApi.backdoorLogin({
                            no: this.backdoorId
                        }, !0, this).then(function(t) {
                            e.setStorageSync("token", t.data.token), e.setStorageSync("userInfo", t.data.user), 
                            t.data.user.last_child_id && e.setStorageSync("child_id", t.data.user.last_child_id), 
                            e.reLaunch({
                                url: "/pages/mine"
                            });
                        });
                    },
                    showStarMPopup: function() {
                        this.mPopup2Open = !0, this.$refs.mPopup2.show();
                    },
                    numberChange: function(e) {
                        this.afterStar = e;
                    },
                    mPopupSubmit2: function() {
                        var e = this;
                        if (!this.remark) return this.$util.msg("请输入星星变动原因");
                        this.remark = this.remark.trim(), this.$api.commonApi.childrenStarEdit({
                            child_id: this.child.id,
                            amount_before: this.child.score,
                            amount_after: this.afterStar,
                            remark: this.remark
                        }, !0, this).then(function(t) {
                            e.$util.msg("修改成功"), e.child.score = e.afterStar, e.$refs.mPopup2.hide();
                        });
                    },
                    mPopupHide2: function() {
                        this.mPopup2Open = !1, this.$forceUpdate();
                    },
                    goStarRecord: function() {
                        this.mPopup2Open = !1, this.$refs.mPopup2.hide(), this.goPage("/pages/mine/starRecord?num=".concat(this.child.score));
                    }
                }
            };
            t.default = r;
        }).call(this, n("df3c").default);
    },
    e18e: function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("e03e"), i = n.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        t.default = i.a;
    }
}, [ [ "a37a", "common/runtime", "common/vendor" ] ] ]);