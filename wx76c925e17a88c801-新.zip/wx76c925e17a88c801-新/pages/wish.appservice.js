$gwx_XC_52=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_52 || [];
function gz$gwx_XC_52_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_52_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_52_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_52_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'content data-v-cfcebff2'])
Z([3,'__l'])
Z([3,'data-v-cfcebff2'])
Z([[7],[3,'loadingShow']])
Z([3,'591ad9e6-1'])
Z([[6],[[7],[3,'child']],[3,'id']])
Z([[6],[[7],[3,'$root']],[3,'g0']])
Z([3,'__i0__'])
Z([3,'cate'])
Z([[6],[[7],[3,'$root']],[3,'l0']])
Z([3,'type'])
Z([3,'goods-category data-v-cfcebff2'])
Z([[2,'=='],[[6],[[6],[[7],[3,'cate']],[3,'$orig']],[3,'type']],[1,2]])
Z([3,'goods-list flex-wrap data-v-cfcebff2'])
Z([3,'__i1__'])
Z([3,'goods'])
Z([[6],[[6],[[7],[3,'cate']],[3,'$orig']],[3,'goods']])
Z([3,'id'])
Z([3,'__e'])
Z([3,'goods flex-column flex-align-center data-v-cfcebff2'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e0']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[8],'goods',[[7],[3,'goods']]])
Z([[2,'+'],[[2,'+'],[1,'height:'],[[2,'?:'],[[2,'=='],[[6],[[6],[[7],[3,'cate']],[3,'$orig']],[3,'type']],[1,1]],[1,'314rpx'],[1,'346rpx']]],[1,';']])
Z([[2,'=='],[[6],[[7],[3,'goods']],[3,'status']],[1,0]])
Z([[7],[3,'is_created']])
Z([[2,'!='],[[6],[[6],[[7],[3,'cate']],[3,'$orig']],[3,'type']],[1,1]])
Z([[2,'!'],[[6],[[7],[3,'cate']],[3,'g1']]])
Z([[6],[[7],[3,'$root']],[3,'g2']])
Z([3,'linear-gradient( 180deg, #CAEAFF 0%, rgba(0,0,0,0) 40%, rgba(0,0,0,0) 100%)'])
Z(z[1])
Z([1,false])
Z([3,'data-v-cfcebff2 vue-ref'])
Z([3,'mPopup'])
Z([[7],[3,'iosSafeArea']])
Z([3,'591ad9e6-2'])
Z([[4],[[5],[1,'default']]])
Z([1,1001])
Z([3,'exchange-wrap data-v-cfcebff2'])
Z(z[1])
Z(z[18])
Z(z[2])
Z([[4],[[5],[[4],[[5],[[5],[1,'^change']],[[4],[[5],[[4],[[5],[1,'numberChange']]]]]]]]])
Z([1,76])
Z([1,37])
Z([1,1])
Z([[7],[3,'exchangeNum']])
Z([[2,'+'],[[2,'+'],[1,'591ad9e6-3'],[1,',']],[1,'591ad9e6-2']])
Z(z[43])
Z(z[1])
Z(z[18])
Z(z[2])
Z([[4],[[5],[[4],[[5],[[5],[1,'^submit']],[[4],[[5],[[4],[[5],[1,'checkExchange']]]]]]]]])
Z([3,'立即兑换'])
Z([[2,'+'],[[2,'+'],[1,'591ad9e6-4'],[1,',']],[1,'591ad9e6-2']])
Z(z[1])
Z(z[18])
Z(z[31])
Z([[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[1,'确定使用'],[[7],[3,'totalStar']]],[1,'星兑换']],[[2,'*'],[[6],[[7],[3,'exChangeGoods']],[3,'number']],[[7],[3,'exchangeNum']]]],[[6],[[7],[3,'exChangeGoods']],[3,'unit']]],[[6],[[7],[3,'exChangeGoods']],[3,'name']]],[1,'？']])
Z([[4],[[5],[[4],[[5],[[5],[1,'^submit']],[[4],[[5],[[4],[[5],[1,'exChange']]]]]]]]])
Z([3,'mModal'])
Z([3,'提示'])
Z([3,'591ad9e6-5'])
Z(z[1])
Z(z[18])
Z([3,'暂不使用'])
Z(z[31])
Z([3,'立即使用'])
Z([3,'是否立即使用？'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^submit']],[[4],[[5],[[4],[[5],[1,'useNow']]]]]]]]])
Z([3,'mModal2'])
Z([3,'兑换成功'])
Z([3,'591ad9e6-6'])
Z(z[1])
Z(z[31])
Z([3,'slotModal'])
Z([3,'591ad9e6-7'])
Z(z[35])
Z(z[1])
Z(z[2])
Z(z[44])
Z([3,'591ad9e6-8'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_52_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_52_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_52=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_52=true;
var x=['./pages/wish.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_52_1()
var lWQ=_n('view')
_rz(z,lWQ,'class',0,e,s,gg)
var b1Q=_mz(z,'page-loading',['bind:__l',1,'class',1,'loadingShow_',2,'vueId',3],[],e,s,gg)
_(lWQ,b1Q)
var aXQ=_v()
_(lWQ,aXQ)
if(_oz(z,5,e,s,gg)){aXQ.wxVkey=1
}
var tYQ=_v()
_(lWQ,tYQ)
if(_oz(z,6,e,s,gg)){tYQ.wxVkey=1
var o2Q=_v()
_(tYQ,o2Q)
var x3Q=function(f5Q,o4Q,c6Q,gg){
var o8Q=_n('view')
_rz(z,o8Q,'class',11,f5Q,o4Q,gg)
var c9Q=_v()
_(o8Q,c9Q)
if(_oz(z,12,f5Q,o4Q,gg)){c9Q.wxVkey=1
}
var o0Q=_n('view')
_rz(z,o0Q,'class',13,f5Q,o4Q,gg)
var aBR=_v()
_(o0Q,aBR)
var tCR=function(bER,eDR,oFR,gg){
var oHR=_mz(z,'view',['bindtap',18,'class',1,'data-event-opts',2,'data-event-params',3,'style',4],[],bER,eDR,gg)
var fIR=_v()
_(oHR,fIR)
if(_oz(z,23,bER,eDR,gg)){fIR.wxVkey=1
}
var cJR=_v()
_(oHR,cJR)
if(_oz(z,24,bER,eDR,gg)){cJR.wxVkey=1
}
var hKR=_v()
_(oHR,hKR)
if(_oz(z,25,bER,eDR,gg)){hKR.wxVkey=1
}
fIR.wxXCkey=1
cJR.wxXCkey=1
hKR.wxXCkey=1
_(oFR,oHR)
return oFR
}
aBR.wxXCkey=2
_2z(z,16,tCR,f5Q,o4Q,gg,aBR,'goods','__i1__','id')
var lAR=_v()
_(o0Q,lAR)
if(_oz(z,26,f5Q,o4Q,gg)){lAR.wxVkey=1
}
lAR.wxXCkey=1
_(o8Q,o0Q)
c9Q.wxXCkey=1
_(c6Q,o8Q)
return c6Q
}
o2Q.wxXCkey=2
_2z(z,9,x3Q,e,s,gg,o2Q,'cate','__i0__','type')
}
var eZQ=_v()
_(lWQ,eZQ)
if(_oz(z,27,e,s,gg)){eZQ.wxVkey=1
}
var oLR=_mz(z,'m-popup',['bgImg',28,'bind:__l',1,'btnShow',2,'class',3,'data-ref',4,'iosSafeArea',5,'vueId',6,'vueSlots',7,'zIndex',8],[],e,s,gg)
var cMR=_n('view')
_rz(z,cMR,'class',37,e,s,gg)
var oNR=_mz(z,'uni-number-box',['bind:__l',38,'bind:change',1,'class',2,'data-event-opts',3,'height',4,'midWidth',5,'min',6,'value',7,'vueId',8,'width',9],[],e,s,gg)
_(cMR,oNR)
var lOR=_mz(z,'m-button',['bind:__l',48,'bind:submit',1,'class',2,'data-event-opts',3,'text',4,'vueId',5],[],e,s,gg)
_(cMR,lOR)
_(oLR,cMR)
_(lWQ,oLR)
var aPR=_mz(z,'m-modal',['bind:__l',54,'bind:submit',1,'class',2,'content',3,'data-event-opts',4,'data-ref',5,'title',6,'vueId',7],[],e,s,gg)
_(lWQ,aPR)
var tQR=_mz(z,'m-modal',['bind:__l',62,'bind:submit',1,'cancalText',2,'class',3,'confirmText',4,'content',5,'data-event-opts',6,'data-ref',7,'title',8,'vueId',9],[],e,s,gg)
_(lWQ,tQR)
var eRR=_mz(z,'slot-modal',['bind:__l',72,'class',1,'data-ref',2,'vueId',3,'vueSlots',4],[],e,s,gg)
_(lWQ,eRR)
var bSR=_mz(z,'tabbar',['bind:__l',77,'class',1,'current',2,'vueId',3],[],e,s,gg)
_(lWQ,bSR)
aXQ.wxXCkey=1
tYQ.wxXCkey=1
eZQ.wxXCkey=1
_(r,lWQ)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_52";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_52();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/wish.wxml'] = [$gwx_XC_52, './pages/wish.wxml'];else __wxAppCode__['pages/wish.wxml'] = $gwx_XC_52( './pages/wish.wxml' );
	;__wxRoute = "pages/wish";__wxRouteBegin = true;__wxAppCurrentFile__="pages/wish.js";define("pages/wish.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/wish"],{"0284":function(t,o,n){"use strict";var e=n("5317");n.n(e).a},4129:function(t,o,n){"use strict";n.r(o);var e=n("be37"),i=n.n(e);for(var s in e)["default"].indexOf(s)<0&&function(t){n.d(o,t,(function(){return e[t]}))}(s);o.default=i.a},5317:function(t,o,n){},"808e":function(t,o,n){"use strict";(function(t,o){var e=n("47a9");n("e465"),e(n("3240"));var i=e(n("d401"));t.__webpack_require_UNI_MP_PLUGIN__=n,o(i.default)}).call(this,n("3223").default,n("df3c").createPage)},"8c79":function(t,o,n){"use strict";n.d(o,"b",(function(){return i})),n.d(o,"c",(function(){return s})),n.d(o,"a",(function(){return e}));var e={pageLoading:function(){return n.e("components/pageLoading/pageLoading").then(n.bind(null,"7f33"))},mPopup:function(){return n.e("components/mPopup/mPopup").then(n.bind(null,"ae6f"))},uniNumberBox:function(){return n.e("uni_modules/uni-number-box/components/uni-number-box/uni-number-box").then(n.bind(null,"2406"))},mButton:function(){return n.e("components/mButton/mButton").then(n.bind(null,"fac5"))},mModal:function(){return n.e("components/mModal/mModal").then(n.bind(null,"68ea"))},slotModal:function(){return n.e("components/slotModal/slotModal").then(n.bind(null,"8d9e"))},tabbar:function(){return n.e("components/tabbar/tabbar").then(n.bind(null,"09e8"))}},i=function(){var t=this,o=(t.$createElement,t._self._c,t.goodsData[0].goods.length),n=o?t.__map(t.goodsData,(function(o,n){return{$orig:t.__get_orig(o),g1:o.goods.length}})):null,e=t.is_created&&t.goodsData[1].goods.length;t._isMounted||(t.e0=function(o,n){var e=arguments[arguments.length-1].currentTarget.dataset,i=e.eventParams||e["event-params"];0!=(n=i.goods).status&&t.clickGoods(n)},t.e1=function(o,n){var e=arguments[arguments.length-1].currentTarget.dataset,i=e.eventParams||e["event-params"];n=i.goods,o.stopPropagation(),t.goPage("/pages/wish/goodsAdd?goods="+encodeURIComponent(JSON.stringify(n)))},t.e2=function(o){return t.$refs.slotModal.hide()}),t.$mp.data=Object.assign({},{$root:{g0:o,l0:n,g2:e}})},s=[]},be37:function(t,o,n){"use strict";(function(t){Object.defineProperty(o,"__esModule",{value:!0}),o.default=void 0;var n={data:function(){return{stickTopOpacity:0,customTop:0,child_id:t.getStorageSync("child_id"),is_created:t.getStorageSync("userInfo").family.is_created,child:{},iosSafeArea:!0,goodsData:[{type:1,title:"小星愿",goods:[]},{type:2,title:"自定义星愿",goods:[]}],sortStatus:0,exChangeGoods:{},exchangeNum:1,exChangeGoodsId:null,errMsg:""}},onPageScroll:function(t){this.stickTopOpacity=t.scrollTop/150},onLoad:function(){var o=this;this.getCustomTop(),t.$off("wish_refresh").$on("wish_refresh",(function(t){o.getData(!1)})),this.getData(!0)},onShow:function(){this.getInfo()},computed:{totalStar:function(){return this.exchangeNum*this.exChangeGoods.star}},methods:{getCustomTop:function(){this.customTop=getApp().globalData.capsuleInfo.bottom+15},getInfo:function(){var o=this;this.$api.commonApi.childrenInfo(this.child_id,{},!1,this).then((function(n){t.setStorageSync("child",n.data),o.child=n.data}))},getData:function(t){var o=this;t&&(this.loadingShow=!0),Promise.all([new Promise((function(t){o.$api.wishApi.prizesList({child_id:o.child_id,type:"system"},!1,o).then((function(n){o.goodsData[0].goods=n.data,t()}))})),new Promise((function(t){o.$api.wishApi.prizesList({child_id:o.child_id,type:"custom"},!1,o).then((function(n){o.goodsData[1].goods=n.data,t()}))}))]).then((function(n){o.$forceUpdate(),t&&(o.loadingShow=!1)}))},sort:function(){var t=this;this.sortStatus=0==this.sortStatus?1:1==this.sortStatus?2:0,this.$api.wishApi.prizesList({child_id:this.child_id,type:"custom",sort:0==this.sortStatus?"":1==this.sortStatus?"sort_up":"sort_down",sort_type:this.sortStatus?"star":"created_at"},!0,this).then((function(o){t.goodsData[1].goods=o.data}))},clickGoods:function(t){this.exchangeNum=1,this.exChangeGoods=t,this.$refs.mPopup.show()},numberChange:function(t){this.exchangeNum=t},checkExchange:function(){if(this.totalStar>this.child.score)return this.$util.msg("孩子星星余额不足",2e3);this.$refs.mModal.show()},exChange:function(){var t=this;this.$api.wishApi.prizesExchange({child_id:this.child_id,prize_id:this.exChangeGoods.id,buy_num:this.exchangeNum},!0,this).then((function(o){t.exChangeGoodsId=o.data.id,t.$refs.mModal2.show(),t.$refs.mPopup.hide(),t.getInfo()}))},useNow:function(){var t=this;this.$api.wishApi.prizesUse(this.exChangeGoodsId,{child_id:this.child_id,status_map:"success"},!0,this).then((function(o){t.$util.msg("使用成功！请即时给孩子兑现~")}))},goodsAdd:function(){t.getStorageSync("userInfo").family.vip_end_day<1&&this.goodsData[1].goods.length>2?(this.errMsg=this.is_created?"标准版最多可添加3个自定义星愿，请升级到专业版，感谢您的理解~":"标准版最多可添加3个自定义星愿，请联系孩子创建者升级，感谢您的理解~",this.$refs.slotModal.show()):this.goPage("/pages/wish/goodsAdd")},renew:function(){this.$refs.slotModal.hide(),this.is_created&&(t.setStorageSync("renew",!0),t.switchTab({url:"/pages/mine"}))}}};o.default=n}).call(this,n("df3c").default)},d401:function(t,o,n){"use strict";n.r(o);var e=n("8c79"),i=n("4129");for(var s in i)["default"].indexOf(s)<0&&function(t){n.d(o,t,(function(){return i[t]}))}(s);n("0284");var a=n("828b"),r=Object(a.a)(i.default,e.b,e.c,!1,null,"cfcebff2",null,!1,e.a,void 0);o.default=r.exports}},[["808e","common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/wish.js'});require("pages/wish.js");