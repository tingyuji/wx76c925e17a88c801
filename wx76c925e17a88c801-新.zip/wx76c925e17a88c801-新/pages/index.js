(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index" ], {
    "4dfb": function(t, e, i) {
        "use strict";
        i.d(e, "b", function() {
            return n;
        }), i.d(e, "c", function() {
            return r;
        }), i.d(e, "a", function() {
            return a;
        });
        var a = {
            pageLoading: function() {
                return i.e("components/pageLoading/pageLoading").then(i.bind(null, "7f33"));
            },
            tabs: function() {
                return i.e("components/tabs/tabs").then(i.bind(null, "461d"));
            },
            guideMask: function() {
                return i.e("components/guideMask/guideMask").then(i.bind(null, "7a4f"));
            },
            scored: function() {
                return i.e("components/scored/scored").then(i.bind(null, "38ef"));
            },
            checkChild: function() {
                return i.e("components/checkChild/checkChild").then(i.bind(null, "1e15"));
            },
            sheet: function() {
                return i.e("components/sheet/sheet").then(i.bind(null, "f546"));
            },
            mModal: function() {
                return i.e("components/mModal/mModal").then(i.bind(null, "68ea"));
            },
            slotModal: function() {
                return i.e("components/slotModal/slotModal").then(i.bind(null, "8d9e"));
            },
            tabbar: function() {
                return i.e("components/tabbar/tabbar").then(i.bind(null, "09e8"));
            }
        }, n = function() {
            var t = this, e = (t.$createElement, t._self._c, t.currentTab < 8 && t.progressData.today_num ? Number(t.progressData.today_star) : null), i = !t.pageData.list.length && 2 == t.pageData.status, a = t.pageData.list.length, n = a ? t.__map(t.pageData.list, function(e, i) {
                return {
                    $orig: t.__get_orig(e),
                    g2: e.behaviors.length
                };
            }) : null;
            t._isMounted || (t.e0 = function(e) {
                return t.$refs.checkChild.show();
            }, t.e1 = function(e) {
                return t.$refs.checkChild.show();
            }, t.e2 = function(e, i, a) {
                var n = arguments[arguments.length - 1].currentTarget.dataset, r = n.eventParams || n["event-params"];
                i = r.behavior, a = r.beha, t.is_created && t.longpress(i.id, a);
            }, t.e3 = function(e, i, a) {
                var n = arguments[arguments.length - 1].currentTarget.dataset, r = n.eventParams || n["event-params"];
                i = r.behavior, a = r.beha, e.stopPropagation(), t.is_created && t.goPage("/pages/target/targetEdit?category_id=" + i.id + "&behaId=" + a.pid + "&beha=" + encodeURIComponent(JSON.stringify(a)));
            }, t.e4 = function(e) {
                return e.stopPropagation(), t.$util.msg("不可打分，未到评分日期，请查看目标设置");
            }, t.e5 = function(e) {
                return t.$refs.slotModal.hide();
            }, t.e6 = function(e) {
                return t.$refs.appUpload.hide();
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    m0: e,
                    g0: i,
                    g1: a,
                    l0: n
                }
            });
        }, r = [];
    },
    7118: function(t, e, i) {
        "use strict";
        (function(t, e) {
            var a = i("47a9");
            i("e465"), a(i("3240"));
            var n = a(i("f1ce"));
            t.__webpack_require_UNI_MP_PLUGIN__ = i, e(n.default);
        }).call(this, i("3223").default, i("df3c").createPage);
    },
    "97cc": function(t, e, i) {
        "use strict";
        i.r(e);
        var a = i("a8cf"), n = i.n(a);
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(t) {
            i.d(e, t, function() {
                return a[t];
            });
        }(r);
        e.default = n.a;
    },
    a8cf: function(t, e, i) {
        "use strict";
        (function(t, a) {
            var n = i("47a9");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = n(i("7eb4")), s = n(i("ee10")), o = {
                mixins: [ n(i("6337")).default ],
                data: function() {
                    return {
                        stickTopOpacity: 0,
                        customTop: 0,
                        customHeight: 0,
                        stickBg: "rgba(0,0,0,0)",
                        stickPadding: "30rpx",
                        child_id: null,
                        is_created: !1,
                        child: {},
                        childList: [],
                        progressData: {},
                        behaviors: [],
                        currentTypeId: null,
                        currentTarget: {},
                        showAini: !0,
                        iosSafeArea: !0,
                        inited: !1,
                        guideRect: {},
                        guideStar: 0,
                        guideStarTimer: null,
                        errMsg: "",
                        vipLimitNum: 10,
                        options: [ {
                            text: "编辑",
                            style: {
                                backgroundColor: "#ADE03D"
                            }
                        }, {
                            text: "删除",
                            style: {
                                backgroundColor: "#F9723E"
                            }
                        } ],
                        sheetArr: [ {
                            name: "编辑",
                            id: 1
                        }, {
                            name: "删除",
                            id: 2
                        }, {
                            name: "批量管理",
                            id: 0
                        } ],
                        updateData: {
                            latest_version: "",
                            description: "",
                            force_update: 0,
                            download_url: ""
                        }
                    };
                },
                onPageScroll: function(t) {
                    this.stickTopOpacity = (t.scrollTop - 5) / 100, this.stickBg = t.scrollTop > 100 ? "#FFF" : "rgba(0,0,0,0)", 
                    this.stickPadding = t.scrollTop > 100 ? "0rpx" : "30rpx";
                },
                onLoad: function() {
                    var e = this;
                    return (0, s.default)(r.default.mark(function i() {
                        var a;
                        return r.default.wrap(function(i) {
                            for (;;) switch (i.prev = i.next) {
                              case 0:
                                return e.getCustomTop(), e.initData(), i.next = 4, e.$onLaunched;

                              case 4:
                                e.child_id = t.getStorageSync("child_id"), a = t.getStorageSync("userInfo").step, 
                                e.child_id && 9 == a ? (e.is_created = t.getStorageSync("userInfo").family.is_created, 
                                e.getVipLimitNum(), e.getList()) : 2 == a ? t.reLaunch({
                                    url: "/pages/enterStep/stepOne"
                                }) : 3 == a && t.reLaunch({
                                    url: "/pages/enterStep/stepThree"
                                }), t.$off("index_refresh_target").$on("index_refresh_target", function(t) {
                                    e.getList(), e.getChildInfo();
                                });

                              case 8:
                              case "end":
                                return i.stop();
                            }
                        }, i);
                    }))();
                },
                onShow: function() {
                    var e = this;
                    return (0, s.default)(r.default.mark(function i() {
                        return r.default.wrap(function(i) {
                            for (;;) switch (i.prev = i.next) {
                              case 0:
                                return i.next = 2, e.$onLaunched;

                              case 2:
                                e.child_id = t.getStorageSync("child_id"), e.child_id && e.getChildInfo();

                              case 4:
                              case "end":
                                return i.stop();
                            }
                        }, i);
                    }))();
                },
                methods: {
                    updateApp: function() {
                        this.$refs.appUpload.hide(), this.$util.updateApp(this);
                    },
                    onClick: function(t, e, i, a) {
                        0 == t.index ? this.goPage("/pages/target/targetEdit?category_id=".concat(e, "&behaId=").concat(i, "&beha=").concat(encodeURIComponent(JSON.stringify(a)))) : 1 == t.index && this.delBtn(a);
                    },
                    longpress: function(t, e) {
                        this.currentTypeId = t, this.currentTarget = e, this.$refs.sheet.show();
                    },
                    sheetSelect: function(t) {
                        0 == t.id ? this.goPage("/pages/target/targetManage") : 1 == t.id ? this.goPage("/pages/target/targetEdit?category_id=".concat(this.currentTypeId, "&behaId=").concat(this.currentTarget.pid, "&beha=").concat(encodeURIComponent(JSON.stringify(this.currentTarget)))) : 2 == t.id && this.delBtn(this.currentTarget);
                    },
                    scroll: function(t) {
                        this.stickTopOpacity = t.target.scrollTop / 100, this.stickBg = t.target.scrollTop > 100 ? "#FFF" : "rgba(0,0,0,0)";
                    },
                    getCustomTop: function() {
                        this.customTop = getApp().globalData.capsuleInfo.bottom, this.customHeight = getApp().globalData.capsuleInfo.height;
                    },
                    initData: function() {
                        this.currentTab = 7;
                        for (var t = [ {
                            name: "今天",
                            desc: this.$util.getFormatDate().day,
                            value: this.$util.getFormatDate().date
                        }, {
                            name: "明天",
                            desc: this.$util.getFormatDate(null, 1).day,
                            value: this.$util.getFormatDate(null, 1).date
                        } ], e = 0; e < 7; e++) t.unshift({
                            name: this.$util.getFormatDate(null, -e - 1).weekDay,
                            desc: this.$util.getFormatDate(null, -e - 1).day,
                            value: this.$util.getFormatDate(null, -e - 1).date
                        });
                        this.initTabList(t);
                    },
                    checkGuide: function() {
                        var e = this;
                        setTimeout(function() {
                            !t.getStorageSync("oldUser") && e.pageData.list.length && e.$refs.guideMask.show();
                        }, 500);
                    },
                    getVipLimitNum: function() {
                        var t = this;
                        this.$api.commonApi.configurations({}, !1, this).then(function(e) {
                            t.vipLimitNum = Number(e.data.primary.child.behavior_num);
                        });
                    },
                    getChildInfo: function() {
                        var e = this;
                        this.$api.commonApi.childrenInfo(this.child_id, {}, !1, this).then(function(i) {
                            t.setStorageSync("child", i.data);
                            var a = e.child.score ? e.child.score : 0;
                            e.child = i.data;
                            var n = e.child.score;
                            if (n - a > 10 && (a = n - 10), e.child.score = a, a < n) var r = setInterval(function() {
                                e.child.score < n ? e.child.score++ : clearInterval(r);
                            }, 500 / (n - a)); else if (a > n) {
                                e.child.score = a;
                                var s = setInterval(function() {
                                    e.child.score > n ? e.child.score-- : clearInterval(s);
                                }, 500 / (a - n));
                            }
                            e.inited = !0;
                        });
                    },
                    selectTab: function(t) {
                        this.currentTab = t, this.clearData(), this.getList();
                    },
                    getPoster: function() {
                        if (0 == this.progressData.today_success_num) return this.$util.msg("你还没有打分，请完成打分后领取报告");
                        this.goPage("/pages/target/posterShare?date=".concat(this.tabList[this.currentTab].value));
                    },
                    getList: function() {
                        var t = this;
                        this.$api.behaviorsApi.behaviorsDay({
                            child_id: this.child_id,
                            day: this.tabList[this.currentTab].value
                        }, !1, this).then(function(e) {
                            t.progressData = e.extends ? e.extends : {}, e.data.length && e.data.filter(function(t) {
                                t.complete_num = t.behaviors.filter(function(t) {
                                    return 0 != t.status;
                                }).length;
                            }), t.initend(e.data);
                        });
                    },
                    initend: function(e) {
                        var i = this;
                        this.pageData.list = e, this.pageData.status = 2, this.$nextTick(function() {
                            t.createSelectorQuery().in(i).select(".goal").boundingClientRect(function(t) {
                                t && (i.guideRect = t, i.guideRect.step = 1, i.guideRect.tips = "点击此处即可编辑目标~");
                            }).exec();
                        });
                    },
                    addTarget: function(e) {
                        t.vibrateShort(), this.goPage("/pages/target/targetAdd?category_id=".concat(e));
                    },
                    targetClick: function(e, i, a, n) {
                        var r = this;
                        if (0 != i.is_today) {
                            if (0 == i.status && -2 == a) return this.$util.msg("点击星星可评分，点击表情可扣分");
                            if (!t.getStorageSync("userInfo").mobile && this.progressData.today_success_num > 1) return this.$refs.mModalPhone.show();
                            if (this.currentTab > 7) return this.$util.msg("时间未到，不能打卡");
                            if (t.getStorageSync("userInfo").family.vip_end_day < 1 && this.$util.compareDate(this.tabList[this.currentTab].value) < 0) return this.$util.pageClick(this, "补卡"), 
                            this.errMsg = this.is_created ? "标准版不支持补卡功能，请升级到专业版，感谢您的理解~" : "标准版不支持补卡功能，请联系孩子创建者升级，感谢您的理解~", 
                            this.$refs.slotModal.show();
                            var s = t.getStorageSync("tmpTime"), o = new Date();
                            if ((!s || s && o - s > 864e5) && (t.setStorageSync("tmpTime", o), t.requestSubscribeMessage({
                                tmplIds: [ "Tqf4HetN1qhQ5XBlh8hjZqztNL0zFN0c0Oyy0q0kiPU" ]
                            })), this.currentTypeId = e, this.currentTarget = i, -1 == a || -2 == a) this.showAini = !1, 
                            this.currentTarget.status_cache = i.status, this.$refs.scored.show(); else {
                                if (1 == a ? t.vibrateLong() : t.vibrateShort(), t.getStorageSync("userInfo").family.vip_end_day < 1 && this.vipLimitNum <= this.progressData.today_success_num) return this.errMsg = this.is_created ? "标准版每天最多可评定".concat(this.vipLimitNum, "个目标，请升级到专业版，感谢您的理解~") : "标准版每天最多可评定".concat(this.vipLimitNum, "个目标，请联系孩子创建者升级，感谢您的理解~"), 
                                this.$util.pageClick(this, "打卡次数"), this.$refs.slotModal.show();
                                this.showAini = !0, this.currentTarget.status = a, this.currentTarget.star = n + 1, 
                                this.currentTarget.status_cache = a, this.$refs.scored.show(), this.$api.behaviorsApi.behaviorsScored(this.currentTarget.id, {
                                    child_id: this.child_id,
                                    status: a,
                                    star: n + 1,
                                    star_day: this.tabList[this.currentTab].value
                                }, !1, this).then(function(t) {
                                    r.getChildInfo(), r.getList();
                                }).catch(function(t) {
                                    900 == t.code && (r.errMsg = t.message, r.$refs.slotModal.show());
                                });
                            }
                        }
                    },
                    renew: function() {
                        this.$refs.slotModal.hide(), this.is_created && (t.setStorageSync("renew", !0), 
                        t.switchTab({
                            url: "/pages/mine"
                        }));
                    },
                    delBtn: function(t) {
                        this.currentTarget = t, this.$refs.mModal.show();
                    },
                    deleteTarget: function() {
                        var t = this;
                        this.$api.behaviorsApi.behaviorsDelete(this.currentTarget.pid, {}, !0, this).then(function(e) {
                            t.$util.msg("删除成功"), t.refreshTab();
                        });
                    },
                    closeMini: function() {
                        a.exitMiniProgram();
                    },
                    handleAgree: function() {
                        this.$refs.mPopup.hide();
                    },
                    nextStep: function() {
                        var e = this;
                        1 == this.guideRect.step ? this.guideRect.tips = "点击此处为未完成目标~" : 2 == this.guideRect.step && (this.guideRect.tips = "点击此处即可打星~", 
                        this.guideStarTimer = setInterval(function() {
                            if (3 == e.guideStar) return e.guideStar = 0;
                            e.guideStar++;
                        }, 1e3)), 3 == this.guideRect.step && (clearInterval(this.guideStarTimer), this.guideStar = 0, 
                        this.$refs.guideMask.hide(), t.setStorageSync("oldUser", !0)), this.guideRect.step++, 
                        this.$forceUpdate();
                    }
                }
            };
            e.default = o;
        }).call(this, i("df3c").default, i("3223").default);
    },
    bcd4: function(t, e, i) {
        "use strict";
        var a = i("c385");
        i.n(a).a;
    },
    c385: function(t, e, i) {},
    f1ce: function(t, e, i) {
        "use strict";
        i.r(e);
        var a = i("4dfb"), n = i("97cc");
        for (var r in n) [ "default" ].indexOf(r) < 0 && function(t) {
            i.d(e, t, function() {
                return n[t];
            });
        }(r);
        i("bcd4");
        var s = i("828b"), o = Object(s.a)(n.default, a.b, a.c, !1, null, "4a5448ee", null, !1, a.a, void 0);
        e.default = o.exports;
    }
}, [ [ "7118", "common/runtime", "common/vendor" ] ] ]);