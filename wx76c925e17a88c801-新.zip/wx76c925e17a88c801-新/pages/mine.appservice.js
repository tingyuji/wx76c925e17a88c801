$gwx_XC_31=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_31 || [];
function gz$gwx_XC_31_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_31_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_31_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_31_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'content data-v-55d32f1c'])
Z([[2,'+'],[[2,'+'],[1,'padding-top:'],[[2,'+'],[[7],[3,'customTop']],[1,'px']]],[1,';']])
Z([3,'__l'])
Z([3,'data-v-55d32f1c'])
Z([[7],[3,'loadingShow']])
Z([3,'fe5e5c8c-1'])
Z([[2,'&&'],[[6],[[7],[3,'userInfo']],[3,'id']],[[6],[[6],[[7],[3,'userInfo']],[3,'family']],[3,'is_created']]])
Z([[6],[[7],[3,'$root']],[3,'g0']])
Z([3,'cell-card data-v-55d32f1c'])
Z([[2,'&&'],[[6],[[7],[3,'userInfo']],[3,'family']],[[6],[[6],[[7],[3,'userInfo']],[3,'family']],[3,'is_created']]])
Z(z[9])
Z([[6],[[7],[3,'userInfo']],[3,'is_backdoor']])
Z([[7],[3,'child_id']])
Z(z[2])
Z([3,'data-v-55d32f1c vue-ref'])
Z([3,'checkChild'])
Z([3,'/pages/mine'])
Z([3,'fe5e5c8c-2'])
Z(z[2])
Z(z[14])
Z([3,'slotModal'])
Z([3,'fe5e5c8c-3'])
Z([[4],[[5],[1,'default']]])
Z(z[2])
Z([3,'__e'])
Z([1,true])
Z(z[14])
Z([3,'立即开通'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^submit']],[[4],[[5],[[4],[[5],[1,'payVip']]]]]]]]])
Z([3,'mPopup'])
Z([3,'fe5e5c8c-4'])
Z(z[22])
Z([1,1005])
Z([3,'mPopup-wrap flex-column flex-align-center data-v-55d32f1c'])
Z(z[24])
Z([3,'order flex-align-center data-v-55d32f1c'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'goPage']],[[4],[[5],[1,'/pages/vip/orderList']]]]]]]]]]])
Z([3,'position:absolute;right:15rpx;top:10rpx;'])
Z([[7],[3,'waitPayNum']])
Z(z[3])
Z([3,'true'])
Z([3,'height:400px;'])
Z([[6],[[7],[3,'userInfo']],[3,'family']])
Z([3,'index'])
Z([3,'item'])
Z([[6],[[7],[3,'vipPriceData']],[3,'prices']])
Z([3,'id'])
Z(z[24])
Z([[4],[[5],[[5],[[5],[[5],[[5],[1,'list-item']],[1,'flex-center']],[1,'flex-column']],[1,'data-v-55d32f1c']],[[2,'?:'],[[2,'=='],[[7],[3,'index']],[[7],[3,'vipIndex']]],[1,'selected'],[1,'']]]])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'checkVip']],[[4],[[5],[[7],[3,'index']]]]]]]]]]]])
Z([[2,'>'],[[7],[3,'index']],[1,0]])
Z([3,'price flex data-v-55d32f1c'])
Z([[2,'=='],[[7],[3,'index']],[1,0]])
Z([[2,'=='],[[7],[3,'index']],[1,1]])
Z([[2,'=='],[[7],[3,'index']],[1,2]])
Z([3,'vip-list-info data-v-55d32f1c'])
Z([3,'#FF9736'])
Z(z[2])
Z(z[3])
Z([3,'#FFF'])
Z([1,24])
Z([1,34])
Z(z[25])
Z([[2,'+'],[[2,'+'],[1,'fe5e5c8c-5'],[1,',']],[1,'fe5e5c8c-4']])
Z(z[61])
Z(z[56])
Z(z[2])
Z(z[3])
Z(z[59])
Z(z[60])
Z(z[61])
Z(z[25])
Z([[2,'+'],[[2,'+'],[1,'fe5e5c8c-6'],[1,',']],[1,'fe5e5c8c-4']])
Z(z[61])
Z(z[56])
Z(z[2])
Z(z[3])
Z(z[59])
Z(z[60])
Z(z[61])
Z(z[25])
Z([[2,'+'],[[2,'+'],[1,'fe5e5c8c-7'],[1,',']],[1,'fe5e5c8c-4']])
Z(z[61])
Z(z[56])
Z(z[2])
Z(z[3])
Z(z[59])
Z(z[60])
Z(z[61])
Z(z[25])
Z([[2,'+'],[[2,'+'],[1,'fe5e5c8c-8'],[1,',']],[1,'fe5e5c8c-4']])
Z(z[61])
Z(z[56])
Z(z[2])
Z(z[3])
Z(z[59])
Z(z[60])
Z(z[61])
Z(z[25])
Z([[2,'+'],[[2,'+'],[1,'fe5e5c8c-9'],[1,',']],[1,'fe5e5c8c-4']])
Z(z[61])
Z(z[56])
Z(z[2])
Z(z[3])
Z(z[59])
Z(z[60])
Z(z[61])
Z(z[25])
Z([[2,'+'],[[2,'+'],[1,'fe5e5c8c-10'],[1,',']],[1,'fe5e5c8c-4']])
Z(z[61])
Z(z[24])
Z([3,'agreement-wrap flex-align-center data-v-55d32f1c'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e4']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'#FFEA00'])
Z(z[2])
Z(z[3])
Z([3,'#000000'])
Z(z[60])
Z(z[61])
Z([[7],[3,'agreement']])
Z([[2,'+'],[[2,'+'],[1,'fe5e5c8c-11'],[1,',']],[1,'fe5e5c8c-4']])
Z(z[61])
Z(z[2])
Z(z[25])
Z(z[14])
Z([3,'绑定'])
Z([3,'防止帐号丢失和孩子数据隐私，请先绑定手机号码'])
Z([3,'mModalPhone'])
Z([3,'提示'])
Z([3,'fe5e5c8c-12'])
Z(z[2])
Z(z[14])
Z([3,'slotModal2'])
Z([1,false])
Z([3,'fe5e5c8c-13'])
Z(z[22])
Z(z[2])
Z(z[24])
Z(z[14])
Z([[4],[[5],[[4],[[5],[[5],[1,'^submit']],[[4],[[5],[[4],[[5],[1,'backdoor']]]]]]]]])
Z([3,'mPopup3'])
Z(z[25])
Z([3,'fe5e5c8c-14'])
Z(z[22])
Z(z[2])
Z(z[24])
Z(z[24])
Z(z[14])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^submit']],[[4],[[5],[[4],[[5],[1,'mPopupSubmit2']]]]]]]],[[4],[[5],[[5],[1,'^hide']],[[4],[[5],[[4],[[5],[1,'mPopupHide2']]]]]]]]])
Z([3,'mPopup2'])
Z([3,'fe5e5c8c-15'])
Z(z[22])
Z([1,1001])
Z([3,'star-wrap flex-align-center flex-column data-v-55d32f1c'])
Z([[7],[3,'mPopup2Open']])
Z(z[2])
Z(z[24])
Z(z[3])
Z([[4],[[5],[[4],[[5],[[5],[1,'^change']],[[4],[[5],[[4],[[5],[1,'numberChange']]]]]]]]])
Z([1,114])
Z([1,100])
Z([1,0])
Z([3,'27px'])
Z(z[25])
Z([1,40])
Z([3,'30px'])
Z([[7],[3,'afterStar']])
Z([[2,'+'],[[2,'+'],[1,'fe5e5c8c-16'],[1,',']],[1,'fe5e5c8c-15']])
Z([1,60])
Z(z[154])
Z(z[2])
Z(z[3])
Z([1,2])
Z([3,'fe5e5c8c-17'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_31_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_31_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_31=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_31=true;
var x=['./pages/mine.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_31_1()
var l7G=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var bAH=_mz(z,'page-loading',['bind:__l',2,'class',1,'loadingShow_',2,'vueId',3],[],e,s,gg)
_(l7G,bAH)
var a8G=_v()
_(l7G,a8G)
if(_oz(z,6,e,s,gg)){a8G.wxVkey=1
}
var t9G=_v()
_(l7G,t9G)
if(_oz(z,7,e,s,gg)){t9G.wxVkey=1
}
var oBH=_n('view')
_rz(z,oBH,'class',8,e,s,gg)
var xCH=_v()
_(oBH,xCH)
if(_oz(z,9,e,s,gg)){xCH.wxVkey=1
}
var oDH=_v()
_(oBH,oDH)
if(_oz(z,10,e,s,gg)){oDH.wxVkey=1
}
var fEH=_v()
_(oBH,fEH)
if(_oz(z,11,e,s,gg)){fEH.wxVkey=1
}
xCH.wxXCkey=1
oDH.wxXCkey=1
fEH.wxXCkey=1
_(l7G,oBH)
var e0G=_v()
_(l7G,e0G)
if(_oz(z,12,e,s,gg)){e0G.wxVkey=1
var cFH=_mz(z,'check-child',['bind:__l',13,'class',1,'data-ref',2,'page',3,'vueId',4],[],e,s,gg)
_(e0G,cFH)
}
var hGH=_mz(z,'slot-modal',['bind:__l',18,'class',1,'data-ref',2,'vueId',3,'vueSlots',4],[],e,s,gg)
_(l7G,hGH)
var oHH=_mz(z,'m-popup',['bind:__l',23,'bind:submit',1,'btnShow',2,'class',3,'confirmBtnText',4,'data-event-opts',5,'data-ref',6,'vueId',7,'vueSlots',8,'zIndex',9],[],e,s,gg)
var cIH=_n('view')
_rz(z,cIH,'class',33,e,s,gg)
var oJH=_mz(z,'view',['bindtap',34,'class',1,'data-event-opts',2,'style',3],[],e,s,gg)
var lKH=_v()
_(oJH,lKH)
if(_oz(z,38,e,s,gg)){lKH.wxVkey=1
}
lKH.wxXCkey=1
_(cIH,oJH)
var aLH=_mz(z,'scroll-view',['class',39,'scrollY',1,'style',2],[],e,s,gg)
var tMH=_v()
_(aLH,tMH)
if(_oz(z,42,e,s,gg)){tMH.wxVkey=1
}
var eNH=_v()
_(aLH,eNH)
var bOH=function(xQH,oPH,oRH,gg){
var cTH=_mz(z,'view',['bindtap',47,'class',1,'data-event-opts',2],[],xQH,oPH,gg)
var hUH=_v()
_(cTH,hUH)
if(_oz(z,50,xQH,oPH,gg)){hUH.wxVkey=1
}
var oVH=_n('view')
_rz(z,oVH,'class',51,xQH,oPH,gg)
var cWH=_v()
_(oVH,cWH)
if(_oz(z,52,xQH,oPH,gg)){cWH.wxVkey=1
}
var oXH=_v()
_(oVH,oXH)
if(_oz(z,53,xQH,oPH,gg)){oXH.wxVkey=1
}
var lYH=_v()
_(oVH,lYH)
if(_oz(z,54,xQH,oPH,gg)){lYH.wxVkey=1
}
cWH.wxXCkey=1
oXH.wxXCkey=1
lYH.wxXCkey=1
_(cTH,oVH)
hUH.wxXCkey=1
_(oRH,cTH)
return oRH
}
eNH.wxXCkey=2
_2z(z,45,bOH,e,s,gg,eNH,'item','index','id')
var aZH=_n('view')
_rz(z,aZH,'class',55,e,s,gg)
var t1H=_mz(z,'m-radio',['actBgColor',56,'bind:__l',1,'class',2,'color',3,'fontSize',4,'height',5,'selected',6,'vueId',7,'width',8],[],e,s,gg)
_(aZH,t1H)
var e2H=_mz(z,'m-radio',['actBgColor',65,'bind:__l',1,'class',2,'color',3,'fontSize',4,'height',5,'selected',6,'vueId',7,'width',8],[],e,s,gg)
_(aZH,e2H)
var b3H=_mz(z,'m-radio',['actBgColor',74,'bind:__l',1,'class',2,'color',3,'fontSize',4,'height',5,'selected',6,'vueId',7,'width',8],[],e,s,gg)
_(aZH,b3H)
var o4H=_mz(z,'m-radio',['actBgColor',83,'bind:__l',1,'class',2,'color',3,'fontSize',4,'height',5,'selected',6,'vueId',7,'width',8],[],e,s,gg)
_(aZH,o4H)
var x5H=_mz(z,'m-radio',['actBgColor',92,'bind:__l',1,'class',2,'color',3,'fontSize',4,'height',5,'selected',6,'vueId',7,'width',8],[],e,s,gg)
_(aZH,x5H)
var o6H=_mz(z,'m-radio',['actBgColor',101,'bind:__l',1,'class',2,'color',3,'fontSize',4,'height',5,'selected',6,'vueId',7,'width',8],[],e,s,gg)
_(aZH,o6H)
_(aLH,aZH)
tMH.wxXCkey=1
_(cIH,aLH)
var f7H=_mz(z,'view',['bindtap',110,'class',1,'data-event-opts',2],[],e,s,gg)
var c8H=_mz(z,'m-radio',['actBgColor',113,'bind:__l',1,'class',2,'color',3,'fontSize',4,'height',5,'selected',6,'vueId',7,'width',8],[],e,s,gg)
_(f7H,c8H)
_(cIH,f7H)
_(oHH,cIH)
_(l7G,oHH)
var h9H=_mz(z,'m-modal',['bind:__l',122,'bindPhone',1,'class',2,'confirmText',3,'content',4,'data-ref',5,'title',6,'vueId',7],[],e,s,gg)
_(l7G,h9H)
var o0H=_mz(z,'slot-modal',['bind:__l',130,'class',1,'data-ref',2,'maskClose',3,'vueId',4,'vueSlots',5],[],e,s,gg)
_(l7G,o0H)
var cAI=_mz(z,'m-popup',['bind:__l',136,'bind:submit',1,'class',2,'data-event-opts',3,'data-ref',4,'hasTab',5,'vueId',6,'vueSlots',7],[],e,s,gg)
_(l7G,cAI)
var oBI=_mz(z,'m-popup',['bind:__l',144,'bind:hide',1,'bind:submit',2,'class',3,'data-event-opts',4,'data-ref',5,'vueId',6,'vueSlots',7,'zIndex',8],[],e,s,gg)
var lCI=_n('view')
_rz(z,lCI,'class',153,e,s,gg)
var aDI=_v()
_(lCI,aDI)
if(_oz(z,154,e,s,gg)){aDI.wxVkey=1
var eFI=_mz(z,'uni-number-box',['bind:__l',155,'bind:change',1,'class',2,'data-event-opts',3,'height',4,'midWidth',5,'min',6,'numberSize',7,'star',8,'starLeft',9,'symbilSize',10,'value',11,'vueId',12,'width',13],[],e,s,gg)
_(aDI,eFI)
}
var tEI=_v()
_(lCI,tEI)
if(_oz(z,169,e,s,gg)){tEI.wxVkey=1
}
aDI.wxXCkey=1
aDI.wxXCkey=3
tEI.wxXCkey=1
_(oBI,lCI)
_(l7G,oBI)
var bGI=_mz(z,'tabbar',['bind:__l',170,'class',1,'current',2,'vueId',3],[],e,s,gg)
_(l7G,bGI)
a8G.wxXCkey=1
t9G.wxXCkey=1
e0G.wxXCkey=1
e0G.wxXCkey=3
_(r,l7G)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_31";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_31();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/mine.wxml'] = [$gwx_XC_31, './pages/mine.wxml'];else __wxAppCode__['pages/mine.wxml'] = $gwx_XC_31( './pages/mine.wxml' );
	;__wxRoute = "pages/mine";__wxRouteBegin = true;__wxAppCurrentFile__="pages/mine.js";define("pages/mine.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/mine"],{"405a":function(e,t,n){"use strict";n.r(t);var o=n("d502"),i=n("e18e");for(var a in i)["default"].indexOf(a)<0&&function(e){n.d(t,e,(function(){return i[e]}))}(a);n("d410");var r=n("828b"),s=Object(r.a)(i.default,o.b,o.c,!1,null,"55d32f1c",null,!1,o.a,void 0);t.default=s.exports},"9f5d":function(e,t,n){},a37a:function(e,t,n){"use strict";(function(e,t){var o=n("47a9");n("e465"),o(n("3240"));var i=o(n("405a"));e.__webpack_require_UNI_MP_PLUGIN__=n,t(i.default)}).call(this,n("3223").default,n("df3c").createPage)},d410:function(e,t,n){"use strict";var o=n("9f5d");n.n(o).a},d502:function(e,t,n){"use strict";n.d(t,"b",(function(){return i})),n.d(t,"c",(function(){return a})),n.d(t,"a",(function(){return o}));var o={pageLoading:function(){return n.e("components/pageLoading/pageLoading").then(n.bind(null,"7f33"))},checkChild:function(){return n.e("components/checkChild/checkChild").then(n.bind(null,"1e15"))},slotModal:function(){return n.e("components/slotModal/slotModal").then(n.bind(null,"8d9e"))},mPopup:function(){return n.e("components/mPopup/mPopup").then(n.bind(null,"ae6f"))},mRadio:function(){return n.e("components/mRadio/mRadio").then(n.bind(null,"b7a0"))},mModal:function(){return n.e("components/mModal/mModal").then(n.bind(null,"68ea"))},uniNumberBox:function(){return n.e("uni_modules/uni-number-box/components/uni-number-box/uni-number-box").then(n.bind(null,"2406"))},tabbar:function(){return n.e("components/tabbar/tabbar").then(n.bind(null,"09e8"))}},i=function(){var e=this,t=(e.$createElement,e._self._c,e.banners.length),n=Math.abs(e.afterStar-e.child.score);e._isMounted||(e.e0=function(t){e.goPage("/pages/mine/setting?userInfo="+encodeURIComponent(JSON.stringify(e.userInfo)))},e.e1=function(t){return e.$refs.checkChild.show()},e.e2=function(t){return e.$refs.mPopup3.show()},e.e3=function(t){return e.$refs.slotModal.hide()},e.e4=function(t){e.agreement=!e.agreement},e.e5=function(t){t.stopPropagation(),e.goPage("/pages/common/agreement?title=用户服务协议&content="+encodeURIComponent(e.vipPriceData.agreement))},e.e6=function(t){t.stopPropagation(),e.goPage("/pages/common/agreement?title=开通须知&content="+encodeURIComponent(e.vipPriceData.open_notice))},e.e7=function(t){t.stopPropagation(),e.goPage("/pages/common/agreement?title=用户服务协议&content="+encodeURIComponent(e.vipPriceData.agreement))},e.e8=function(t){t.stopPropagation(),e.goPage("/pages/common/agreement?title=开通须知&content="+encodeURIComponent(e.vipPriceData.open_notice))},e.e9=function(t){return e.$refs.slotModal2.hide()}),e.$mp.data=Object.assign({},{$root:{g0:t,g1:n}})},a=[]},e03e:function(e,t,n){"use strict";(function(e){var o=n("47a9");Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i=o(n("7eb4")),a=o(n("ee10")),r={data:function(){return{firstLoad:!0,child_id:null,customTop:0,userInfo:{},child:{},banners:[],waitPayNum:0,vipPriceData:{},vipIndex:2,coupon:null,haveCoupon:null,agreement:!1,backdoorId:"",afterStar:0,remark:"",mPopup2Open:!1}},onLoad:function(){var t=this;this.child_id=e.getStorageSync("child_id"),this.getCustomTop(),this.getBanners(),e.$off("selecteCoupon").$on("selecteCoupon",(function(e){t.coupon=e})),e.$off("useCoupon").$on("useCoupon",(function(e){t.coupon=e,t.checkSystem()}))},onShow:function(){e.getStorageSync("renew")&&(e.removeStorageSync("renew"),this.checkSystem()),this.getUserInfo(),this.getChildInfo(),this.getCoupon(),this.getOrder()},methods:{share:function(){},getCustomTop:function(){this.customTop=getApp().globalData.capsuleInfo.bottom+25},getBanners:function(){var e=this;this.$api.activeApi.banners({},!1,this).then((function(t){e.banners=t.data}))},getUserInfo:function(){var t=this;this.$api.commonApi.userInfo({},this.firstLoad,this).then((function(n){t.firstLoad=!1,t.userInfo=n.data,e.setStorageSync("userInfo",n.data)}))},getChildInfo:function(){var t=this;this.$api.commonApi.childrenInfo(this.child_id,{},!1,this).then((function(n){e.setStorageSync("child",n.data),t.child=n.data,t.afterStar=t.child.score}))},getOrder:function(){var e=this;this.$api.vipApi.orderList({status_map:"waiting"},!1,this).then((function(t){e.waitPayNum=t.data.total}))},getVipPrices:function(){var e=this;return new Promise((function(t,n){e.$api.vipApi.pricesList({},!1,e).then((function(n){n.data.prices.filter((function(e){var t=e.price.toString().split(".");e.price1=t[0],e.price2=t[1]?t[1]:null})),e.vipPriceData=n.data,t()}))}))},checkVip:function(e){this.vipIndex=e,this.haveCoupon&&Number(this.vipPriceData.prices[e].price)>=Number(this.haveCoupon.batch.used_amount)?this.coupon=this.haveCoupon:this.coupon=null},getCoupon:function(){var e=this;return(0,a.default)(i.default.mark((function t(){return i.default.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:return t.next=2,e.getVipPrices();case 2:e.$api.vipApi.couponList({status:1,page:1,per_page:1},!1,e).then((function(t){t.data.rows.length?(e.haveCoupon=t.data.rows[0],Number(e.vipPriceData.prices[e.vipIndex].price)>=Number(e.haveCoupon.batch.used_amount)?e.coupon=e.haveCoupon:e.coupon=null):e.coupon=null}));case 3:case"end":return t.stop()}}),t)})))()},checkSystem:function(){if(this.$util.pageClick(this,"点击VIP"),!e.getStorageSync("userInfo").mobile)return this.$refs.mModalPhone.show();"ios"==getApp().globalData.systemName?this.$refs.slotModal.show():this.$refs.mPopup.show()},agreementModal:function(){this.$refs.slotModal2.hide(),this.agreement=!0,this.payVip()},payVip:function(){var t=this,n=this;if(!this.agreement)return this.$refs.slotModal2.show();this.loadingShow=!0,this.$api.vipApi.createVipOrder({price_id:this.vipPriceData.prices[this.vipIndex].id,coupon_id:this.coupon?this.coupon.id:0},!1,this).then((function(o){t.$api.vipApi.payVipOrder({order_sn:o.data.order_sn,trade_type:"JSAPI"},!1,t).then((function(t){var i=t.data.pay_data;e.getProvider({service:"payment",success:function(t){n.loadingShow=!1,e.requestPayment({provider:t.provider[0],timeStamp:i.timeStamp,nonceStr:i.nonceStr,package:i.package,signType:i.signType,paySign:i.paySign,success:function(e){n.$api.vipApi.payVipCheck({order_sn:o.data.order_sn},!0,n).then((function(e){n.$util.msg("支付成功"),n.$refs.mPopup.hide(),n.getUserInfo(),n.getCoupon()}))},fail:function(e){n.getOrder(),n.getCoupon()}})}})}))}))},backdoor:function(){this.$api.commonApi.backdoorLogin({no:this.backdoorId},!0,this).then((function(t){e.setStorageSync("token",t.data.token),e.setStorageSync("userInfo",t.data.user),t.data.user.last_child_id&&e.setStorageSync("child_id",t.data.user.last_child_id),e.reLaunch({url:"/pages/mine"})}))},showStarMPopup:function(){this.mPopup2Open=!0,this.$refs.mPopup2.show()},numberChange:function(e){this.afterStar=e},mPopupSubmit2:function(){var e=this;if(!this.remark)return this.$util.msg("请输入星星变动原因");this.remark=this.remark.trim(),this.$api.commonApi.childrenStarEdit({child_id:this.child.id,amount_before:this.child.score,amount_after:this.afterStar,remark:this.remark},!0,this).then((function(t){e.$util.msg("修改成功"),e.child.score=e.afterStar,e.$refs.mPopup2.hide()}))},mPopupHide2:function(){this.mPopup2Open=!1,this.$forceUpdate()},goStarRecord:function(){this.mPopup2Open=!1,this.$refs.mPopup2.hide(),this.goPage("/pages/mine/starRecord?num=".concat(this.child.score))}}};t.default=r}).call(this,n("df3c").default)},e18e:function(e,t,n){"use strict";n.r(t);var o=n("e03e"),i=n.n(o);for(var a in o)["default"].indexOf(a)<0&&function(e){n.d(t,e,(function(){return o[e]}))}(a);t.default=i.a}},[["a37a","common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/mine.js'});require("pages/mine.js");