(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/checkChild/checkChild" ], {
    "01f9": function(n, t, e) {
        "use strict";
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var e = {
                props: {
                    page: {
                        type: String,
                        default: ""
                    }
                },
                data: function() {
                    return {
                        childArr: [],
                        child_id: null
                    };
                },
                mounted: function() {
                    var t = this;
                    this.child_id = n.getStorageSync("child_id"), this.getChildList(), n.$on("change_child_info", function(n) {
                        t.getChildList();
                    });
                },
                methods: {
                    show: function() {
                        this.$refs.mPopup.show();
                    },
                    hide: function() {
                        this.$refs.mPopup.hide();
                    },
                    getChildList: function() {
                        var n = this;
                        this.$api.commonApi.childrenList({}, !1, this).then(function(t) {
                            n.childArr = t.data;
                        });
                    },
                    submit: function(t) {
                        var e = this;
                        if (this.child_id = t, this.child_id == n.getStorageSync("child_id")) return this.hide();
                        this.$api.commonApi.childrenCheck({
                            child_id: this.child_id
                        }, !0, this).then(function(t) {
                            n.setStorageSync("child_id", e.child_id), n.setStorageSync("token", t.data.token), 
                            n.setStorageSync("userInfo", t.data.user), n.reLaunch({
                                url: e.page
                            });
                        });
                    },
                    manage: function() {
                        this.$refs.mPopup.hide(), this.goPage("/pages/mine/childManage");
                    }
                }
            };
            t.default = e;
        }).call(this, e("df3c").default);
    },
    "1e15": function(n, t, e) {
        "use strict";
        e.r(t);
        var i = e("4df3"), c = e("e467");
        for (var o in c) [ "default" ].indexOf(o) < 0 && function(n) {
            e.d(t, n, function() {
                return c[n];
            });
        }(o);
        e("5896");
        var d = e("828b"), a = Object(d.a)(c.default, i.b, i.c, !1, null, "47ddd7c8", null, !1, i.a, void 0);
        t.default = a.exports;
    },
    "4df3": function(n, t, e) {
        "use strict";
        e.d(t, "b", function() {
            return c;
        }), e.d(t, "c", function() {
            return o;
        }), e.d(t, "a", function() {
            return i;
        });
        var i = {
            pageLoading: function() {
                return e.e("components/pageLoading/pageLoading").then(e.bind(null, "7f33"));
            },
            mPopup: function() {
                return e.e("components/mPopup/mPopup").then(e.bind(null, "ae6f"));
            }
        }, c = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    5896: function(n, t, e) {
        "use strict";
        var i = e("f28e");
        e.n(i).a;
    },
    e467: function(n, t, e) {
        "use strict";
        e.r(t);
        var i = e("01f9"), c = e.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(n) {
            e.d(t, n, function() {
                return i[n];
            });
        }(o);
        t.default = c.a;
    },
    f28e: function(n, t, e) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/checkChild/checkChild-create-component", {
    "components/checkChild/checkChild-create-component": function(n, t, e) {
        e("df3c").createComponent(e("1e15"));
    }
}, [ [ "components/checkChild/checkChild-create-component" ] ] ]);