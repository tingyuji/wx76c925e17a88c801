$gwx_XC_12=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_12 || [];
function gz$gwx_XC_12_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_12_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_12_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_12_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'showBack']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_12_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_12_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_12=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_12=true;
var x=['./components/navBar/navBar.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_12_1()
var t7B=_v()
_(r,t7B)
if(_oz(z,0,e,s,gg)){t7B.wxVkey=1
}
t7B.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_12";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_12();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/navBar/navBar.wxml'] = [$gwx_XC_12, './components/navBar/navBar.wxml'];else __wxAppCode__['components/navBar/navBar.wxml'] = $gwx_XC_12( './components/navBar/navBar.wxml' );
	;__wxRoute = "components/navBar/navBar";__wxRouteBegin = true;__wxAppCurrentFile__="components/navBar/navBar.js";define("components/navBar/navBar.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["components/navBar/navBar"],{4836:function(t,n,a){"use strict";a.d(n,"b",(function(){return e})),a.d(n,"c",(function(){return o})),a.d(n,"a",(function(){}));var e=function(){this.$createElement;this._self._c},o=[]},"501f":function(t,n,a){"use strict";a.r(n);var e=a("4836"),o=a("510e");for(var c in o)["default"].indexOf(c)<0&&function(t){a.d(n,t,(function(){return o[t]}))}(c);a("8ca6");var u=a("828b"),r=Object(u.a)(o.default,e.b,e.c,!1,null,"248cc336",null,!1,e.a,void 0);n.default=r.exports},"510e":function(t,n,a){"use strict";a.r(n);var e=a("6d05"),o=a.n(e);for(var c in e)["default"].indexOf(c)<0&&function(t){a.d(n,t,(function(){return e[t]}))}(c);n.default=o.a},6478:function(t,n,a){},"6d05":function(t,n,a){"use strict";(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a={props:{title:{type:null|String,default:""},showBack:{type:Boolean,default:!0},bgColor:{type:String,default:"#FFFFFF"},textColor:{type:String,default:"#333333"},fixed:{type:Boolean,default:!0}},data:function(){return{customTop:getApp().globalData.capsuleInfo.top,customBottom:getApp().globalData.capsuleInfo.bottom,customHeight:getApp().globalData.capsuleInfo.height,statusbar:getApp().globalData.statusbar}},methods:{onBack:function(){var n=getCurrentPages();n[n.length-2]?t.navigateBack():t.reLaunch({url:"/pages/index"})}}};n.default=a}).call(this,a("df3c").default)},"8ca6":function(t,n,a){"use strict";var e=a("6478");a.n(e).a}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["components/navBar/navBar-create-component",{"components/navBar/navBar-create-component":function(t,n,a){a("df3c").createComponent(a("501f"))}},[["components/navBar/navBar-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'components/navBar/navBar.js'});require("components/navBar/navBar.js");