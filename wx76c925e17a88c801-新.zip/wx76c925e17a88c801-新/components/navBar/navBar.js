(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/navBar/navBar" ], {
    4836: function(t, n, a) {
        "use strict";
        a.d(n, "b", function() {
            return e;
        }), a.d(n, "c", function() {
            return o;
        }), a.d(n, "a", function() {});
        var e = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    "501f": function(t, n, a) {
        "use strict";
        a.r(n);
        var e = a("4836"), o = a("510e");
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(t) {
            a.d(n, t, function() {
                return o[t];
            });
        }(c);
        a("8ca6");
        var u = a("828b"), r = Object(u.a)(o.default, e.b, e.c, !1, null, "248cc336", null, !1, e.a, void 0);
        n.default = r.exports;
    },
    "510e": function(t, n, a) {
        "use strict";
        a.r(n);
        var e = a("6d05"), o = a.n(e);
        for (var c in e) [ "default" ].indexOf(c) < 0 && function(t) {
            a.d(n, t, function() {
                return e[t];
            });
        }(c);
        n.default = o.a;
    },
    6478: function(t, n, a) {},
    "6d05": function(t, n, a) {
        "use strict";
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var a = {
                props: {
                    title: {
                        type: null | String,
                        default: ""
                    },
                    showBack: {
                        type: Boolean,
                        default: !0
                    },
                    bgColor: {
                        type: String,
                        default: "#FFFFFF"
                    },
                    textColor: {
                        type: String,
                        default: "#333333"
                    },
                    fixed: {
                        type: Boolean,
                        default: !0
                    }
                },
                data: function() {
                    return {
                        customTop: getApp().globalData.capsuleInfo.top,
                        customBottom: getApp().globalData.capsuleInfo.bottom,
                        customHeight: getApp().globalData.capsuleInfo.height,
                        statusbar: getApp().globalData.statusbar
                    };
                },
                methods: {
                    onBack: function() {
                        var n = getCurrentPages();
                        n[n.length - 2] ? t.navigateBack() : t.reLaunch({
                            url: "/pages/index"
                        });
                    }
                }
            };
            n.default = a;
        }).call(this, a("df3c").default);
    },
    "8ca6": function(t, n, a) {
        "use strict";
        var e = a("6478");
        a.n(e).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/navBar/navBar-create-component", {
    "components/navBar/navBar-create-component": function(t, n, a) {
        a("df3c").createComponent(a("501f"));
    }
}, [ [ "components/navBar/navBar-create-component" ] ] ]);