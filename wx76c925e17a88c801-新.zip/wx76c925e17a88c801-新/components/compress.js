(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/compress" ], {
    4291: function(t, n, e) {
        "use strict";
        e.r(n);
        var a = e("97b3"), o = e.n(a);
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(c);
        n.default = o.a;
    },
    "97b3": function(t, n, e) {
        "use strict";
        (function(t) {
            var a = e("47a9");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var o = a(e("7eb4")), c = a(e("ee10")), r = {
                data: function() {
                    return {
                        canvasSize: {
                            width: "0px",
                            height: "0px"
                        }
                    };
                },
                methods: {
                    compress: function(n) {
                        var e = this;
                        return new Promise(function() {
                            var a = (0, c.default)(o.default.mark(function a(c, r) {
                                var i, u, s, f, l;
                                return o.default.wrap(function(a) {
                                    for (;;) switch (a.prev = a.next) {
                                      case 0:
                                        return a.next = 2, e.getImageInfo(n.src).then(function(t) {
                                            return t;
                                        }).catch(function(t) {
                                            return t;
                                        });

                                      case 2:
                                        if (i = a.sent) {
                                            a.next = 6;
                                            break;
                                        }
                                        return r("获取图片信息异常"), a.abrupt("return");

                                      case 6:
                                        if (u = n.maxSize || 900, s = n.minSize || 640, f = i.width, l = i.height, console.log("原图大小:".concat(f, "X").concat(l)), 
                                        !(f <= s && l <= s)) {
                                            a.next = 13;
                                            break;
                                        }
                                        return c(n.src), a.abrupt("return");

                                      case 13:
                                        n.maxSize ? (f > n.maxSize && (l = Math.floor(l / (f / n.maxSize)), f = n.maxSize), 
                                        l > n.maxSize && (f = Math.floor(f / (l / n.maxSize)), l = n.maxSize), console.log("压缩大小:".concat(f, "X").concat(l))) : ((f > u || l > u) && (f > l ? l = Math.floor(l / (f / u)) : f = Math.floor(f / (l / u))), 
                                        console.log("压缩大小:".concat(f, "X").concat(l))), e.$set(e, "canvasSize", {
                                            width: "".concat(f, "rpx"),
                                            height: "".concat(l, "rpx")
                                        }), setTimeout(function() {
                                            var a = t.createCanvasContext("myCanvas", e);
                                            a.clearRect(0, 0, f, l), a.drawImage(i.path, 0, 0, t.upx2px(f), t.upx2px(l)), a.draw(!1, function() {
                                                t.canvasToTempFilePath({
                                                    x: 0,
                                                    y: 0,
                                                    width: t.upx2px(f),
                                                    height: t.upx2px(l),
                                                    destWidth: f,
                                                    destHeight: l,
                                                    canvasId: "myCanvas",
                                                    fileType: n.fileType || "jpg",
                                                    quality: n.quality,
                                                    success: function(t) {
                                                        var n = t.tempFilePath;
                                                        console.log("得到的压缩图片", n), c(n);
                                                    },
                                                    fail: function(t) {
                                                        console.log("fail", t), r(null);
                                                    }
                                                }, e);
                                            });
                                        }, 300);

                                      case 16:
                                      case "end":
                                        return a.stop();
                                    }
                                }, a);
                            }));
                            return function(t, n) {
                                return a.apply(this, arguments);
                            };
                        }()).catch(function(t) {});
                    },
                    dataURLtoFile: function(t, n) {
                        for (var e = t.split(","), a = e[0].match(/:(.*?);/)[1], o = atob(e[1]), c = o.length, r = new Uint8Array(c); c--; ) r[c] = o.charCodeAt(c);
                        return new File([ r ], n, {
                            type: a
                        });
                    },
                    dataURLtoBlob: function(t) {
                        for (var n = t.split(","), e = n[0].match(/:(.*?);/)[1], a = atob(n[1]), o = a.length, c = new Uint8Array(o); o--; ) c[o] = a.charCodeAt(o);
                        return console.log(e), new Blob([ c ], {
                            type: e
                        });
                    },
                    getImageInfo: function(n) {
                        return new Promise(function(e, a) {
                            t.getImageInfo({
                                src: n,
                                success: function(t) {
                                    e(t);
                                },
                                fail: function() {
                                    a(null);
                                }
                            });
                        }).catch(function(t) {});
                    }
                }
            };
            n.default = r;
        }).call(this, e("df3c").default);
    },
    a24a: function(t, n, e) {
        "use strict";
        var a = e("edf9");
        e.n(a).a;
    },
    a521: function(t, n, e) {
        "use strict";
        e.d(n, "b", function() {
            return a;
        }), e.d(n, "c", function() {
            return o;
        }), e.d(n, "a", function() {});
        var a = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    de3a: function(t, n, e) {
        "use strict";
        e.r(n);
        var a = e("a521"), o = e("4291");
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(c);
        e("a24a");
        var r = e("828b"), i = Object(r.a)(o.default, a.b, a.c, !1, null, "72d26d6d", null, !1, a.a, void 0);
        n.default = i.exports;
    },
    edf9: function(t, n, e) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/compress-create-component", {
    "components/compress-create-component": function(t, n, e) {
        e("df3c").createComponent(e("de3a"));
    }
}, [ [ "components/compress-create-component" ] ] ]);