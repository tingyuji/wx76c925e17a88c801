$gwx_XC_11=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_11 || [];
function gz$gwx_XC_11_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_11_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'imageV data-v-c71235aa'])
Z([3,'con data-v-c71235aa'])
Z([3,'area data-v-c71235aa'])
Z([[2,'+'],[[2,'+'],[1,'height:'],[[7],[3,'areaHeight']]],[1,';']])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'imageList']])
Z([3,'id'])
Z([3,'data-v-c71235aa'])
Z([3,'__e'])
Z(z[9])
Z(z[9])
Z(z[9])
Z(z[9])
Z([3,'view data-v-c71235aa'])
Z([1,40])
Z([[4],[[5],[[5],[[5],[[5],[[5],[[4],[[5],[[5],[1,'change']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'onChange']],[[4],[[5],[[5],[1,'$event']],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'imageList']],[1,'id']],[[6],[[7],[3,'item']],[3,'id']]]]]]]]]]]]]]],[[4],[[5],[[5],[1,'touchstart']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'touchstart']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'imageList']],[1,'id']],[[6],[[7],[3,'item']],[3,'id']]]]]]]]]]]]]]],[[4],[[5],[[5],[1,'mousedown']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'touchstart']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'imageList']],[1,'id']],[[6],[[7],[3,'item']],[3,'id']]]]]]]]]]]]]]],[[4],[[5],[[5],[1,'touchend']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'touchend']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'imageList']],[1,'id']],[[6],[[7],[3,'item']],[3,'id']]]]]]]]]]]]]]],[[4],[[5],[[5],[1,'mouseup']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'touchend']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'imageList']],[1,'id']],[[6],[[7],[3,'item']],[3,'id']]]]]]]]]]]]]]]])
Z([3,'all'])
Z([[6],[[7],[3,'item']],[3,'disable']])
Z([[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[1,'width:'],[[2,'+'],[[7],[3,'viewWidth']],[1,'px']]],[1,';']],[[2,'+'],[[2,'+'],[1,'height:'],[[2,'+'],[[7],[3,'viewWidth']],[1,'px']]],[1,';']]],[[2,'+'],[[2,'+'],[1,'z-index:'],[[6],[[7],[3,'item']],[3,'zIndex']]],[1,';']]],[[2,'+'],[[2,'+'],[1,'opacity:'],[[6],[[7],[3,'item']],[3,'opacity']]],[1,';']]])
Z([[6],[[7],[3,'item']],[3,'x']])
Z([[6],[[7],[3,'item']],[3,'y']])
Z([3,'area-con data-v-c71235aa'])
Z([[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[1,'width:'],[[7],[3,'childWidth']]],[1,';']],[[2,'+'],[[2,'+'],[1,'height:'],[[7],[3,'childWidth']]],[1,';']]],[[2,'+'],[[2,'+'],[1,'transform:'],[[2,'+'],[[2,'+'],[1,'scale('],[[6],[[7],[3,'item']],[3,'scale']]],[1,')']]],[1,';']]])
Z([[2,'&&'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,1]],[[2,'!='],[[6],[[7],[3,'item']],[3,'load']],[1,'err']]])
Z(z[9])
Z([3,'pre-image data-v-c71235aa'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'lookImg']],[[4],[[5],[[5],[1,'$0']],[[7],[3,'index']]]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'imageList']],[1,'id']],[[6],[[7],[3,'item']],[3,'id']]]]]]]]]]]]]]]])
Z([3,'aspectFill'])
Z([[2,'+'],[[6],[[7],[3,'item']],[3,'image']],[1,'?x-oss-process\x3dimage/resize,m_fixed,w_220/quality,q_80/sharpen,100']])
Z([[2,'&&'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,2]],[[2,'!='],[[6],[[7],[3,'item']],[3,'load']],[1,'err']]])
Z(z[9])
Z(z[26])
Z(z[27])
Z(z[28])
Z([[2,'+'],[[6],[[7],[3,'item']],[3,'image']],[1,'?x-oss-process\x3dvideo/snapshot,t_1000,f_jpg,w_440,m_fast']])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'load']],[1,'err']])
Z(z[26])
Z(z[28])
Z([[2,'+'],[[7],[3,'ossMoUrl']],[1,'img_picture_failure.png']])
Z([[2,'&&'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,2]],[[2,'==='],[[6],[[7],[3,'item']],[3,'load']],[1,true]]])
Z(z[9])
Z([3,'play-box flex-center data-v-c71235aa'])
Z(z[27])
Z([3,'cuIcon-playfill data-v-c71235aa'])
Z([[2,'==='],[[6],[[7],[3,'item']],[3,'load']],[1,false]])
Z([[4],[[5],[[5],[[5],[1,'speed-box']],[1,'data-v-c71235aa']],[[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,2]],[1,'a'],[1,'']]]])
Z([3,'speed data-v-c71235aa'])
Z([a,[[2,'+'],[[6],[[7],[3,'item']],[3,'speed']],[1,'%']]])
Z(z[9])
Z(z[9])
Z(z[9])
Z(z[9])
Z([3,'del-con data-v-c71235aa'])
Z([[4],[[5],[[5],[[5],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'delImage']],[[4],[[5],[[5],[1,'$0']],[[7],[3,'index']]]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'imageList']],[1,'id']],[[6],[[7],[3,'item']],[3,'id']]]]]]]]]]]]]]],[[4],[[5],[[5],[1,'touchend']],[[4],[[5],[[4],[[5],[1,'nothing']]]]]]]],[[4],[[5],[[5],[1,'mousedown']],[[4],[[5],[[4],[[5],[1,'nothing']]]]]]]],[[4],[[5],[[5],[1,'mouseup']],[[4],[[5],[[4],[[5],[1,'nothing']]]]]]]]])
Z([3,'del-wrap data-v-c71235aa'])
Z([3,'del-image data-v-c71235aa'])
Z(z[28])
Z([[2,'+'],[[7],[3,'ossMoUrl']],[1,'ic_delete_1.png']])
Z([[2,'<'],[[6],[[7],[3,'$root']],[3,'g0']],[[7],[3,'number']]])
Z(z[9])
Z([3,'add data-v-c71235aa'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'addImages']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[1,'top:'],[[6],[[7],[3,'add']],[3,'y']]],[1,';']],[[2,'+'],[[2,'+'],[1,'left:'],[[6],[[7],[3,'add']],[3,'x']]],[1,';']]],[[2,'+'],[[2,'+'],[1,'width:'],[[2,'+'],[[7],[3,'viewWidth']],[1,'px']]],[1,';']]],[[2,'+'],[[2,'+'],[1,'height:'],[[2,'+'],[[7],[3,'viewWidth']],[1,'px']]],[1,';']]])
Z([3,'add-wrap flex-column flex-center data-v-c71235aa'])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'width:'],[[7],[3,'childWidth']]],[1,';']],[[2,'+'],[[2,'+'],[1,'height:'],[[7],[3,'childWidth']]],[1,';']]])
Z([3,'cuIcon-camerafill data-v-c71235aa'])
Z(z[8])
Z([3,'图片/视频'])
Z([3,'__l'])
Z([3,'data-v-c71235aa vue-ref'])
Z([3,'compress'])
Z([3,'3ceefc5a-1'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_11_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_11=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_11=true;
var x=['./components/multipleImg/multipleImg.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_11_1()
var o8D=_n('view')
_rz(z,o8D,'class',0,e,s,gg)
var x9D=_n('view')
_rz(z,x9D,'class',1,e,s,gg)
var o0D=_mz(z,'movable-area',['class',2,'style',1],[],e,s,gg)
var cBE=_v()
_(o0D,cBE)
var hCE=function(cEE,oDE,oFE,gg){
var aHE=_mz(z,'movable-view',['bindchange',9,'bindmousedown',1,'bindmouseup',2,'bindtouchend',3,'bindtouchstart',4,'class',5,'damping',6,'data-event-opts',7,'direction',8,'disabled',9,'style',10,'x',11,'y',12],[],cEE,oDE,gg)
var tIE=_mz(z,'view',['class',22,'style',1],[],cEE,oDE,gg)
var eJE=_v()
_(tIE,eJE)
if(_oz(z,24,cEE,oDE,gg)){eJE.wxVkey=1
var fOE=_mz(z,'image',['bindtap',25,'class',1,'data-event-opts',2,'mode',3,'src',4],[],cEE,oDE,gg)
_(eJE,fOE)
}
var bKE=_v()
_(tIE,bKE)
if(_oz(z,30,cEE,oDE,gg)){bKE.wxVkey=1
var cPE=_mz(z,'image',['catchtap',31,'class',1,'data-event-opts',2,'mode',3,'src',4],[],cEE,oDE,gg)
_(bKE,cPE)
}
var oLE=_v()
_(tIE,oLE)
if(_oz(z,36,cEE,oDE,gg)){oLE.wxVkey=1
var hQE=_mz(z,'image',['class',37,'mode',1,'src',2],[],cEE,oDE,gg)
_(oLE,hQE)
}
var xME=_v()
_(tIE,xME)
if(_oz(z,40,cEE,oDE,gg)){xME.wxVkey=1
var oRE=_mz(z,'view',['bindtap',41,'class',1,'data-event-opts',2],[],cEE,oDE,gg)
var cSE=_n('text')
_rz(z,cSE,'class',44,cEE,oDE,gg)
_(oRE,cSE)
_(xME,oRE)
}
var oNE=_v()
_(tIE,oNE)
if(_oz(z,45,cEE,oDE,gg)){oNE.wxVkey=1
var oTE=_n('view')
_rz(z,oTE,'class',46,cEE,oDE,gg)
var lUE=_n('view')
_rz(z,lUE,'class',47,cEE,oDE,gg)
var aVE=_oz(z,48,cEE,oDE,gg)
_(lUE,aVE)
_(oTE,lUE)
_(oNE,oTE)
}
var tWE=_mz(z,'view',['bindtap',49,'catchmousedown',1,'catchmouseup',2,'catchtouchend',3,'class',4,'data-event-opts',5],[],cEE,oDE,gg)
var eXE=_n('view')
_rz(z,eXE,'class',55,cEE,oDE,gg)
var bYE=_mz(z,'image',['class',56,'mode',1,'src',2],[],cEE,oDE,gg)
_(eXE,bYE)
_(tWE,eXE)
_(tIE,tWE)
eJE.wxXCkey=1
bKE.wxXCkey=1
oLE.wxXCkey=1
xME.wxXCkey=1
oNE.wxXCkey=1
_(aHE,tIE)
_(oFE,aHE)
return oFE
}
cBE.wxXCkey=2
_2z(z,6,hCE,e,s,gg,cBE,'item','index','id')
var fAE=_v()
_(o0D,fAE)
if(_oz(z,59,e,s,gg)){fAE.wxVkey=1
var oZE=_mz(z,'view',['bindtap',60,'class',1,'data-event-opts',2,'style',3],[],e,s,gg)
var x1E=_mz(z,'view',['class',64,'style',1],[],e,s,gg)
var o2E=_n('text')
_rz(z,o2E,'class',66,e,s,gg)
_(x1E,o2E)
var f3E=_n('text')
_rz(z,f3E,'class',67,e,s,gg)
var c4E=_oz(z,68,e,s,gg)
_(f3E,c4E)
_(x1E,f3E)
_(oZE,x1E)
_(fAE,oZE)
}
fAE.wxXCkey=1
_(x9D,o0D)
_(o8D,x9D)
var h5E=_mz(z,'compress',['bind:__l',69,'class',1,'data-ref',2,'vueId',3],[],e,s,gg)
_(o8D,h5E)
_(r,o8D)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_11";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_11();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/multipleImg/multipleImg.wxml'] = [$gwx_XC_11, './components/multipleImg/multipleImg.wxml'];else __wxAppCode__['components/multipleImg/multipleImg.wxml'] = $gwx_XC_11( './components/multipleImg/multipleImg.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/multipleImg/multipleImg.wxss'] = setCssToHead([".",[1],"con.",[1],"data-v-c71235aa{min-height:110px}\n.",[1],"con .",[1],"area.",[1],"data-v-c71235aa{width:100%}\n.",[1],"con .",[1],"area .",[1],"view.",[1],"data-v-c71235aa{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-justify-content:center;justify-content:center}\n.",[1],"con .",[1],"area .",[1],"view .",[1],"area-con.",[1],"data-v-c71235aa{border-radius:",[0,12],";position:relative}\n.",[1],"con .",[1],"area .",[1],"view .",[1],"area-con .",[1],"pre-image.",[1],"data-v-c71235aa{border-radius:",[0,12],";height:100%;width:100%}\n.",[1],"con .",[1],"area .",[1],"view .",[1],"area-con .",[1],"del-con.",[1],"data-v-c71235aa{padding:0 0 ",[0,20]," ",[0,20],";position:absolute;right:",[0,0],";top:",[0,0],"}\n.",[1],"con .",[1],"area .",[1],"view .",[1],"area-con .",[1],"del-con .",[1],"del-wrap.",[1],"data-v-c71235aa{-webkit-align-items:center;align-items:center;border-radius:0 0 0 ",[0,10],";display:-webkit-flex;display:flex;height:",[0,36],";-webkit-justify-content:center;justify-content:center;width:",[0,36],";z-index:8}\n.",[1],"con .",[1],"area .",[1],"view .",[1],"area-con .",[1],"del-con .",[1],"del-wrap .",[1],"del-image.",[1],"data-v-c71235aa{height:",[0,36],";width:",[0,36],"}\n.",[1],"con .",[1],"area .",[1],"view .",[1],"area-con .",[1],"play-box.",[1],"data-v-c71235aa{height:",[0,80],";left:50%;position:absolute;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);width:",[0,80],";z-index:3}\n.",[1],"con .",[1],"area .",[1],"view .",[1],"area-con .",[1],"play-box .",[1],"cuIcon-playfill.",[1],"data-v-c71235aa{color:#fff;font-size:",[0,60],"}\n.",[1],"con .",[1],"area .",[1],"view .",[1],"area-con .",[1],"speed-box.",[1],"data-v-c71235aa{-webkit-align-items:center;align-items:center;background-color:rgba(0,0,0,.5);border-radius:",[0,12],";display:-webkit-flex;display:flex;height:100%;-webkit-justify-content:center;justify-content:center;left:0;position:absolute;top:0;width:100%}\n.",[1],"con .",[1],"area .",[1],"view .",[1],"area-con .",[1],"speed-box .",[1],"speed.",[1],"data-v-c71235aa{color:#fff;font-size:",[0,32],";font-weight:400}\n.",[1],"con .",[1],"area .",[1],"view .",[1],"area-con .",[1],"speed-box.",[1],"a.",[1],"data-v-c71235aa{background-color:#000}\n.",[1],"con .",[1],"area .",[1],"add.",[1],"data-v-c71235aa{-webkit-align-items:center;align-items:center;border-radius:",[0,12],";display:-webkit-flex;display:flex;-webkit-justify-content:center;justify-content:center;position:absolute}\n.",[1],"con .",[1],"area .",[1],"add .",[1],"add-wrap.",[1],"data-v-c71235aa{background-color:#f7f7f7;border-radius:",[0,12],";color:#999;font-size:",[0,24],";position:relative}\n.",[1],"con .",[1],"area .",[1],"add .",[1],"add-wrap .",[1],"cuIcon-camerafill.",[1],"data-v-c71235aa{color:#797979;font-size:",[0,50],";margin-bottom:",[0,16],"}\n.",[1],"uploadType.",[1],"data-v-c71235aa{display:-webkit-flex;display:flex;padding:",[0,20]," ",[0,40]," ",[0,50],";width:100%}\n.",[1],"uploadType .",[1],"pImg.",[1],"data-v-c71235aa{height:",[0,34],";margin-right:",[0,60],";width:",[0,40],"}\n",],undefined,{path:"./components/multipleImg/multipleImg.wxss"});
}