(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/multipleImg/multipleImg" ], {
    "4b67": function(t, e, i) {
        "use strict";
        var n = i("535f");
        i.n(n).a;
    },
    "535f": function(t, e, i) {},
    "644b": function(t, e, i) {
        "use strict";
        i.r(e);
        var n = i("d4f0"), a = i("7627");
        for (var s in a) [ "default" ].indexOf(s) < 0 && function(t) {
            i.d(e, t, function() {
                return a[t];
            });
        }(s);
        i("4b67");
        var o = i("828b"), r = Object(o.a)(a.default, n.b, n.c, !1, null, "c71235aa", null, !1, n.a, void 0);
        e.default = r.exports;
    },
    7627: function(t, e, i) {
        "use strict";
        i.r(e);
        var n = i("91d4"), a = i.n(n);
        for (var s in n) [ "default" ].indexOf(s) < 0 && function(t) {
            i.d(e, t, function() {
                return n[t];
            });
        }(s);
        e.default = a.a;
    },
    "91d4": function(t, e, i) {
        "use strict";
        (function(t) {
            var n = i("47a9");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a = n(i("7eb4")), s = n(i("ee10")), o = i("d6b4"), r = i("505c");
            function l(t, e) {
                var i = "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                if (!i) {
                    if (Array.isArray(t) || (i = function(t, e) {
                        if (t) {
                            if ("string" == typeof t) return c(t, e);
                            var i = Object.prototype.toString.call(t).slice(8, -1);
                            return "Object" === i && t.constructor && (i = t.constructor.name), "Map" === i || "Set" === i ? Array.from(t) : "Arguments" === i || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i) ? c(t, e) : void 0;
                        }
                    }(t)) || e && t && "number" == typeof t.length) {
                        i && (t = i);
                        var n = 0, a = function() {};
                        return {
                            s: a,
                            n: function() {
                                return n >= t.length ? {
                                    done: !0
                                } : {
                                    done: !1,
                                    value: t[n++]
                                };
                            },
                            e: function(t) {
                                throw t;
                            },
                            f: a
                        };
                    }
                    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }
                var s, o = !0, r = !1;
                return {
                    s: function() {
                        i = i.call(t);
                    },
                    n: function() {
                        var t = i.next();
                        return o = t.done, t;
                    },
                    e: function(t) {
                        r = !0, s = t;
                    },
                    f: function() {
                        try {
                            o || null == i.return || i.return();
                        } finally {
                            if (r) throw s;
                        }
                    }
                };
            }
            function c(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var i = 0, n = new Array(e); i < e; i++) n[i] = t[i];
                return n;
            }
            n(i("ed82"));
            var u = {
                components: {
                    compress: function() {
                        i.e("components/compress").then(function() {
                            return resolve(i("de3a"));
                        }.bind(null, i)).catch(i.oe);
                    }
                },
                data: function() {
                    return {
                        imageList: [],
                        width: 0,
                        add: {
                            x: 0,
                            y: 0
                        },
                        colsValue: 0,
                        viewWidth: 0,
                        tempItem: null,
                        timer: null,
                        changeStatus: !0,
                        preStatus: !0
                    };
                },
                props: {
                    list: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    },
                    number: {
                        type: Number,
                        default: 9
                    },
                    imageWidth: {
                        type: Number,
                        default: 220
                    },
                    cols: {
                        type: Number,
                        default: 0
                    },
                    padding: {
                        type: Number,
                        default: 10
                    },
                    scale: {
                        type: Number,
                        default: 1.1
                    },
                    opacity: {
                        type: Number,
                        default: .7
                    },
                    itemList: {
                        type: Array,
                        default: function() {
                            return [ "图片", "视频" ];
                        }
                    },
                    col: {
                        type: Number,
                        default: 0
                    },
                    uploadModel: {
                        type: null | String,
                        default: ""
                    }
                },
                computed: {
                    areaHeight: function() {
                        return this.imageList.length < this.number ? Math.ceil((this.imageList.length + 1) / this.colsValue) * this.viewWidth + "px" : Math.ceil(this.imageList.length / this.colsValue) * this.viewWidth + "px";
                    },
                    childWidth: function() {
                        return this.viewWidth - 2 * this.rpx2px(this.padding) + "px";
                    }
                },
                created: function() {
                    this.width = t.getSystemInfoSync().windowWidth, this.viewWidth = this.rpx2px(this.imageWidth);
                },
                mounted: function() {
                    var e = this, i = t.createSelectorQuery().in(this);
                    i.select(".area").boundingClientRect(function(t) {
                        if (t) {
                            e.colsValue = Math.floor(t.width / e.viewWidth), e.cols > 0 && (e.colsValue = e.cols, 
                            e.viewWidth = t.width / e.cols), e.col && (e.colsValue = e.col);
                            var i, n = l(e.list);
                            try {
                                for (n.s(); !(i = n.n()).done; ) {
                                    var a = i.value, s = "", o = (s = a === Object(a) ? a.image : a).split("."), r = o[o.length - 1];
                                    [ "png", "jpg", "jpeg", "bmp", "gif" ].indexOf(r) > -1 ? e.addProperties(s, 1, !0, 1, 100) : e.addProperties(s, 2, !0, 1, 100);
                                }
                            } catch (t) {
                                n.e(t);
                            } finally {
                                n.f();
                            }
                        }
                    }), i.exec();
                },
                methods: {
                    lookImg: function(e, i) {
                        if (2 == e.type) t.navigateTo({
                            url: "/pages/common/playVideo?src=" + e.image
                        }); else {
                            var n = [];
                            this.imageList.filter(function(t) {
                                n.push(t.image);
                            }), t.previewImage({
                                urls: n,
                                current: i
                            });
                        }
                    },
                    onChange: function(t, e) {
                        var i = this;
                        if (e && (e.oldX = t.detail.x, e.oldY = t.detail.y, "touch" === t.detail.source)) {
                            e.moveEnd && (e.offset = Math.sqrt(Math.pow(e.oldX - e.absX * this.viewWidth, 2) + Math.pow(e.oldY - e.absY * this.viewWidth, 2)));
                            var n = Math.floor((t.detail.x + this.viewWidth / 2) / this.viewWidth);
                            if (n >= this.colsValue) return;
                            var a = Math.floor((t.detail.y + this.viewWidth / 2) / this.viewWidth), s = this.colsValue * a + n;
                            if (e.index != s && s < this.imageList.length) {
                                this.changeStatus = !1;
                                var o, r = l(this.imageList);
                                try {
                                    var c = function() {
                                        var t = o.value;
                                        e.index > s && t.index >= s && t.index < e.index ? i.change(t, 1) : e.index < s && t.index <= s && t.index > e.index ? i.change(t, -1) : t.id != e.id && (t.offset = 0, 
                                        t.x = t.oldX, t.y = t.oldY, setTimeout(function() {
                                            i.$nextTick(function() {
                                                t.x = t.absX * i.viewWidth, t.y = t.absY * i.viewWidth;
                                            });
                                        }, 0));
                                    };
                                    for (r.s(); !(o = r.n()).done; ) c();
                                } catch (t) {
                                    r.e(t);
                                } finally {
                                    r.f();
                                }
                                e.index = s, e.absX = n, e.absY = a, this.sortList();
                            }
                        }
                    },
                    change: function(t, e) {
                        var i = this;
                        t.index += e, t.offset = 0, t.x = t.oldX, t.y = t.oldY, t.absX = t.index % this.colsValue, 
                        t.absY = Math.floor(t.index / this.colsValue), setTimeout(function() {
                            i.$nextTick(function() {
                                t.x = t.absX * i.viewWidth, t.y = t.absY * i.viewWidth;
                            });
                        }, 0);
                    },
                    touchstart: function(t) {
                        var e = this;
                        this.imageList.forEach(function(t) {
                            t.zIndex = t.index + 9;
                        }), t.zIndex = 99, t.moveEnd = !0, this.tempItem = t, this.timer = setTimeout(function() {
                            t.scale = e.scale, t.opacity = e.opacity, clearTimeout(e.timer), e.timer = null;
                        }, 200);
                    },
                    touchend: function(t) {
                        var e = this;
                        t.scale = 1, t.opacity = 1, t.x = t.oldX, t.y = t.oldY, t.offset = 0, t.moveEnd = !1, 
                        setTimeout(function() {
                            e.$nextTick(function() {
                                t.x = t.absX * e.viewWidth, t.y = t.absY * e.viewWidth, e.tempItem = null, e.changeStatus = !0, 
                                e.$emit("moveImage", JSON.stringify(e.imageList));
                            });
                        }, 0);
                    },
                    addImages: function() {
                        var e = this;
                        return (0, s.default)(a.default.mark(function i() {
                            var n;
                            return a.default.wrap(function(i) {
                                for (;;) switch (i.prev = i.next) {
                                  case 0:
                                    n = e, t.showActionSheet({
                                        itemList: e.itemList,
                                        success: function(t) {
                                            0 == t.tapIndex ? n.chooseImage() : n.chooseVideo();
                                        }
                                    });

                                  case 2:
                                  case "end":
                                    return i.stop();
                                }
                            }, i);
                        }))();
                    },
                    chooseImage: function() {
                        var e = this, i = this.number - this.imageList.length, n = this.imageList.length;
                        t.chooseImage({
                            count: i,
                            success: function(t) {
                                for (var a = i <= t.tempFilePaths.length ? i : t.tempFilePaths.length, s = [], o = 0; o < a; o++) {
                                    e.addProperties(t.tempFilePaths[o], 1);
                                    var r = {
                                        src: t.tempFilePaths[o],
                                        image: "",
                                        type: 1,
                                        load: !1,
                                        speed: 0
                                    };
                                    s.push(r);
                                }
                                e.asynUpload(1, s, n, "image");
                            }
                        });
                    },
                    chooseVideo: function() {
                        var e = this, i = this.imageList.length;
                        t.chooseVideo({
                            success: function(t) {
                                var n = {
                                    src: t.tempFilePath,
                                    image: "",
                                    type: 2,
                                    load: !1,
                                    speed: 0
                                };
                                e.addProperties(t.tempFilePaths, 2), e.asynUpload(2, [ n ], i, "video");
                            }
                        });
                    },
                    asynUpload: function(e, i, n, l) {
                        var c = this;
                        return (0, s.default)(a.default.mark(function s() {
                            var u, d, h, f;
                            return a.default.wrap(function(s) {
                                for (;;) switch (s.prev = s.next) {
                                  case 0:
                                    u = c, d = c.$refs.compress, h = a.default.mark(function s(c) {
                                        var h;
                                        return a.default.wrap(function(a) {
                                            for (;;) switch (a.prev = a.next) {
                                              case 0:
                                                if (h = i[c], 1 != e) {
                                                    a.next = 5;
                                                    break;
                                                }
                                                return a.next = 4, d.compress({
                                                    src: h.src,
                                                    fileType: "jpg",
                                                    maxSize: 3e3
                                                });

                                              case 4:
                                                h.src = a.sent;

                                              case 5:
                                                t.uploadFile({
                                                    url: r.config.host + "/api/v1/upload",
                                                    filePath: h.src,
                                                    name: "file_data",
                                                    header: {
                                                        Authorization: "Bearer " + t.getStorageSync("token"),
                                                        "cli-os": "wechat",
                                                        "cli-version": "1.0.0"
                                                    },
                                                    formData: (0, o.apiRequestSign)({
                                                        file_type: l,
                                                        upload_model: u.uploadModel
                                                    }, {
                                                        app_id: "cd4a1bcdfcc4ea75f78d900b67fe29bd",
                                                        app_key: "deb94c11ebac02471dba55050cb0638bbb6d0a92dd4f378fb09350492688e260"
                                                    }),
                                                    success: function(t) {
                                                        u.imageList[c + n].image = JSON.parse(t.data).data.url, setTimeout(function() {
                                                            u.imageList[c + n].speed = 100, u.imageList[c + n].load = !0, u.$emit("upload", JSON.stringify(u.imageList));
                                                        }, 500);
                                                    },
                                                    complete: function(e) {
                                                        u.uploading = !1, e.statusCode && 200 == e.statusCode || (e.statusCode && 413 == e.statusCode ? (u.load = "err", 
                                                        t.showToast({
                                                            title: "文件过大，请重新上传",
                                                            icon: "none"
                                                        })) : (u.load = "err", t.showToast({
                                                            title: "上传失败，请检查网络",
                                                            icon: "none"
                                                        })));
                                                    }
                                                }).onProgressUpdate(function(t) {
                                                    u.imageList[c + n].speed = t.progress, 100 == t.progress && (u.imageList[c + n].speed = 99);
                                                });

                                              case 7:
                                              case "end":
                                                return a.stop();
                                            }
                                        }, s);
                                    }), f = 0;

                                  case 4:
                                    if (!(f < i.length)) {
                                        s.next = 9;
                                        break;
                                    }
                                    return s.delegateYield(h(f), "t0", 6);

                                  case 6:
                                    f++, s.next = 4;
                                    break;

                                  case 9:
                                  case "end":
                                    return s.stop();
                                }
                            }, s);
                        }))();
                    },
                    delImage: function(t, e) {
                        var i = this;
                        this.imageList.splice(e, 1);
                        var n, a = l(this.imageList);
                        try {
                            var s = function() {
                                var e = n.value;
                                e.index > t.index && (e.index -= 1, e.x = e.oldX, e.y = e.oldY, e.absX = e.index % i.colsValue, 
                                e.absY = Math.floor(e.index / i.colsValue), i.$nextTick(function() {
                                    e.x = e.absX * i.viewWidth, e.y = e.absY * i.viewWidth;
                                }));
                            };
                            for (a.s(); !(n = a.n()).done; ) s();
                        } catch (t) {
                            a.e(t);
                        } finally {
                            a.f();
                        }
                        this.add.x = this.imageList.length % this.colsValue * this.viewWidth + "px", this.add.y = Math.floor(this.imageList.length / this.colsValue) * this.viewWidth + "px", 
                        this.sortList();
                    },
                    sortList: function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, e = this.imageList.slice();
                        e.sort(function(t, e) {
                            return t.index - e.index;
                        });
                        for (var i = 0; i < e.length; i++) e[i] = e[i].image;
                        this.$emit("update:list", e), this.$emit("moveImage", JSON.stringify(this.imageList), t);
                    },
                    addProperties: function(t, e) {
                        var i = arguments.length > 2 && void 0 !== arguments[2] && arguments[2], n = arguments.length > 3 ? arguments[3] : void 0, a = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0, s = this.imageList.length % this.colsValue, o = Math.floor(this.imageList.length / this.colsValue), r = s * this.viewWidth, l = o * this.viewWidth;
                        this.imageList.push({
                            image: t,
                            x: r,
                            y: l,
                            oldX: r,
                            oldY: l,
                            absX: s,
                            absY: o,
                            scale: 1,
                            zIndex: 9,
                            opacity: 1,
                            index: this.imageList.length,
                            id: this.guid(),
                            disable: !1,
                            offset: 0,
                            moveEnd: !1,
                            type: e,
                            speed: a,
                            load: i
                        }), this.add.x = this.imageList.length % this.colsValue * this.viewWidth + "px", 
                        this.add.y = Math.floor(this.imageList.length / this.colsValue) * this.viewWidth + "px", 
                        this.sortList(n);
                    },
                    nothing: function() {},
                    rpx2px: function(t) {
                        return this.width * t / 750;
                    },
                    guid: function() {
                        function t() {
                            return (65536 * (1 + Math.random()) | 0).toString(16).substring(1);
                        }
                        return t() + t() + "-" + t() + "-" + t() + "-" + t() + "-" + t() + t() + t();
                    }
                }
            };
            e.default = u;
        }).call(this, i("df3c").default);
    },
    d4f0: function(t, e, i) {
        "use strict";
        i.d(e, "b", function() {
            return n;
        }), i.d(e, "c", function() {
            return a;
        }), i.d(e, "a", function() {});
        var n = function() {
            this.$createElement;
            var t = (this._self._c, this.imageList.length);
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: t
                }
            });
        }, a = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/multipleImg/multipleImg-create-component", {
    "components/multipleImg/multipleImg-create-component": function(t, e, i) {
        i("df3c").createComponent(i("644b"));
    }
}, [ [ "components/multipleImg/multipleImg-create-component" ] ] ]);