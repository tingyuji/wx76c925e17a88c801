(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/uni-countdown/uni-countdown" ], {
    "17bc": function(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return o;
        }), n.d(e, "a", function() {});
        var i = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    6655: function(t, e, n) {
        "use strict";
        n.r(e);
        var i = n("17bc"), o = n("78d3");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(a);
        n("ca39");
        var s = n("828b"), u = Object(s.a)(o.default, i.b, i.c, !1, null, "35cac238", null, !1, i.a, void 0);
        e.default = u.exports;
    },
    "78d3": function(t, e, n) {
        "use strict";
        n.r(e);
        var i = n("adbd"), o = n.n(i);
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(a);
        e.default = o.a;
    },
    adbd: function(t, e, n) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var i = {
            name: "UniCountdown",
            props: {
                showDay: {
                    type: Boolean,
                    default: !0
                },
                showColon: {
                    type: Boolean,
                    default: !0
                },
                backgroundColor: {
                    type: String,
                    default: "#FFFFFF"
                },
                borderColor: {
                    type: String,
                    default: "#000000"
                },
                color: {
                    type: String,
                    default: "#000000"
                },
                splitorColor: {
                    type: String,
                    default: "#000000"
                },
                day: {
                    type: Number,
                    default: 0
                },
                hour: {
                    type: Number,
                    default: 0
                },
                minute: {
                    type: Number,
                    default: 0
                },
                second: {
                    type: Number,
                    default: 0
                },
                timestamp: {
                    type: Number,
                    default: 0
                },
                fontSize: {
                    type: String,
                    default: "22rpx"
                },
                fontWeight: {
                    type: String,
                    default: "400"
                },
                boxWidth: {
                    type: String,
                    default: "36rpx"
                },
                boxHeight: {
                    type: String,
                    default: "36rpx"
                },
                noInter: {
                    type: Boolean,
                    default: !1
                }
            },
            data: function() {
                return {
                    timer: null,
                    syncFlag: !1,
                    d: "00",
                    h: "00",
                    i: "00",
                    s: "00",
                    leftTime: 0,
                    seconds: 0
                };
            },
            watch: {
                day: function(t) {
                    this.changeFlag();
                },
                hour: function(t) {
                    this.changeFlag();
                },
                minute: function(t) {
                    this.changeFlag();
                },
                second: function(t) {
                    this.changeFlag();
                },
                timestamp: function(t) {
                    this.getTimestamp();
                }
            },
            created: function(t) {
                this.getTimestamp();
            },
            beforeDestroy: function() {
                clearInterval(this.timer);
            },
            methods: {
                getTimestamp: function() {
                    this.timer && clearInterval(this.timer), this.timestamp - parseInt(new Date().getTime() / 1e3, 10) > 0 ? (this.syncFlag = !1, 
                    this.startData()) : this.$emit("errTime");
                },
                toSeconds: function(t, e, n, i, o) {
                    return t ? t - parseInt(new Date().getTime() / 1e3, 10) : 60 * e * 60 * 24 + 60 * n * 60 + 60 * i + o;
                },
                timeUp: function() {
                    clearInterval(this.timer), this.$emit("timeup");
                },
                countDown: function() {
                    var t = this.seconds, e = 0, n = 0, i = 0, o = 0;
                    t > 0 ? (e = Math.floor(t / 86400), n = Math.floor(t / 3600) - 24 * e, i = Math.floor(t / 60) - 24 * e * 60 - 60 * n, 
                    o = Math.floor(t) - 24 * e * 60 * 60 - 60 * n * 60 - 60 * i) : this.timeUp(), e < 10 && (e = "0" + e), 
                    n < 10 && (n = "0" + n), i < 10 && (i = "0" + i), o < 10 && (o = "0" + o), this.d = e, 
                    this.h = n, this.i = i, this.s = o;
                },
                startData: function() {
                    var t = this;
                    if (this.seconds = this.toSeconds(this.timestamp, this.day, this.hour, this.minute, this.second), 
                    this.seconds <= 0) return this.timer && clearInterval(this.timer), void this.$emit("timeup");
                    this.countDown(), this.timer = setInterval(function() {
                        t.seconds--, t.seconds < 0 ? t.timeUp() : t.countDown();
                    }, 1e3);
                },
                changeFlag: function() {
                    this.syncFlag || (this.seconds = this.toSeconds(this.timestamp, this.day, this.hour, this.minute, this.second), 
                    this.startData(), this.syncFlag = !0);
                }
            }
        };
        e.default = i;
    },
    ca39: function(t, e, n) {
        "use strict";
        var i = n("def2");
        n.n(i).a;
    },
    def2: function(t, e, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/uni-countdown/uni-countdown-create-component", {
    "components/uni-countdown/uni-countdown-create-component": function(t, e, n) {
        n("df3c").createComponent(n("6655"));
    }
}, [ [ "components/uni-countdown/uni-countdown-create-component" ] ] ]);