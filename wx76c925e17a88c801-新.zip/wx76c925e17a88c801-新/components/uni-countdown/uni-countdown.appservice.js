$gwx_XC_20=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_20 || [];
function gz$gwx_XC_20_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_20_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_20_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_20_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'uni-countdown data-v-35cac238'])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'font-size:'],[[7],[3,'fontSize']]],[1,';']],[[2,'+'],[[2,'+'],[1,'font-weight:'],[[7],[3,'fontWeight']]],[1,';']]])
Z([[7],[3,'showDay']])
Z(z[2])
Z([[2,'!'],[[7],[3,'showColon']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_20_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_20_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_20=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_20=true;
var x=['./components/uni-countdown/uni-countdown.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_20_1()
var oZD=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var c1D=_v()
_(oZD,c1D)
if(_oz(z,2,e,s,gg)){c1D.wxVkey=1
}
var o2D=_v()
_(oZD,o2D)
if(_oz(z,3,e,s,gg)){o2D.wxVkey=1
}
var l3D=_v()
_(oZD,l3D)
if(_oz(z,4,e,s,gg)){l3D.wxVkey=1
}
c1D.wxXCkey=1
o2D.wxXCkey=1
l3D.wxXCkey=1
_(r,oZD)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_20";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_20();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/uni-countdown/uni-countdown.wxml'] = [$gwx_XC_20, './components/uni-countdown/uni-countdown.wxml'];else __wxAppCode__['components/uni-countdown/uni-countdown.wxml'] = $gwx_XC_20( './components/uni-countdown/uni-countdown.wxml' );
	;__wxRoute = "components/uni-countdown/uni-countdown";__wxRouteBegin = true;__wxAppCurrentFile__="components/uni-countdown/uni-countdown.js";define("components/uni-countdown/uni-countdown.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["components/uni-countdown/uni-countdown"],{"17bc":function(t,e,n){"use strict";n.d(e,"b",(function(){return i})),n.d(e,"c",(function(){return o})),n.d(e,"a",(function(){}));var i=function(){this.$createElement;this._self._c},o=[]},6655:function(t,e,n){"use strict";n.r(e);var i=n("17bc"),o=n("78d3");for(var a in o)["default"].indexOf(a)<0&&function(t){n.d(e,t,(function(){return o[t]}))}(a);n("ca39");var s=n("828b"),u=Object(s.a)(o.default,i.b,i.c,!1,null,"35cac238",null,!1,i.a,void 0);e.default=u.exports},"78d3":function(t,e,n){"use strict";n.r(e);var i=n("adbd"),o=n.n(i);for(var a in i)["default"].indexOf(a)<0&&function(t){n.d(e,t,(function(){return i[t]}))}(a);e.default=o.a},adbd:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var i={name:"UniCountdown",props:{showDay:{type:Boolean,default:!0},showColon:{type:Boolean,default:!0},backgroundColor:{type:String,default:"#FFFFFF"},borderColor:{type:String,default:"#000000"},color:{type:String,default:"#000000"},splitorColor:{type:String,default:"#000000"},day:{type:Number,default:0},hour:{type:Number,default:0},minute:{type:Number,default:0},second:{type:Number,default:0},timestamp:{type:Number,default:0},fontSize:{type:String,default:"22rpx"},fontWeight:{type:String,default:"400"},boxWidth:{type:String,default:"36rpx"},boxHeight:{type:String,default:"36rpx"},noInter:{type:Boolean,default:!1}},data:function(){return{timer:null,syncFlag:!1,d:"00",h:"00",i:"00",s:"00",leftTime:0,seconds:0}},watch:{day:function(t){this.changeFlag()},hour:function(t){this.changeFlag()},minute:function(t){this.changeFlag()},second:function(t){this.changeFlag()},timestamp:function(t){this.getTimestamp()}},created:function(t){this.getTimestamp()},beforeDestroy:function(){clearInterval(this.timer)},methods:{getTimestamp:function(){this.timer&&clearInterval(this.timer),this.timestamp-parseInt((new Date).getTime()/1e3,10)>0?(this.syncFlag=!1,this.startData()):this.$emit("errTime")},toSeconds:function(t,e,n,i,o){return t?t-parseInt((new Date).getTime()/1e3,10):60*e*60*24+60*n*60+60*i+o},timeUp:function(){clearInterval(this.timer),this.$emit("timeup")},countDown:function(){var t=this.seconds,e=0,n=0,i=0,o=0;t>0?(e=Math.floor(t/86400),n=Math.floor(t/3600)-24*e,i=Math.floor(t/60)-24*e*60-60*n,o=Math.floor(t)-24*e*60*60-60*n*60-60*i):this.timeUp(),e<10&&(e="0"+e),n<10&&(n="0"+n),i<10&&(i="0"+i),o<10&&(o="0"+o),this.d=e,this.h=n,this.i=i,this.s=o},startData:function(){var t=this;if(this.seconds=this.toSeconds(this.timestamp,this.day,this.hour,this.minute,this.second),this.seconds<=0)return this.timer&&clearInterval(this.timer),void this.$emit("timeup");this.countDown(),this.timer=setInterval((function(){t.seconds--,t.seconds<0?t.timeUp():t.countDown()}),1e3)},changeFlag:function(){this.syncFlag||(this.seconds=this.toSeconds(this.timestamp,this.day,this.hour,this.minute,this.second),this.startData(),this.syncFlag=!0)}}};e.default=i},ca39:function(t,e,n){"use strict";var i=n("def2");n.n(i).a},def2:function(t,e,n){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["components/uni-countdown/uni-countdown-create-component",{"components/uni-countdown/uni-countdown-create-component":function(t,e,n){n("df3c").createComponent(n("6655"))}},[["components/uni-countdown/uni-countdown-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'components/uni-countdown/uni-countdown.js'});require("components/uni-countdown/uni-countdown.js");