$gwx_XC_5=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_5 || [];
function gz$gwx_XC_5_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'content data-v-04b774d9'])
Z([3,'__e'])
Z(z[1])
Z([[4],[[5],[[5],[[5],[1,'mask-wrap']],[1,'data-v-04b774d9']],[[2,'?:'],[[7],[3,'open']],[1,'show'],[1,'']]]])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'touchmove']],[[4],[[5],[[4],[[5],[[5],[1,'']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'nextStep']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'aini-wrap flex-align-center data-v-04b774d9'])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'top:'],[[2,'+'],[[2,'-'],[[7],[3,'top']],[1,82]],[1,'px']]],[1,';']],[[2,'+'],[[2,'+'],[1,'left:'],[[2,'+'],[[2,'+'],[[2,'/'],[[7],[3,'width']],[1,2]],[[7],[3,'left']]],[1,'px']]],[1,';']]])
Z([3,'aini data-v-04b774d9'])
Z([[2,'!'],[[2,'=='],[[7],[3,'guideStar']],[1,1]]])
Z([3,'aspectFill'])
Z([[2,'+'],[[7],[3,'ossMoUrl']],[1,'good_iSpt.png']])
Z(z[7])
Z([[2,'!'],[[2,'=='],[[7],[3,'guideStar']],[1,2]]])
Z(z[9])
Z([[2,'+'],[[7],[3,'ossMoUrl']],[1,'great_iSpt.png']])
Z(z[7])
Z([[2,'!'],[[2,'=='],[[7],[3,'guideStar']],[1,3]]])
Z(z[9])
Z([[2,'+'],[[7],[3,'ossMoUrl']],[1,'excellent_iSpt.png']])
Z([[7],[3,'guideStar']])
Z([3,'guideStarLabel data-v-04b774d9'])
Z([a,[[2,'+'],[[2,'+'],[1,'摘'],[[7],[3,'guideStar']]],[1,'星']]])
Z([3,'inner data-v-04b774d9'])
Z([[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[1,'top:'],[[2,'+'],[[7],[3,'top']],[1,'px']]],[1,';']],[[2,'+'],[[2,'+'],[1,'left:'],[[2,'+'],[[7],[3,'left']],[1,'px']]],[1,';']]],[[2,'+'],[[2,'+'],[1,'width:'],[[2,'+'],[[7],[3,'width']],[1,'px']]],[1,';']]],[[2,'+'],[[2,'+'],[1,'height:'],[[2,'+'],[[7],[3,'height']],[1,'px']]],[1,';']]])
Z([3,'label-arrow data-v-04b774d9'])
Z([[2,'+'],[[7],[3,'ossMoUrl']],[1,'img_hand.png']])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'top:'],[[2,'+'],[[2,'+'],[[2,'+'],[[7],[3,'top']],[[2,'/'],[[7],[3,'height']],[1,2]]],[1,10]],[1,'px']]],[1,';']],[[2,'+'],[[2,'+'],[1,'left:'],[[2,'?:'],[[2,'=='],[[7],[3,'step']],[1,1]],[1,'40px'],[[2,'?:'],[[2,'=='],[[7],[3,'step']],[1,2]],[[2,'+'],[[2,'+'],[[2,'+'],[[7],[3,'left']],[[2,'/'],[[7],[3,'width']],[1,2]]],[1,33]],[1,'px']],[[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[1,'calc('],[[7],[3,'width']]],[1,'px - ']],[[2,'?:'],[[2,'<'],[[7],[3,'guideStar']],[1,2]],[1,176],[[2,'?:'],[[2,'=='],[[7],[3,'guideStar']],[1,2]],[1,106],[1,38]]]],[1,'rpx)']]]]],[1,';']]])
Z([3,'label flex-align-center data-v-04b774d9'])
Z([[2,'+'],[[2,'+'],[1,'top:'],[[2,'+'],[[2,'+'],[[2,'+'],[[7],[3,'top']],[[7],[3,'height']]],[1,40]],[1,'px']]],[1,';']])
Z([a,[[7],[3,'tips']]])
Z([3,'btn flex-center data-v-04b774d9'])
Z([[2,'+'],[[2,'+'],[1,'top:'],[[2,'+'],[[2,'+'],[[2,'+'],[[7],[3,'top']],[[7],[3,'height']]],[1,100]],[1,'px']]],[1,';']])
Z([3,'知道了'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_5=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_5=true;
var x=['./components/guideMask/guideMask.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_5_1()
var oXB=_n('view')
_rz(z,oXB,'class',0,e,s,gg)
var fYB=_mz(z,'view',['bindtap',1,'catchtouchmove',1,'class',2,'data-event-opts',3],[],e,s,gg)
var cZB=_mz(z,'view',['class',5,'style',1],[],e,s,gg)
var o2B=_mz(z,'image',['class',7,'hidden',1,'mode',2,'src',3],[],e,s,gg)
_(cZB,o2B)
var c3B=_mz(z,'image',['class',11,'hidden',1,'mode',2,'src',3],[],e,s,gg)
_(cZB,c3B)
var o4B=_mz(z,'image',['class',15,'hidden',1,'mode',2,'src',3],[],e,s,gg)
_(cZB,o4B)
var h1B=_v()
_(cZB,h1B)
if(_oz(z,19,e,s,gg)){h1B.wxVkey=1
var l5B=_n('view')
_rz(z,l5B,'class',20,e,s,gg)
var a6B=_oz(z,21,e,s,gg)
_(l5B,a6B)
_(h1B,l5B)
}
h1B.wxXCkey=1
_(fYB,cZB)
var t7B=_mz(z,'view',['class',22,'style',1],[],e,s,gg)
_(fYB,t7B)
var e8B=_mz(z,'image',['class',24,'src',1,'style',2],[],e,s,gg)
_(fYB,e8B)
var b9B=_mz(z,'view',['class',27,'style',1],[],e,s,gg)
var o0B=_oz(z,29,e,s,gg)
_(b9B,o0B)
_(fYB,b9B)
var xAC=_mz(z,'view',['class',30,'style',1],[],e,s,gg)
var oBC=_oz(z,32,e,s,gg)
_(xAC,oBC)
_(fYB,xAC)
_(oXB,fYB)
_(r,oXB)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_5";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_5();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/guideMask/guideMask.wxml'] = [$gwx_XC_5, './components/guideMask/guideMask.wxml'];else __wxAppCode__['components/guideMask/guideMask.wxml'] = $gwx_XC_5( './components/guideMask/guideMask.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/guideMask/guideMask.wxss'] = setCssToHead([".",[1],"mask-wrap.",[1],"data-v-04b774d9{height:100vh;left:0;opacity:0;position:fixed;top:0;transition:all .3s ease;visibility:hidden;width:100vw;z-index:9999}\n.",[1],"mask-wrap.",[1],"show.",[1],"data-v-04b774d9{opacity:1;visibility:visible}\n.",[1],"mask-wrap .",[1],"aini-wrap.",[1],"data-v-04b774d9{position:absolute;z-index:1}\n.",[1],"mask-wrap .",[1],"aini.",[1],"data-v-04b774d9{height:",[0,224],";width:",[0,240],"}\n.",[1],"mask-wrap .",[1],"guideStarLabel.",[1],"data-v-04b774d9{color:#ffea00;font-size:",[0,36],";font-weight:700;-webkit-transform:translateY(",[0,-4],");transform:translateY(",[0,-4],");width:",[0,120],"}\n.",[1],"mask-wrap .",[1],"inner.",[1],"data-v-04b774d9{background:transparent;border-radius:10px;box-shadow:0 0 0 1500px rgba(0,0,0,.6);box-sizing:initial;position:absolute}\n.",[1],"mask-wrap .",[1],"label-arrow.",[1],"data-v-04b774d9{-webkit-animation:aini1-data-v-04b774d9 1.2s linear infinite;animation:aini1-data-v-04b774d9 1.2s linear infinite;height:",[0,100],";position:absolute;width:",[0,88],"}\n@-webkit-keyframes aini1-data-v-04b774d9{0%{-webkit-transform:translate(0);transform:translate(0)}\n50%{-webkit-transform:translate(",[0,20],",",[0,20],");transform:translate(",[0,20],",",[0,20],")}\n100%{-webkit-transform:translate(0);transform:translate(0)}\n}@keyframes aini1-data-v-04b774d9{0%{-webkit-transform:translate(0);transform:translate(0)}\n50%{-webkit-transform:translate(",[0,20],",",[0,20],");transform:translate(",[0,20],",",[0,20],")}\n100%{-webkit-transform:translate(0);transform:translate(0)}\n}.",[1],"mask-wrap .",[1],"label.",[1],"data-v-04b774d9{background:linear-gradient(93deg,#fc81b9,#ff9aea);border-radius:",[0,20],";color:#fff;font-size:",[0,24],";height:",[0,84],";padding:0 ",[0,30],";position:absolute;right:",[0,30],"}\n.",[1],"mask-wrap .",[1],"btn.",[1],"data-v-04b774d9{border:1px solid #fff;border-radius:",[0,200],";color:#fff;font-size:",[0,24],";height:",[0,56],";position:absolute;right:",[0,30],";width:",[0,128],"}\n",],undefined,{path:"./components/guideMask/guideMask.wxss"});
}