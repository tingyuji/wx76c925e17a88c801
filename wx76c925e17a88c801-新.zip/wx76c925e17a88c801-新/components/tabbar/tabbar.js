(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/tabbar/tabbar" ], {
    "0507": function(t, n, a) {
        "use strict";
        var e = a("d6ae");
        a.n(e).a;
    },
    "09e8": function(t, n, a) {
        "use strict";
        a.r(n);
        var e = a("a4df"), c = a("3ce3");
        for (var o in c) [ "default" ].indexOf(o) < 0 && function(t) {
            a.d(n, t, function() {
                return c[t];
            });
        }(o);
        a("0507");
        var r = a("828b"), i = Object(r.a)(c.default, e.b, e.c, !1, null, "96571566", null, !1, e.a, void 0);
        n.default = i.exports;
    },
    "3ce3": function(t, n, a) {
        "use strict";
        a.r(n);
        var e = a("6f69"), c = a.n(e);
        for (var o in e) [ "default" ].indexOf(o) < 0 && function(t) {
            a.d(n, t, function() {
                return e[t];
            });
        }(o);
        n.default = c.a;
    },
    "6f69": function(t, n, a) {
        "use strict";
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0, getApp();
            var a = {
                name: "tabBar",
                props: {
                    current: {
                        type: Number,
                        default: 0
                    }
                },
                data: function() {
                    return {
                        tabList: [ {
                            name: "摘星星",
                            icon: "/static/tabbar/index.png",
                            icon_s: "/static/tabbar/index_s.png",
                            url: "/pages/index"
                        }, {
                            name: "星愿池",
                            icon: "/static/tabbar/wish.png",
                            icon_s: "/static/tabbar/wish_s.png",
                            url: "/pages/wish"
                        }, {
                            name: "我的",
                            icon: "/static/tabbar/mine.png",
                            icon_s: "/static/tabbar/mine_s1.png",
                            url: "/pages/mine"
                        } ]
                    };
                },
                methods: {
                    changeTab: function(n, a) {
                        this.current != a && t.switchTab({
                            url: n.url
                        });
                    }
                }
            };
            n.default = a;
        }).call(this, a("df3c").default);
    },
    a4df: function(t, n, a) {
        "use strict";
        a.d(n, "b", function() {
            return c;
        }), a.d(n, "c", function() {
            return o;
        }), a.d(n, "a", function() {
            return e;
        });
        var e = {
            fixBottom: function() {
                return a.e("components/fixBottom/fixBottom").then(a.bind(null, "4980"));
            }
        }, c = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    d6ae: function(t, n, a) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/tabbar/tabbar-create-component", {
    "components/tabbar/tabbar-create-component": function(t, n, a) {
        a("df3c").createComponent(a("09e8"));
    }
}, [ [ "components/tabbar/tabbar-create-component" ] ] ]);