$gwx_XC_18=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_18 || [];
function gz$gwx_XC_18_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_18_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'__l'])
Z([3,'data-v-96571566'])
Z([3,'d01cb1fc-1'])
Z([[4],[[5],[1,'default']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_18_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_18=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_18=true;
var x=['./components/tabbar/tabbar.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_18_1()
var hKD=_mz(z,'fix-bottom',['bind:__l',0,'class',1,'vueId',1,'vueSlots',2],[],e,s,gg)
_(r,hKD)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_18";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_18();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/tabbar/tabbar.wxml'] = [$gwx_XC_18, './components/tabbar/tabbar.wxml'];else __wxAppCode__['components/tabbar/tabbar.wxml'] = $gwx_XC_18( './components/tabbar/tabbar.wxml' );
	;__wxRoute = "components/tabbar/tabbar";__wxRouteBegin = true;__wxAppCurrentFile__="components/tabbar/tabbar.js";define("components/tabbar/tabbar.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["components/tabbar/tabbar"],{"0507":function(t,n,a){"use strict";var e=a("d6ae");a.n(e).a},"09e8":function(t,n,a){"use strict";a.r(n);var e=a("a4df"),c=a("3ce3");for(var o in c)["default"].indexOf(o)<0&&function(t){a.d(n,t,(function(){return c[t]}))}(o);a("0507");var r=a("828b"),i=Object(r.a)(c.default,e.b,e.c,!1,null,"96571566",null,!1,e.a,void 0);n.default=i.exports},"3ce3":function(t,n,a){"use strict";a.r(n);var e=a("6f69"),c=a.n(e);for(var o in e)["default"].indexOf(o)<0&&function(t){a.d(n,t,(function(){return e[t]}))}(o);n.default=c.a},"6f69":function(t,n,a){"use strict";(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0,getApp();var a={name:"tabBar",props:{current:{type:Number,default:0}},data:function(){return{tabList:[{name:"摘星星",icon:"/static/tabbar/index.png",icon_s:"/static/tabbar/index_s.png",url:"/pages/index"},{name:"星愿池",icon:"/static/tabbar/wish.png",icon_s:"/static/tabbar/wish_s.png",url:"/pages/wish"},{name:"我的",icon:"/static/tabbar/mine.png",icon_s:"/static/tabbar/mine_s1.png",url:"/pages/mine"}]}},methods:{changeTab:function(n,a){this.current!=a&&t.switchTab({url:n.url})}}};n.default=a}).call(this,a("df3c").default)},a4df:function(t,n,a){"use strict";a.d(n,"b",(function(){return c})),a.d(n,"c",(function(){return o})),a.d(n,"a",(function(){return e}));var e={fixBottom:function(){return a.e("components/fixBottom/fixBottom").then(a.bind(null,"4980"))}},c=function(){this.$createElement;this._self._c},o=[]},d6ae:function(t,n,a){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["components/tabbar/tabbar-create-component",{"components/tabbar/tabbar-create-component":function(t,n,a){a("df3c").createComponent(a("09e8"))}},[["components/tabbar/tabbar-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'components/tabbar/tabbar.js'});require("components/tabbar/tabbar.js");