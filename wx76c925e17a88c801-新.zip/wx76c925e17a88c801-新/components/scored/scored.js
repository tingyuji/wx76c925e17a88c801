(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/scored/scored" ], {
    "38ef": function(t, n, e) {
        "use strict";
        e.r(n);
        var i = e("95ba"), o = e("6569");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(a);
        e("4e55");
        var s = e("828b"), c = Object(s.a)(o.default, i.b, i.c, !1, null, "79b56252", null, !1, i.a, void 0);
        n.default = c.exports;
    },
    4673: function(t, n, e) {
        "use strict";
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var e = {
                props: {
                    data: {
                        type: Object,
                        default: {}
                    },
                    typeId: {
                        type: Number,
                        default: 0
                    },
                    date: {
                        type: null | String,
                        default: ""
                    },
                    showAini: {
                        type: Boolean,
                        default: !0
                    },
                    iosSafeArea: {
                        type: Boolean,
                        default: !0
                    }
                },
                data: function() {
                    return {
                        is_created: !1,
                        open: !1,
                        status_cache: 9,
                        plus_star: 0,
                        deduct_star: 0,
                        aini_show: !1,
                        changeTime: null,
                        lottie0: "https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/cry.json",
                        lottie1: "https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/good.json",
                        lottie2: "https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/great.json",
                        lottie3: "https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/excellent.json"
                    };
                },
                mounted: function() {
                    var n = this;
                    setTimeout(function() {
                        n.is_created = t.getStorageSync("userInfo").family.is_created;
                    }, 500);
                },
                watch: {
                    data: function(t) {
                        this.status_cache = t.status_cache, this.plus_star = t.star, this.deduct_star = t.deduct_star;
                    }
                },
                methods: {
                    show: function() {
                        var t = this;
                        this.open = !0, this.$nextTick(function() {
                            t.showAini && (t.plus_star = t.data.star, t.status_cache = t.data.status_cache, 
                            t.deduct_star = t.data.deduct_star, 9 == t.status_cache && t.playAudio(t.plus_star), 
                            t.aini_show = !0, setTimeout(function() {
                                t.aini_show = !1;
                            }, 2e3));
                        });
                    },
                    hide: function() {
                        this.aini_show = !1, this.open = !1;
                    },
                    playAudio: function(n) {
                        var e = t.createInnerAudioContext();
                        e.autoplay = !0, 1 == n ? e.src = "https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/good.mp3" : 2 == n ? e.src = "https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/great.mp3" : 3 == n && (e.src = "https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/excellent.mp3"), 
                        e.onEnded(function(t) {
                            try {
                                e.pause(), e.destroy(), e = null;
                            } catch (t) {}
                        }), e.onError(function(t) {
                            console.log(t.errMsg), console.log(t.errCode);
                        });
                    },
                    goEdit: function() {
                        this.open = !1, this.goPage("/pages/target/targetEdit?category_id=".concat(this.typeId, "&behaId=").concat(this.data.pid, "&beha=").concat(encodeURIComponent(JSON.stringify(this.data))));
                    },
                    scored: function(n, e) {
                        var i = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
                        if (8 == this.typeId && 1 == n) return this.$util.msg("该项为批评，不可加星~");
                        this.aini_show = !1, i && (1 == e ? t.vibrateLong() : t.vibrateShort()), 1 == e && (this.deduct_star = n), 
                        this.plus_star = n + 1, this.status_cache = e, this.$forceUpdate(), this.$api.behaviorsApi.behaviorsScored(this.data.id, {
                            child_id: t.getStorageSync("child_id"),
                            status: e,
                            star: 9 == e ? n + 1 : 1 == e ? this.deduct_star : 0,
                            star_day: this.date
                        }, !1, this).then(function(n) {
                            t.$emit("index_refresh_target"), t.$emit("record_refresh_target");
                        });
                    },
                    plusChange: function(n) {
                        var e = this;
                        t.vibrateShort(), null != this.changeTime && clearTimeout(this.changeTime), this.changeTime = setTimeout(function() {
                            e.scored(n - 1, 9, !1);
                        }, 500);
                    },
                    deductChange: function(n) {
                        var e = this;
                        t.vibrateShort(), null != this.changeTime && clearTimeout(this.changeTime), this.changeTime = setTimeout(function() {
                            e.deduct_star = n, e.scored(n, 1);
                        }, 500);
                    },
                    submit: function() {
                        this.open = !1;
                    }
                }
            };
            n.default = e;
        }).call(this, e("df3c").default);
    },
    "4e55": function(t, n, e) {
        "use strict";
        var i = e("5d94");
        e.n(i).a;
    },
    "5d94": function(t, n, e) {},
    6569: function(t, n, e) {
        "use strict";
        e.r(n);
        var i = e("4673"), o = e.n(i);
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(a);
        n.default = o.a;
    },
    "95ba": function(t, n, e) {
        "use strict";
        e.d(n, "b", function() {
            return o;
        }), e.d(n, "c", function() {
            return a;
        }), e.d(n, "a", function() {
            return i;
        });
        var i = {
            pageLoading: function() {
                return e.e("components/pageLoading/pageLoading").then(e.bind(null, "7f33"));
            },
            cLottie: function() {
                return Promise.all([ e.e("common/vendor"), e.e("uni_modules/c-lottie/components/c-lottie/c-lottie") ]).then(e.bind(null, "9b1b"));
            },
            uniNumberBox: function() {
                return e.e("uni_modules/uni-number-box/components/uni-number-box/uni-number-box").then(e.bind(null, "2406"));
            },
            mButton: function() {
                return e.e("components/mButton/mButton").then(e.bind(null, "fac5"));
            }
        }, o = function() {
            var t = this;
            t.$createElement;
            t._self._c, t._isMounted || (t.e0 = function(n) {
                n.stopPropagation(), t.is_created && t.goEdit();
            });
        }, a = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/scored/scored-create-component", {
    "components/scored/scored-create-component": function(t, n, e) {
        e("df3c").createComponent(e("38ef"));
    }
}, [ [ "components/scored/scored-create-component" ] ] ]);