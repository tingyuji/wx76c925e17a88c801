$gwx_XC_14=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_14 || [];
function gz$gwx_XC_14_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_14_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'__e'])
Z([[4],[[5],[[5],[[5],[[5],[[5],[1,'scored']],[1,'flex-align-center']],[1,'flex-column']],[1,'data-v-79b56252']],[[2,'?:'],[[7],[3,'open']],[1,'show'],[1,'']]]])
Z([[4],[[5],[[4],[[5],[[5],[1,'touchmove']],[[4],[[5],[[4],[[5],[[5],[1,'']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'__l'])
Z([3,'data-v-79b56252'])
Z([[7],[3,'loadingShow']])
Z([3,'180ee982-1'])
Z(z[4])
Z([3,'position:fixed;left:-10000rpx;'])
Z(z[3])
Z([3,'c-lottie data-v-79b56252 vue-ref'])
Z([3,'cLottieRef'])
Z([3,'350rpx'])
Z([1,true])
Z([[7],[3,'lottie0']])
Z([3,'180ee982-2'])
Z(z[12])
Z(z[3])
Z(z[10])
Z(z[11])
Z(z[12])
Z(z[13])
Z([[7],[3,'lottie1']])
Z([3,'180ee982-3'])
Z(z[12])
Z(z[3])
Z(z[10])
Z(z[11])
Z(z[12])
Z(z[13])
Z([[7],[3,'lottie2']])
Z([3,'180ee982-4'])
Z(z[12])
Z(z[3])
Z(z[10])
Z(z[11])
Z(z[12])
Z(z[13])
Z([[7],[3,'lottie3']])
Z([3,'180ee982-5'])
Z(z[12])
Z([[2,'&&'],[[7],[3,'aini_show']],[[2,'=='],[[7],[3,'status_cache']],[1,1]]])
Z(z[0])
Z([3,'aini-wrap data-v-79b56252'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[1,'hide']]]]]]]]])
Z(z[3])
Z(z[10])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[14])
Z([3,'180ee982-6'])
Z(z[12])
Z([[2,'&&'],[[7],[3,'aini_show']],[[2,'=='],[[7],[3,'plus_star']],[1,1]]])
Z(z[0])
Z(z[43])
Z(z[44])
Z(z[3])
Z(z[10])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[22])
Z([3,'180ee982-7'])
Z(z[12])
Z([[2,'&&'],[[7],[3,'aini_show']],[[2,'=='],[[7],[3,'plus_star']],[1,2]]])
Z(z[0])
Z(z[43])
Z(z[44])
Z(z[3])
Z(z[10])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[30])
Z([3,'180ee982-8'])
Z(z[12])
Z([[2,'&&'],[[7],[3,'aini_show']],[[2,'=='],[[7],[3,'plus_star']],[1,3]]])
Z(z[0])
Z(z[43])
Z(z[44])
Z(z[3])
Z(z[10])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[38])
Z([3,'180ee982-9'])
Z(z[12])
Z([[4],[[5],[[5],[[5],[[5],[[5],[1,'wrap']],[1,'flex-align-center']],[1,'flex-column']],[1,'data-v-79b56252']],[[2,'?:'],[[7],[3,'open']],[1,'show'],[1,'']]]])
Z(z[0])
Z([3,'icon-wrap flex-center data-v-79b56252'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e0']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[7],[3,'is_created']])
Z([3,'star-wrap flex-center flex-wrap data-v-79b56252'])
Z([[2,'!='],[[7],[3,'status_cache']],[1,1]])
Z([[7],[3,'open']])
Z(z[3])
Z(z[0])
Z(z[4])
Z([[4],[[5],[[4],[[5],[[5],[1,'^change']],[[4],[[5],[[4],[[5],[1,'plusChange']]]]]]]]])
Z([1,68])
Z([1,100])
Z([1,56])
Z([1,1])
Z([[7],[3,'plus_star']])
Z([3,'180ee982-10'])
Z(z[96])
Z(z[3])
Z(z[0])
Z(z[4])
Z([[4],[[5],[[4],[[5],[[5],[1,'^change']],[[4],[[5],[[4],[[5],[1,'deductChange']]]]]]]]])
Z(z[101])
Z(z[102])
Z(z[103])
Z([1,0])
Z([[7],[3,'deduct_star']])
Z([3,'180ee982-11'])
Z(z[3])
Z(z[0])
Z(z[4])
Z([[4],[[5],[[4],[[5],[[5],[1,'^submit']],[[4],[[5],[[4],[[5],[1,'submit']]]]]]]]])
Z([1,84])
Z([3,'180ee982-12'])
Z([[7],[3,'iosSafeArea']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_14_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_14=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_14=true;
var x=['./components/scored/scored.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_14_1()
var oBC=_mz(z,'view',['catchtouchmove',0,'class',1,'data-event-opts',1],[],e,s,gg)
var cGC=_mz(z,'page-loading',['bind:__l',3,'class',1,'loadingShow_',2,'vueId',3],[],e,s,gg)
_(oBC,cGC)
var oHC=_mz(z,'view',['class',7,'style',1],[],e,s,gg)
var lIC=_mz(z,'c-lottie',['bind:__l',9,'class',1,'data-ref',2,'height',3,'loop',4,'src',5,'vueId',6,'width',7],[],e,s,gg)
_(oHC,lIC)
var aJC=_mz(z,'c-lottie',['bind:__l',17,'class',1,'data-ref',2,'height',3,'loop',4,'src',5,'vueId',6,'width',7],[],e,s,gg)
_(oHC,aJC)
var tKC=_mz(z,'c-lottie',['bind:__l',25,'class',1,'data-ref',2,'height',3,'loop',4,'src',5,'vueId',6,'width',7],[],e,s,gg)
_(oHC,tKC)
var eLC=_mz(z,'c-lottie',['bind:__l',33,'class',1,'data-ref',2,'height',3,'loop',4,'src',5,'vueId',6,'width',7],[],e,s,gg)
_(oHC,eLC)
_(oBC,oHC)
var fCC=_v()
_(oBC,fCC)
if(_oz(z,41,e,s,gg)){fCC.wxVkey=1
var bMC=_mz(z,'view',['bindtap',42,'class',1,'data-event-opts',2],[],e,s,gg)
var oNC=_mz(z,'c-lottie',['bind:__l',45,'class',1,'data-ref',2,'height',3,'loop',4,'src',5,'vueId',6,'width',7],[],e,s,gg)
_(bMC,oNC)
_(fCC,bMC)
}
var cDC=_v()
_(oBC,cDC)
if(_oz(z,53,e,s,gg)){cDC.wxVkey=1
var xOC=_mz(z,'view',['bindtap',54,'class',1,'data-event-opts',2],[],e,s,gg)
var oPC=_mz(z,'c-lottie',['bind:__l',57,'class',1,'data-ref',2,'height',3,'loop',4,'src',5,'vueId',6,'width',7],[],e,s,gg)
_(xOC,oPC)
_(cDC,xOC)
}
var hEC=_v()
_(oBC,hEC)
if(_oz(z,65,e,s,gg)){hEC.wxVkey=1
var fQC=_mz(z,'view',['bindtap',66,'class',1,'data-event-opts',2],[],e,s,gg)
var cRC=_mz(z,'c-lottie',['bind:__l',69,'class',1,'data-ref',2,'height',3,'loop',4,'src',5,'vueId',6,'width',7],[],e,s,gg)
_(fQC,cRC)
_(hEC,fQC)
}
var oFC=_v()
_(oBC,oFC)
if(_oz(z,77,e,s,gg)){oFC.wxVkey=1
var hSC=_mz(z,'view',['bindtap',78,'class',1,'data-event-opts',2],[],e,s,gg)
var oTC=_mz(z,'c-lottie',['bind:__l',81,'class',1,'data-ref',2,'height',3,'loop',4,'src',5,'vueId',6,'width',7],[],e,s,gg)
_(hSC,oTC)
_(oFC,hSC)
}
var cUC=_n('view')
_rz(z,cUC,'class',89,e,s,gg)
var lWC=_mz(z,'view',['catchtap',90,'class',1,'data-event-opts',2],[],e,s,gg)
var aXC=_v()
_(lWC,aXC)
if(_oz(z,93,e,s,gg)){aXC.wxVkey=1
}
aXC.wxXCkey=1
_(cUC,lWC)
var tYC=_n('view')
_rz(z,tYC,'class',94,e,s,gg)
var eZC=_v()
_(tYC,eZC)
if(_oz(z,95,e,s,gg)){eZC.wxVkey=1
var b1C=_v()
_(eZC,b1C)
if(_oz(z,96,e,s,gg)){b1C.wxVkey=1
var o2C=_mz(z,'uni-number-box',['bind:__l',97,'bind:change',1,'class',2,'data-event-opts',3,'height',4,'max',5,'midWidth',6,'min',7,'value',8,'vueId',9],[],e,s,gg)
_(b1C,o2C)
}
b1C.wxXCkey=1
b1C.wxXCkey=3
}
else{eZC.wxVkey=2
var x3C=_v()
_(eZC,x3C)
if(_oz(z,107,e,s,gg)){x3C.wxVkey=1
var o4C=_mz(z,'uni-number-box',['bind:__l',108,'bind:change',1,'class',2,'data-event-opts',3,'height',4,'max',5,'midWidth',6,'min',7,'value',8,'vueId',9],[],e,s,gg)
_(x3C,o4C)
}
x3C.wxXCkey=1
x3C.wxXCkey=3
}
eZC.wxXCkey=1
eZC.wxXCkey=3
eZC.wxXCkey=3
_(cUC,tYC)
var f5C=_mz(z,'m-button',['bind:__l',118,'bind:submit',1,'class',2,'data-event-opts',3,'height',4,'vueId',5],[],e,s,gg)
_(cUC,f5C)
var oVC=_v()
_(cUC,oVC)
if(_oz(z,124,e,s,gg)){oVC.wxVkey=1
}
oVC.wxXCkey=1
_(oBC,cUC)
fCC.wxXCkey=1
fCC.wxXCkey=3
cDC.wxXCkey=1
cDC.wxXCkey=3
hEC.wxXCkey=1
hEC.wxXCkey=3
oFC.wxXCkey=1
oFC.wxXCkey=3
_(r,oBC)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_14";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_14();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/scored/scored.wxml'] = [$gwx_XC_14, './components/scored/scored.wxml'];else __wxAppCode__['components/scored/scored.wxml'] = $gwx_XC_14( './components/scored/scored.wxml' );
	;__wxRoute = "components/scored/scored";__wxRouteBegin = true;__wxAppCurrentFile__="components/scored/scored.js";define("components/scored/scored.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["components/scored/scored"],{"38ef":function(t,n,e){"use strict";e.r(n);var i=e("95ba"),o=e("6569");for(var a in o)["default"].indexOf(a)<0&&function(t){e.d(n,t,(function(){return o[t]}))}(a);e("4e55");var s=e("828b"),c=Object(s.a)(o.default,i.b,i.c,!1,null,"79b56252",null,!1,i.a,void 0);n.default=c.exports},4673:function(t,n,e){"use strict";(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var e={props:{data:{type:Object,default:{}},typeId:{type:Number,default:0},date:{type:null|String,default:""},showAini:{type:Boolean,default:!0},iosSafeArea:{type:Boolean,default:!0}},data:function(){return{is_created:!1,open:!1,status_cache:9,plus_star:0,deduct_star:0,aini_show:!1,changeTime:null,lottie0:"https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/cry.json",lottie1:"https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/good.json",lottie2:"https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/great.json",lottie3:"https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/excellent.json"}},mounted:function(){var n=this;setTimeout((function(){n.is_created=t.getStorageSync("userInfo").family.is_created}),500)},watch:{data:function(t){this.status_cache=t.status_cache,this.plus_star=t.star,this.deduct_star=t.deduct_star}},methods:{show:function(){var t=this;this.open=!0,this.$nextTick((function(){t.showAini&&(t.plus_star=t.data.star,t.status_cache=t.data.status_cache,t.deduct_star=t.data.deduct_star,9==t.status_cache&&t.playAudio(t.plus_star),t.aini_show=!0,setTimeout((function(){t.aini_show=!1}),2e3))}))},hide:function(){this.aini_show=!1,this.open=!1},playAudio:function(n){var e=t.createInnerAudioContext();e.autoplay=!0,1==n?e.src="https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/good.mp3":2==n?e.src="https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/great.mp3":3==n&&(e.src="https://xingmubiao.oss-cn-shanghai.aliyuncs.com/mini/excellent.mp3"),e.onEnded((function(t){try{e.pause(),e.destroy(),e=null}catch(t){}})),e.onError((function(t){console.log(t.errMsg),console.log(t.errCode)}))},goEdit:function(){this.open=!1,this.goPage("/pages/target/targetEdit?category_id=".concat(this.typeId,"&behaId=").concat(this.data.pid,"&beha=").concat(encodeURIComponent(JSON.stringify(this.data))))},scored:function(n,e){var i=!(arguments.length>2&&void 0!==arguments[2])||arguments[2];if(8==this.typeId&&1==n)return this.$util.msg("该项为批评，不可加星~");this.aini_show=!1,i&&(1==e?t.vibrateLong():t.vibrateShort()),1==e&&(this.deduct_star=n),this.plus_star=n+1,this.status_cache=e,this.$forceUpdate(),this.$api.behaviorsApi.behaviorsScored(this.data.id,{child_id:t.getStorageSync("child_id"),status:e,star:9==e?n+1:1==e?this.deduct_star:0,star_day:this.date},!1,this).then((function(n){t.$emit("index_refresh_target"),t.$emit("record_refresh_target")}))},plusChange:function(n){var e=this;t.vibrateShort(),null!=this.changeTime&&clearTimeout(this.changeTime),this.changeTime=setTimeout((function(){e.scored(n-1,9,!1)}),500)},deductChange:function(n){var e=this;t.vibrateShort(),null!=this.changeTime&&clearTimeout(this.changeTime),this.changeTime=setTimeout((function(){e.deduct_star=n,e.scored(n,1)}),500)},submit:function(){this.open=!1}}};n.default=e}).call(this,e("df3c").default)},"4e55":function(t,n,e){"use strict";var i=e("5d94");e.n(i).a},"5d94":function(t,n,e){},6569:function(t,n,e){"use strict";e.r(n);var i=e("4673"),o=e.n(i);for(var a in i)["default"].indexOf(a)<0&&function(t){e.d(n,t,(function(){return i[t]}))}(a);n.default=o.a},"95ba":function(t,n,e){"use strict";e.d(n,"b",(function(){return o})),e.d(n,"c",(function(){return a})),e.d(n,"a",(function(){return i}));var i={pageLoading:function(){return e.e("components/pageLoading/pageLoading").then(e.bind(null,"7f33"))},cLottie:function(){return Promise.all([e.e("common/vendor"),e.e("uni_modules/c-lottie/components/c-lottie/c-lottie")]).then(e.bind(null,"9b1b"))},uniNumberBox:function(){return e.e("uni_modules/uni-number-box/components/uni-number-box/uni-number-box").then(e.bind(null,"2406"))},mButton:function(){return e.e("components/mButton/mButton").then(e.bind(null,"fac5"))}},o=function(){var t=this;t.$createElement;t._self._c,t._isMounted||(t.e0=function(n){n.stopPropagation(),t.is_created&&t.goEdit()})},a=[]}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["components/scored/scored-create-component",{"components/scored/scored-create-component":function(t,n,e){e("df3c").createComponent(e("38ef"))}},[["components/scored/scored-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'components/scored/scored.js'});require("components/scored/scored.js");