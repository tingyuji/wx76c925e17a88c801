$gwx_XC_15=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_15 || [];
function gz$gwx_XC_15_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_15_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_15_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_15_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[4],[[5],[[5],[[5],[1,'sheet']],[1,'data-v-45e8efb7']],[[2,'?:'],[[7],[3,'open']],[1,'show'],[1,'']]]])
Z([[2,'+'],[[2,'+'],[1,'z-index:'],[[7],[3,'zIndex']]],[1,';']])
Z([3,'__e'])
Z(z[2])
Z([[4],[[5],[[5],[[5],[1,'mask']],[1,'data-v-45e8efb7']],[[2,'?:'],[[7],[3,'open']],[1,'show'],[1,'']]]])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'touchmove']],[[4],[[5],[[4],[[5],[[5],[1,'']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e0']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[4],[[5],[[5],[[5],[[5],[1,'sheet-wrap']],[1,'cxy_ios-bottom']],[1,'data-v-45e8efb7']],[[2,'?:'],[[7],[3,'open']],[1,'show'],[1,'']]]])
Z([3,'__i0__'])
Z([3,'item'])
Z([[7],[3,'sheetArr']])
Z([3,'id'])
Z(z[2])
Z([3,'sheet-item data-v-45e8efb7'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'select']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'sheetArr']],[1,'id']],[[6],[[7],[3,'item']],[3,'id']]]]]]]]]]]]]]]])
Z([3,'hover'])
Z([a,[[6],[[7],[3,'item']],[3,'name']]])
Z([3,'cut data-v-45e8efb7'])
Z(z[2])
Z([3,'cancel data-v-45e8efb7'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'hide']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[14])
Z([3,'取消'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_15_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_15_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_15=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_15=true;
var x=['./components/sheet/sheet.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_15_1()
var o4H=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var x5H=_mz(z,'view',['bindtap',2,'catchtouchmove',1,'class',2,'data-event-opts',3],[],e,s,gg)
_(o4H,x5H)
var o6H=_n('view')
_rz(z,o6H,'class',6,e,s,gg)
var f7H=_v()
_(o6H,f7H)
var c8H=function(o0H,h9H,cAI,gg){
var lCI=_mz(z,'view',['bindtap',11,'class',1,'data-event-opts',2,'hoverClass',3],[],o0H,h9H,gg)
var aDI=_oz(z,15,o0H,h9H,gg)
_(lCI,aDI)
_(cAI,lCI)
return cAI
}
f7H.wxXCkey=2
_2z(z,9,c8H,e,s,gg,f7H,'item','__i0__','id')
var tEI=_n('view')
_rz(z,tEI,'class',16,e,s,gg)
_(o6H,tEI)
var eFI=_mz(z,'view',['bindtap',17,'class',1,'data-event-opts',2,'hoverClass',3],[],e,s,gg)
var bGI=_oz(z,21,e,s,gg)
_(eFI,bGI)
_(o6H,eFI)
_(o4H,o6H)
_(r,o4H)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_15";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_15();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/sheet/sheet.wxml'] = [$gwx_XC_15, './components/sheet/sheet.wxml'];else __wxAppCode__['components/sheet/sheet.wxml'] = $gwx_XC_15( './components/sheet/sheet.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/sheet/sheet.wxss'] = setCssToHead([".",[1],"sheet.",[1],"data-v-45e8efb7{height:100vh;left:0;opacity:0;position:fixed;top:0;transition:all .3s ease;visibility:hidden;width:100vw}\n.",[1],"sheet.",[1],"show.",[1],"data-v-45e8efb7{opacity:1;visibility:visible}\n.",[1],"sheet .",[1],"mask.",[1],"data-v-45e8efb7{background-color:rgba(0,0,0,.5);bottom:0;left:0;position:fixed;right:0;top:0;z-index:1000}\n.",[1],"sheet-wrap.",[1],"data-v-45e8efb7{background-color:#fff;border-radius:",[0,20]," ",[0,20]," ",[0,0]," ",[0,0],";bottom:0;left:0;overflow:hidden;padding-top:",[0,22],";position:fixed;right:0;-webkit-transform:translateY(100%);transform:translateY(100%);transition:all .3s ease;width:100%;z-index:1002}\n.",[1],"sheet-wrap.",[1],"show.",[1],"data-v-45e8efb7{-webkit-transform:translateY(0);transform:translateY(0)}\n.",[1],"sheet-wrap .",[1],"sheet-item.",[1],"data-v-45e8efb7{color:#333;font-size:",[0,30],";font-weight:700;padding:",[0,30]," 0;text-align:center}\n.",[1],"sheet-wrap .",[1],"cut.",[1],"data-v-45e8efb7{background-color:#f6f6f6;height:",[0,4],";margin-top:",[0,22],";width:100%}\n.",[1],"sheet-wrap .",[1],"cancel.",[1],"data-v-45e8efb7{color:#999;font-size:",[0,30],";font-weight:700;padding:",[0,34]," 0;text-align:center}\n.",[1],"sheet-wrap .",[1],"hover.",[1],"data-v-45e8efb7{background-color:#f5f5f5}\n",],undefined,{path:"./components/sheet/sheet.wxss"});
}