(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/singleImg/singleImg" ], {
    "0901": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("8ce7"), o = n.n(a);
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(i);
        t.default = o.a;
    },
    "47e8": function(e, t, n) {
        "use strict";
        var a = n("f5ee");
        n.n(a).a;
    },
    7219: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {});
        var a = function() {
            var e = this, t = (e.$createElement, e._self._c, (e.uploading || e.image) && e.showImg && e.image && "err" != e.load ? e.ossFixedUrl.replace("{h}", e.size).replace("{w}", e.size) : null);
            e.$mp.data = Object.assign({}, {
                $root: {
                    g0: t
                }
            });
        }, o = [];
    },
    "8ce7": function(e, t, n) {
        "use strict";
        (function(e) {
            var a = n("47a9");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = a(n("7eb4")), i = a(n("ee10")), c = n("d6b4"), s = n("505c"), u = (a(n("ed82")), 
            {
                components: {
                    compress: function() {
                        n.e("components/compress").then(function() {
                            return resolve(n("de3a"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                props: {
                    size: {
                        type: Number,
                        default: 220
                    },
                    addSize: {
                        type: Number,
                        default: 180
                    },
                    imageBack: {
                        type: null | String,
                        default: ""
                    },
                    showDel: {
                        type: Boolean,
                        default: !0
                    },
                    showImg: {
                        type: Boolean,
                        default: !0
                    },
                    uploadModel: {
                        type: null | String,
                        default: ""
                    }
                },
                data: function() {
                    return {
                        image: "",
                        uploading: !1,
                        speed: 0,
                        load: !1
                    };
                },
                watch: {
                    imageBack: function(e) {
                        this.image = e;
                    }
                },
                mounted: function() {
                    this.image = this.imageBack;
                },
                methods: {
                    chooseImage: function() {
                        var t = this;
                        return (0, i.default)(o.default.mark(function n() {
                            var a;
                            return o.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    a = t, e.chooseImage({
                                        count: 1,
                                        success: function(t) {
                                            a.uploading = !0, a.image = t.tempFilePaths[0], a.showImg || e.showLoading({
                                                mask: !0
                                            }), a.uploadImg(t.tempFilePaths[0]);
                                        },
                                        fail: function(e) {}
                                    });

                                  case 2:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    uploadImg: function(t) {
                        var n = this;
                        return (0, i.default)(o.default.mark(function a() {
                            var i, u, r;
                            return o.default.wrap(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    return i = n, u = n.$refs.compress, a.next = 4, u.compress({
                                        src: t,
                                        fileType: "jpg",
                                        maxSize: 3e3
                                    });

                                  case 4:
                                    r = a.sent, e.uploadFile({
                                        url: s.config.host + "/api/v1/upload",
                                        filePath: r,
                                        name: "file_data",
                                        header: {
                                            Authorization: "Bearer " + e.getStorageSync("token"),
                                            "cli-os": "wechat",
                                            "cli-version": "1.0.0"
                                        },
                                        formData: (0, c.apiRequestSign)({
                                            file_type: "image",
                                            upload_model: i.uploadModel
                                        }, {
                                            app_id: "cd4a1bcdfcc4ea75f78d900b67fe29bd",
                                            app_key: "deb94c11ebac02471dba55050cb0638bbb6d0a92dd4f378fb09350492688e260"
                                        }),
                                        success: function(t) {
                                            i.image = JSON.parse(t.data).data.url, i.load = !0, i.showImg || e.hideLoading(), 
                                            i.$emit("upload", i.image);
                                        },
                                        complete: function(t) {
                                            i.uploading = !1, t.statusCode && 200 == t.statusCode || (t.statusCode && 413 == t.statusCode ? (i.load = "err", 
                                            e.showToast({
                                                title: "文件过大，请重新上传",
                                                icon: "none"
                                            })) : (i.load = "err", e.showToast({
                                                title: "上传失败，请检查网络",
                                                icon: "none"
                                            })));
                                        }
                                    }).onProgressUpdate(function(e) {
                                        i.speed = e.progress;
                                    });

                                  case 7:
                                  case "end":
                                    return a.stop();
                                }
                            }, a);
                        }))();
                    },
                    del: function() {
                        this.image = "", this.$emit("upload", "");
                    }
                }
            });
            t.default = u;
        }).call(this, n("df3c").default);
    },
    afd9: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("7219"), o = n("0901");
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(i);
        n("47e8");
        var c = n("828b"), s = Object(c.a)(o.default, a.b, a.c, !1, null, "1ce55c27", null, !1, a.a, void 0);
        t.default = s.exports;
    },
    f5ee: function(e, t, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/singleImg/singleImg-create-component", {
    "components/singleImg/singleImg-create-component": function(e, t, n) {
        n("df3c").createComponent(n("afd9"));
    }
}, [ [ "components/singleImg/singleImg-create-component" ] ] ]);