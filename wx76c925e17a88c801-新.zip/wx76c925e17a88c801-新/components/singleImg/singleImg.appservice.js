$gwx_XC_16=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_16 || [];
function gz$gwx_XC_16_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_16_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_16_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_16_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'imageV data-v-1ce55c27'])
Z([3,'con data-v-1ce55c27'])
Z([[2,'&&'],[[2,'||'],[[7],[3,'uploading']],[[7],[3,'image']]],[[7],[3,'showImg']]])
Z([3,'__e'])
Z([3,'area-con data-v-1ce55c27'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'chooseImage']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[2,'&&'],[[7],[3,'image']],[[2,'!='],[[7],[3,'load']],[1,'err']]])
Z([[2,'=='],[[7],[3,'load']],[1,'err']])
Z([[7],[3,'uploading']])
Z([[2,'&&'],[[2,'||'],[[7],[3,'image']],[[2,'=='],[[7],[3,'load']],[1,'err']]],[[7],[3,'showDel']]])
Z([[2,'||'],[[2,'!'],[[7],[3,'image']]],[[2,'!'],[[7],[3,'showImg']]]])
Z([3,'__l'])
Z([3,'data-v-1ce55c27 vue-ref'])
Z([3,'compress'])
Z([3,'e9ca896c-1'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_16_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_16_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_16=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_16=true;
var x=['./components/singleImg/singleImg.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_16_1()
var o8C=_n('view')
_rz(z,o8C,'class',0,e,s,gg)
var c9C=_n('view')
_rz(z,c9C,'class',1,e,s,gg)
var o0C=_v()
_(c9C,o0C)
if(_oz(z,2,e,s,gg)){o0C.wxVkey=1
var aBD=_mz(z,'view',['bindtap',3,'class',1,'data-event-opts',2],[],e,s,gg)
var tCD=_v()
_(aBD,tCD)
if(_oz(z,6,e,s,gg)){tCD.wxVkey=1
}
var eDD=_v()
_(aBD,eDD)
if(_oz(z,7,e,s,gg)){eDD.wxVkey=1
}
var bED=_v()
_(aBD,bED)
if(_oz(z,8,e,s,gg)){bED.wxVkey=1
}
var oFD=_v()
_(aBD,oFD)
if(_oz(z,9,e,s,gg)){oFD.wxVkey=1
}
tCD.wxXCkey=1
eDD.wxXCkey=1
bED.wxXCkey=1
oFD.wxXCkey=1
_(o0C,aBD)
}
var lAD=_v()
_(c9C,lAD)
if(_oz(z,10,e,s,gg)){lAD.wxVkey=1
}
o0C.wxXCkey=1
lAD.wxXCkey=1
_(o8C,c9C)
var xGD=_mz(z,'compress',['bind:__l',11,'class',1,'data-ref',2,'vueId',3],[],e,s,gg)
_(o8C,xGD)
_(r,o8C)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_16";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_16();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/singleImg/singleImg.wxml'] = [$gwx_XC_16, './components/singleImg/singleImg.wxml'];else __wxAppCode__['components/singleImg/singleImg.wxml'] = $gwx_XC_16( './components/singleImg/singleImg.wxml' );
	;__wxRoute = "components/singleImg/singleImg";__wxRouteBegin = true;__wxAppCurrentFile__="components/singleImg/singleImg.js";define("components/singleImg/singleImg.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["components/singleImg/singleImg"],{"0901":function(e,t,n){"use strict";n.r(t);var a=n("8ce7"),o=n.n(a);for(var i in a)["default"].indexOf(i)<0&&function(e){n.d(t,e,(function(){return a[e]}))}(i);t.default=o.a},"47e8":function(e,t,n){"use strict";var a=n("f5ee");n.n(a).a},7219:function(e,t,n){"use strict";n.d(t,"b",(function(){return a})),n.d(t,"c",(function(){return o})),n.d(t,"a",(function(){}));var a=function(){var e=this,t=(e.$createElement,e._self._c,(e.uploading||e.image)&&e.showImg&&e.image&&"err"!=e.load?e.ossFixedUrl.replace("{h}",e.size).replace("{w}",e.size):null);e.$mp.data=Object.assign({},{$root:{g0:t}})},o=[]},"8ce7":function(e,t,n){"use strict";(function(e){var a=n("47a9");Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var o=a(n("7eb4")),i=a(n("ee10")),c=n("d6b4"),s=n("505c"),u=(a(n("ed82")),{components:{compress:function(){n.e("components/compress").then(function(){return resolve(n("de3a"))}.bind(null,n)).catch(n.oe)}},props:{size:{type:Number,default:220},addSize:{type:Number,default:180},imageBack:{type:null|String,default:""},showDel:{type:Boolean,default:!0},showImg:{type:Boolean,default:!0},uploadModel:{type:null|String,default:""}},data:function(){return{image:"",uploading:!1,speed:0,load:!1}},watch:{imageBack:function(e){this.image=e}},mounted:function(){this.image=this.imageBack},methods:{chooseImage:function(){var t=this;return(0,i.default)(o.default.mark((function n(){var a;return o.default.wrap((function(n){for(;;)switch(n.prev=n.next){case 0:a=t,e.chooseImage({count:1,success:function(t){a.uploading=!0,a.image=t.tempFilePaths[0],a.showImg||e.showLoading({mask:!0}),a.uploadImg(t.tempFilePaths[0])},fail:function(e){}});case 2:case"end":return n.stop()}}),n)})))()},uploadImg:function(t){var n=this;return(0,i.default)(o.default.mark((function a(){var i,u,r;return o.default.wrap((function(a){for(;;)switch(a.prev=a.next){case 0:return i=n,u=n.$refs.compress,a.next=4,u.compress({src:t,fileType:"jpg",maxSize:3e3});case 4:r=a.sent,e.uploadFile({url:s.config.host+"/api/v1/upload",filePath:r,name:"file_data",header:{Authorization:"Bearer "+e.getStorageSync("token"),"cli-os":"wechat","cli-version":"1.0.0"},formData:(0,c.apiRequestSign)({file_type:"image",upload_model:i.uploadModel},{app_id:"cd4a1bcdfcc4ea75f78d900b67fe29bd",app_key:"deb94c11ebac02471dba55050cb0638bbb6d0a92dd4f378fb09350492688e260"}),success:function(t){i.image=JSON.parse(t.data).data.url,i.load=!0,i.showImg||e.hideLoading(),i.$emit("upload",i.image)},complete:function(t){i.uploading=!1,t.statusCode&&200==t.statusCode||(t.statusCode&&413==t.statusCode?(i.load="err",e.showToast({title:"文件过大，请重新上传",icon:"none"})):(i.load="err",e.showToast({title:"上传失败，请检查网络",icon:"none"})))}}).onProgressUpdate((function(e){i.speed=e.progress}));case 7:case"end":return a.stop()}}),a)})))()},del:function(){this.image="",this.$emit("upload","")}}});t.default=u}).call(this,n("df3c").default)},afd9:function(e,t,n){"use strict";n.r(t);var a=n("7219"),o=n("0901");for(var i in o)["default"].indexOf(i)<0&&function(e){n.d(t,e,(function(){return o[e]}))}(i);n("47e8");var c=n("828b"),s=Object(c.a)(o.default,a.b,a.c,!1,null,"1ce55c27",null,!1,a.a,void 0);t.default=s.exports},f5ee:function(e,t,n){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["components/singleImg/singleImg-create-component",{"components/singleImg/singleImg-create-component":function(e,t,n){n("df3c").createComponent(n("afd9"))}},[["components/singleImg/singleImg-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'components/singleImg/singleImg.js'});require("components/singleImg/singleImg.js");